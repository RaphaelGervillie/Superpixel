

#' @export
GradientBoostingModel <- function(target_variable, explanatory_variables,
                                  max_depth = 2, nround = 2,
                                  fit_default = list(),
                                  fit.default = NULL,
                                  transformation_function = NULL) {
  # <deprecated>
  if (!is.null(fit.default)
      && (class(fit_default) == "list") && length(fit_default) == 0) {
    fit_default <- fit.default
  }
  # </deprecated>
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)

  # object parameters
  this$target_variable       <- target_variable
  this$explanatory_variables <- explanatory_variables
  # algorithm parameters
  this$max_depth <- max_depth
  this$nround    <- nround

  class(this) <- append(class(this), "GradientBoostingModel")
  return(this)
}


#' Estimation of a GradientBoostingModel
#'
#' @rdname fit
#' @export
fit.GradientBoostingModel <- function(mid_term_model, data_train,
                                      bypass_transform = FALSE,
                                      leading_period = NULL,
                                      weights = NULL, by = NULL) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- mid_term_model$fit_default[["by"]]
  }

  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }

  data_train <- data_train[leading_period == 0, ]
  weights    <- weights[leading_period == 0]

  mask_train <- which(weights == 1)

  # TODO: check data_train columns are ok
  library(xgboost)
  mid_term_model$model_ <- xgboost(
    data  = as.matrix(
      data_train[mask_train, mid_term_model$explanatory_variables]),
    label = data_train[mask_train, mid_term_model$target_variable],
    max.depth = mid_term_model$max_depth,
    nround    = mid_term_model$nround,
    verbose = 0)
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @method predict GradientBoostingModel
#' @export
predict.GradientBoostingModel <- function(model, data_prediction,
                                          bypass_transform = FALSE,
                                          leading_period = NULL) {
  library(xgboost)
  prediction <- predict(
    model$model_, as.matrix(data_prediction[, model$explanatory_variables]))
  return(as.numeric(prediction)[leading_period == 0])
}
