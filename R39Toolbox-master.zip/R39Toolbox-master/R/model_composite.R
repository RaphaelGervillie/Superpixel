

#' Models that are combination of several others
#'
#' Composite models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#' Different models may be applied according to a "selection factor" that
#' tells which model should be applied on which part of the data.
#'
#' @param model_list Ordered list of models in the aggregation
#' @param selection_factor_name Name of the variable that is used to
#'   know which model should be applied on which data chunk
#' @param selection_factor_levels List of the selection factor values.
#'   The values in this list and their order are used to determine which
#'   model should be applied on which observations
#'
#' @export
CompositeModel <- function(model_list,
                             selection_factor_name, selection_factor_levels,
                             transformation_function = NULL,
                             fit_default = NULL) {
  this <- ForecastModel(fit_default = fit_default,
                        transformation_function = transformation_function)

  this$model_list <- model_list
  this$selection_factor_name   <- selection_factor_name
  this$selection_factor_levels <- selection_factor_levels

  class(this) <- append(class(this), "CompositeModel")
  return(this)
}


#' Estimation of the models in a CompositeModel
#'
#' This method only dispatches the call the individual models'
#' 'fit' methods. Some checks are run beforehand.
#' It is only a convenient way to fit the models all-at-once (on the same
#' dataset) if one does not want to do it manually.
#'
#' @rdname fit
#' @export
fit.CompositeModel <- function(model, data_train, leading_period = NULL,
                               bypass_transform = FALSE, weights = NULL,
                               by = NULL) {
  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_train)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_train'"))
  }
  if (length(levels(data_train[[model$selection_factor_name]]))
      != length(model$selection_factor_levels)) {
    stop(paste0("The number of levels in '", model$selection_factor_name,
                "' is different from the number of models in the ",
                "aggregation model"))
  }

  selection_factor <- levels(data_train[[model$selection_factor_name]])[
    data_train[[model$selection_factor_name]]]
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           leading_period_chunk <- leading_period[mask_chunk]
           # remove column used to dispatch data as it might be
           # incompatible with some models the structure of which is
           # determined from the available clumns in the dataset
           ind_select_fact <- which(names(data_train) %in%
               model$selection_factor_name)
           data_train_chunk <- data_train[mask_chunk, - ind_select_fact]
           if (!is.null(weights)) {
             weights_chunk <- weights[mask_chunk]
           } else {
             weights_chunk <- NULL
           }
           # perform fit
           model$model_list[[x]] <<- R39Toolbox::fit(
             model$model_list[[x]], data_train_chunk,
             bypass_transform = TRUE,
             leading_period = leading_period_chunk,
             weights = weights_chunk, by = by)
         })

  return(model)
}


#' Complex prediction from several models
#'
#' The models may have been fine-tuned or built from different datasets.
#' They can also be of different kind (e.g. GAM, Linear, RandomForest, ...)
#' Composite models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#'
#' @rdname predict
#' @method predict CompositeModel
#' @export
predict.CompositeModel <- function(model, data_prediction,
                                   bypass_transform = FALSE,
                                   leading_period = NULL) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_prediction)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_prediction'"))
  }
  unique_prediction_levels <- unique(
    data_prediction[[model$selection_factor_name]])
  if (length(unique_prediction_levels)
      > length(model$selection_factor_levels)) {
    stop(paste0("There are more levels in '", model$selection_factor_name,
                "' than there are models in the aggregation model."))
  }
  if (!all(unique_prediction_levels %in% model$selection_factor_levels)) {
    stop(paste0("There are levels in '", model$selection_factor_name,
                "' than do not correspond to a model ",
                "in the aggregation model."))
  }

  selection_factor <- levels(data_prediction[[model$selection_factor_name]])[
    data_prediction[[model$selection_factor_name]]]
  prediction <- vector(length = nrow(data_prediction))
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           if (length(which(mask_chunk)) > 0) {
             leading_period_chunk <- leading_period[mask_chunk]
             # remove column used to dispatch data as it might be
             # incompatible with some models the structure of which is
             # determined from the available clumns in the dataset
             ind_select_fact <- which(names(data_prediction) %in%
                                        model$selection_factor_name)
             data_prediction_chunk <- data_prediction[
               mask_chunk, - ind_select_fact]
             # perfom prediction
             prediction[mask_chunk] <<- predict(
               model$model_list[[x]], data_prediction_chunk,
               bypass_transform = TRUE, leading_period = leading_period_chunk)
           }
         })

  return(as.numeric(prediction))
}


#' Complex prediction from several models
#'
#' The models may have been fine-tuned or built from different datasets.
#' They can also be of different kind (e.g. GAM, Linear, RandomForest, ...)
#' Composite models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#'
#' @rdname predict_details
#' @export
predict_details.CompositeModel <- function(model, data_prediction,
                                           bypass_transform = FALSE,
                                           leading_period = NULL) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_prediction)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_prediction'"))
  }
  if (length(levels(data_prediction[[model$selection_factor_name]]))
      > length(model$selection_factor_levels)) {
    stop(paste0("There are more levels in '", model$selection_factor_name,
                "' than there are models in the aggregation model"))
  }

  selection_factor <- levels(data_prediction[[model$selection_factor_name]])[
      data_prediction[[model$selection_factor_name]]]
  all_effect_names <- NULL
  # Get the names of the effects for all the aggregated models
  for (i in 1:length(model$selection_factor_levels)) {
    mask_chunk <- (
      selection_factor == model$selection_factor_levels[[i]])
    data_prediction_chunk <- data_prediction[mask_chunk, ][1, , drop = FALSE]
    prediction_chunk <- predict_details(
      model$model_list[[i]], data_prediction_chunk,
      bypass_transform = TRUE, leading_period = NULL)
    all_effect_names <- c(all_effect_names, colnames(prediction_chunk))
  }
  all_effect_names <- unique(all_effect_names)
  prediction <- as.data.frame(
    matrix(nrow = nrow(data_prediction),
           ncol = length(all_effect_names)))
  colnames(prediction) <- all_effect_names
  # Do the actual prediction
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           leading_period_chunk <- leading_period[mask_chunk]
           data_prediction_chunk <- data_prediction[mask_chunk, ]
           prediction_chunk <- predict_details(
             model$model_list[[x]], data_prediction_chunk,
             bypass_transform = TRUE, leading_period = leading_period_chunk)
           prediction[mask_chunk, colnames(prediction_chunk)] <<- prediction_chunk
         })

  return(prediction)
}
