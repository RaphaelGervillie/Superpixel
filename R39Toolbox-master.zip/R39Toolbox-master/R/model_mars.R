#' @title Multivariate Adaptive (Regression) Splines Model
#'
#' @param target_variable the variable to predict
#' @param formula a formula (optional)
#' @param fit_default R39Toolbox model parameter
#' @param transformation_function R39Toolbox model parameter
#' @param degree 
#' @param nk 
#'
#' @export
MultivariateAdaptiveSplinesModel <- function(target_variable,
                                             degree, nk,
                                             formula = NULL,
                                             fit_default = NULL,
                                             transformation_function = NULL) {
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable <- target_variable
  
  # algorithm parameters
  this$degree <- degree
  this$nk     <- nk
  if (!is.null(formula)) {
    this$formula <- formula
  }
  
  class(this) <- append(class(this), "MultivariateAdaptiveSplinesModel")
  return(this)
}


#' Estimation of a MultivariateAdaptiveSplinesModel
#'
#' @importFrom stats model.matrix
#' @rdname fit
#' @export
fit.MultivariateAdaptiveSplinesModel <- function(mid_term_model, data_train,
                                       bypass_transform = FALSE,
                                       leading_period = NULL,
                                       weights = NULL, by = NULL) {
  mask_train <- which(weights == 1)
  
  # TODO: check data_train columns are ok
  if (!is.null(mid_term_model$formula)) {
    # fit by formula
    mid_term_model$model_ <- earth::earth(as.formula(mid_term_model$formula),
                                          data = data_train[mask_train, ],
                                          nk = mid_term_model$nk,
                                          degree = mid_term_model$degree)
    
  } else {
    # check data_train is numeric
    var_types <- sapply(data_train, class)
    if (!all(var_types == "numeric")) {
      stop("If no forumula is provided, the data_train need to be numeric")
    }
    
    # get the target index
    ind_target <- which(names(data_train) ==
                          mid_term_model$target_variable)
    
    # fit with all columns other than target variable
    mid_term_model$model_ <- earth::earth(x = as.matrix(
      data_train[mask_train, - ind_target]),
      y = as.matrix(data_train[mask_train,
                               ind_target]),
      nk = mid_term_model$nk,
      degree = mid_term_model$degree)
    
    # then record the explanatory_variables
    # for later prediction use
    # necessary to record to garantie the
    # right order of variables in matrix
    mid_term_model$explanatory_variables <-
      names(data_train)[-ind_target]
  }
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @importFrom stats model.matrix
#' @rdname predict
#' @export
predict.MultivariateAdaptiveSplinesModel <- function(model, data_prediction,
                                                     bypass_transform = FALSE,
                                                     leading_period = NULL) {
  
  if (is.null(model$formula)) {
    prediction <- predict(
      model$model_, data_prediction[, model$explanatory_variables])
  } else {
    prediction <- predict(model$model_, data_prediction)
  }
  
  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }
  
  return(prediction)
}
