## utf-8
## R39Toolbox
## @copyright EDF R&D 2015
## 2016-03-10
## Raphael Nedellec


#' binarize
#'
#' @param x, factor
#' @param label, optional, prefix for column name
#' @return a matrix of dummy (e.g 0 - 1) variables, of dimension
#'   'length(x)' and 'nlevel(x)'
#' @details This function transform a categorical variable with n
#'   levels into a integer (sparse) matrix, with n columns.  Each
#'   column contains only 1 and 0. For example, if x has 3 levels, A B
#'   and C, then each observation where x == A will be translate as a
#'   row \code{[1 0 0]}.
#' @examples
#' ex <- as.factor(c(rep(letters[1:6], each = 2), "hello", "ok"))
#' binarize(ex)
#' binarize(ex, "feat")
#'
#' @section Data transformation functions:
#' @export
binarize <- function(x, label = deparse(substitute(x))){

  ## TODO : sparse option with Matrix ??
  if (!(is.factor(x) | is.ordered(x)))
    stop("x must be of class factor or ordered")
  # n <- deparse(substitute(x))
  m <- as.data.frame(model.matrix(~ x +0))
  # new names
  colnames(m) <- gsub(pattern = "^x",
                      replacement = paste0(label, "_"),
                      colnames(m))
  return(m)
}

#' lag for a vector
#'
#' lag for a vector
#'
#' lag for a vector
#'
#' @param x : initial vector
#' @param lag : lag
#' @return a vector
#' @examples
#' n = 10000000
#' system.time(lag1 <- lag(1:n, 3))
#'
#' @note Copyright 2015 EDF
#' @section Data transformation functions:
#' @export
lag <- function(x, lag) {

  # controls
  if (!is.vector(x)) {
    stop("'x' must be a vector.")
  }
  if (length(lag) > 1){
    stop("length(lag) must be equal to 1.")
  }
  if (!is.numeric(lag) & !is.integer(lag)) {
    stop("'lag' must be an integer.")
  }
  if (lag != as.integer(lag)) {
    stop("'lag' must be an integer.")
  }
  if (lag < 0 | is.na(lag)) {
    stop("'lag' must be a positive integer.")
  }
  n <- length(x)
  if (lag > n) {
    stop("'lag' must be smaller than the number of elements in 'x'.")
  }

  # compute
  if (lag == 0) {
    x <- x
  } else if (lag == n) {
    x <- rep(NA, n)
  } else {
    x <- c(rep(NA, lag), x[c(1:(n - lag))])
  }

  return(x)
}


#' Exponential smoothing for a vector.
#'
#' Exponential smoothing for a vector.
#'
#' Exponential smoothing for a vector.
#'
#' @param x : initial vector
#' @param theta : smoothing parameter (double between 0 and 1).
#' @return a vector
#' @details smooth(x, theta)[t] = x[t]*(1-theta) + smooth(x,
#'   theta)[t-1]*theta. Does not deal with missing values.  Missing
#'   values must be dealt with before using smooth
#' @note Copyright 2016 EDF
#' @examples
#' smooth(1:10, 0.5)
#'
#' @section Data transformation functions:
#' @export
smooth <- function(x, theta) {

  # controls
  if (!is.vector(x)) {
    stop("'x' must be a vector")
  }
  if (!(is.numeric(x) | is.integer(x))) {
    stop("'x' must be a numeric vector")
  }
  if (length(x) <= 1) {
    stop("'x' must be a numeric vector with at least two elements")
  }
  if (length(theta) > 1) {
    stop("length(theta) must be equal to 1.")
  }
  if (theta < 0 | theta > 1) {
    stop("'theta' must be between 0 and 1")
  }
  if (any(is.na(x))) {
    stop("'x' must not have missing values. NA must be dealt with beforehand.")
  }

  # compute
  for (k in seq_along(x)[-1]) {
    x[k] <- x[k] * (1 - theta) + theta * x[k - 1]
  }
  return(x)
}


#' Timezone conversion for a dataset with time observations
#'
#' @param data : data.frame to transform
#' @param target_timezonetz : Timezone to be switch to.
#'                            Any standard timezone defined in POSIX norm.
#' @return a data.frame that is the exact same than `data`, but with the
#'         timezone updated to what is expected by `target_timezone`
#'
#' @examples
#'   data <- R39Toolbox::R39ExData
#'   attr(data$date, 'tzone')  # should be 'UTC'
#'   data.cet <- R39Toolbox::switch_time_zone(data, 'CET')
#'   attr(data.cet$date, 'tzone')  # timezone is 'CET' now
#'
#' @details
#' 'CET24' is a special timezone that has been introduced in the R39Toolbox
#' package because of its consistency with the data from the operational
#' divisions with which EDF R&D is working. It is a mix betwwen UTC -as the
#' instants are the same for each day of the year- and Paris time (often
#' wrongly referred to as 'CET') -as there is a one-hour shift between
#' summer and winter time. In other words, CET24 is equal to the CET/CEST
#' combination except that each day in which a daylight saving time switch
#' occurs is transformed so as to have the same number of instant than any
#' other day.
#'
#' \tabular{ccc}{
#' initial tz \tab target tz \tab algorithm \cr
#'       \tab         \tab \cr
#'       \tab   UTC   \tab          nothing to do \cr
#' UTC   \tab   CET   \tab       standard tz update \cr
#'       \tab  CET24  \tab update to CET and to_cet24 function \cr
#'       \tab   UTC   \tab          nothing to do \cr
#' CET   \tab   CET   \tab       standard tz update \cr
#'       \tab  CET24  \tab update to CET and to_cet24 function \cr
#'       \tab   UTC   \tab            not allowed \cr
#' CET24 \tab   CET   \tab            not allowed \cr
#'       \tab  CET24  \tab           nothing to do \cr
#' }
#'
#' @section Data transformation functions:
#' @export
switch_time_zone <- function(data, target_timezone) {
  col_date <- "date"
  date_control <- R39Toolbox::check_dates(data)
  initial_timezone <- date_control$tz

  # early stop if conversion to the same timezone
  if (initial_timezone == target_timezone) {
    return(data)
  }

  # check that the wanted conversion is valid
  if ((initial_timezone == 'CET24') & !(target_timezone == 'CET24')) {
    stop("Can't transform from CET24 to another timezone")
  }

  # conversion (reminder: initial and target tz are different at this point)
  if (target_timezone == 'CET24') {
    attr(data[[col_date]], "tzone") <- 'CET'  # changes nothing if already CET
    data <- to_cet24(
      data, ind_date = which(colnames(data) == col_date))
  } else {
    attr(data[[col_date]], "tzone") <- target_timezone
  }

  data
}


#' Resample a dataset of timed observations
#'
#' Change the timestep between the observations of a dataset
#'
#' The variables encoded as the columns of the dataframe may be
#' interpolated. It is the responsibility of the user to ensure
#' that he provides only quantitative variables. Would qualitative
#' variables be needed, one can use the 'generate_calendar' function
#' of the package to build them at the desired sample rate.
#'
#' @param data : Dataframe to be resampled
#' @param target_timestep : Increment of the sequence. Default to
#'   "10 min".  Can be a number, in seconds, or a character string
#'   containing one of "min", "hour", "day".  This can optionally be
#'   preceded by a positive integer and a space
#' @param fun_aggr : Aggregation function to use ("min", "max", "sum",
#'   "mean").  Default to "mean". Can be NULL for no aggregation.
#' @param type_aggr: Character. Type of aggregation \itemize{
#'   \item{"first"}{ : Date/Time result is equal to minimum of
#'   sequence, and this minimum is included in aggregation}
#'   \item{"last"}{ : Date/Time result is equal to maximum of and this
#'   maximum is included in aggregation} }
#'
#' @return a data.frame with resample observations
#'
#' @section Data transformation functions:
#' @export
resample <- function(data, target_timestep = "10 min",
                     fun_aggr = 'mean', type_aggr = 'first') {
  # various initialisations
  col_date <- "date"
  initial_column_order <- colnames(data)
  columns_quali  <- names(data)[sapply(names(data),
                                       function(x) {
                                         any(class(data[[x]])
                                             %in% c("factor", "character",
                                                    "ordered"))})]
  if ("date" %in% columns_quali) {
    columns_quali <- columns_quali[which(columns_quali != "date")]
  }
  columns_quanti <- names(data)[sapply(names(data),
                                       function(x) {
                                         any(class(data[[x]])
                                             %in% c("numeric", "integer",
                                                    "double"))})]
  all_columns_but_date <- setdiff(colnames(data), col_date)

  # check 'fun_aggr' argument
  if (!is.null(fun_aggr)) {
    if (!fun_aggr %in% c('mean', 'min', 'max', 'sum')) {
      stop("Invalid 'fun_aggr' argument provided")
    }
  }

  # Check dates
  date_control <- R39Toolbox::check_dates(data)
  # check initial timezone and set working timezone accordingly
  initial_timezone <- date_control$tz
  if (initial_timezone == "CET24") {
    data[[col_date]] <- as.POSIXct(as.character(data[[col_date]]), tz = 'UTC')
    working_timezone <- 'UTC'
  } else {
    working_timezone <- date_control$tz
  }

  # Interpret function argument
  # read 'target_timestep' value and convert it to seconds
  if ("character" %in% class(target_timestep)) {  # ts provided as a character
    # check if 'target_timestep' has been given a unit
    provided_time_unit <- try(
      match.arg(gsub("^[[:digit:]]+[[:space:]]+","", target_timestep),
                choices = c("day", "hour", "min")), silent = TRUE)
    if ("try-error" %in% class(provided_time_unit)) {
      stop("Invalid 'ts' argument. Please use 'day', 'hour', or 'min'")
    }
    # convert 'target_timestep' (with the unit stripped) to a number
    check <- regexpr("[[:digit:]]+", target_timestep)
    number_time <- ifelse(check == -1, 1,
                          as.numeric(regmatches(target_timestep, check)))
    # convert 'target_timestep' in seconds
    time_conversion  <- c(day = 86400, hour = 3600, min = 60)
    target_timestep <- time_conversion[[provided_time_unit]] * number_time
    timestamp_selection_needed <- FALSE
  } else {  # 'target_timestep' is provided in seconds
    if (target_timestep < 60) {
      stop("Invalid 'target_timestep' argument. Must be at least 60.")
    }
    if (target_timestep %% 60 != 0) {
      stop(paste0("Please provide a value for 'target_timestep' that ",
                  "corresponds to a round number of minutes"))
    }
  }

  # Initial timestep
  if (date_control$ts != "non-uniform") {
    initial_timestep <- date_control$ts
  } else {  # non-uniform timestep
    if (length(columns_quali) > 0) {
      stop(paste0("The input dataset contains qualitative columns ",
                  "but its timestep is not uniform. It is therefore ",
                  "impossible to infer the values for the qualitative ",
                  "variables on the output grid."))
    }
    initial_timestep <- target_timestep
  }
  # if needed, generate an oversampled data set, from which we might choose
  # the timestamps that we want at the end.
  working_timestep <- gcd(target_timestep, initial_timestep)
  # is the working grid finer than the desired one?
  timestamp_selection_needed <- FALSE
  if (working_timestep < target_timestep) {
    timestamp_selection_needed <- TRUE
  }
  # will there be the need for an aggregation strategy?
  aggregation_needed <- FALSE
  if ((target_timestep > initial_timestep) & !is.null(fun_aggr)) {
    if (target_timestep %% initial_timestep == 0) {
      aggregation_needed <- TRUE
    }
  }

  # check that we can deal with qualitative variable if any
  if ((target_timestep > initial_timestep)
      & (target_timestep %% initial_timestep != 0)
      & (length(columns_quali) > 0)) {
    stop(paste0("The input dataset contains qualitative columns ",
                "and the nodes of the input grid does not correspond ",
                "to existing nodes in the output grid. No interpolation ",
                "method for the qualitative variables is implemented yet. ",
                "It is therefore impossible to infer the values for the ",
                "qualitative variables on the output grid."))
  }
  if ((target_timestep < initial_timestep)
      & (initial_timestep %% target_timestep != 0)
      & (length(columns_quali) > 0)) {
    stop(paste0("The input dataset contains qualitative columns ",
                "and the nodes of the output grid does not correspond ",
                "to existing nodes in the input grid. No interpolation ",
                "method for the qualitative variables is implemented yet. ",
                "It is therefore impossible to infer the values for the ",
                "qualitative variables on the output grid."))
  }

  # New timestamps generation
  new_data <- cbind(
    data[[col_date]],
    #mtqdate = as.Date(data[[col_date]], tz = working_timezone),
    #mtqtime = as.ITime(data[[col_date]], tz = working_timezone),
    data[, all_columns_but_date, drop = FALSE])
  colnames(new_data) <- c(col_date, all_columns_but_date)
  new_date_time <- seq.POSIXt(
    from = as.POSIXct(data[1, col_date], tz = working_timezone),
    to   = as.POSIXct(data[nrow(data), col_date], tz = working_timezone),
    by   = working_timestep)

  # Interpolation
  res <- data.frame(tmpdate = new_date_time)
  tmp_function <- function(x) {
    res$tmp <<- approx(x    = new_data[[col_date]],
                       y    = new_data[[x]],
                       xout = new_date_time)$y
    ## # TODO: do not treat missing here, but in a imputer instead
    ## if (!treat.missing) {
    ##   res$tmp[which(is.na(new_data[, eval(parse(text = x))]))] <<- NA
    ## }
    colnames(res)[ncol(res)] <<- x
  }
  sapply(columns_quanti, tmp_function)
  colnames(res)[1] <- col_date

  # Resample date sequence (pick desired timestamps)
  # It is assumed that the first instant of the input dataset matches
  # an instant of the new grid.
  if (timestamp_selection_needed) {
    step_width <- target_timestep / working_timestep
    if (aggregation_needed) {
      n_samples_input <- dim(res)[[1]]
      if (type_aggr == 'first') {
        aggreg <- rep(1:n_samples_input, each = step_width)[1:n_samples_input]
      } else if (type_aggr == 'last') {
        n_samples_output <- (n_samples_input - 1) %/% step_width
        aggreg <- c(1, 1 + rep(1:n_samples_input,  # first instant
                               each = step_width))[1:n_samples_input]

      } else {
        stop(paste0("Unknwown aggregration type 'type_aggr' (",
                    type_aggr, ")."))
      }
      res_no_date <- aggregate(
        res[, columns_quanti], by = list(aggreg), FUN = fun_aggr)
      if (type_aggr == 'last') {
        res_no_date <- res_no_date[2:dim(res_no_date)[[1]], ]
      }
      res <- res[seq(1, n_samples_input, step_width), ]
      res[, columns_quanti] <- res_no_date[, 2:dim(res)[[2]]]
      if (type_aggr == 'last') {
        res <- res[1:n_samples_output, ]  # remove incomplete slots
      }
    } else {
      if (type_aggr == 'first') {
        res <- res[seq(1, dim(res)[[1]], step_width), ]
      } else if (type_aggr == 'last') {
          res <- res[seq(step_width, dim(res)[[1]], step_width), ]
      } else {
        stop(paste0("Unknwown aggregration type 'type_aggr' (",
                    type_aggr, ")."))
      }
    }
  }
  # resample qualitative variables
  if (length(columns_quali) > 0) {
    if (target_timestep < initial_timestep) {
      step_width <- initial_timestep / target_timestep
      n_samples_output <- dim(res)[[1]]
      if (type_aggr == 'first') {
        res_quali <- as.data.frame(
          sapply(columns_quali,
                 function(x) {
                   rep(data[[x]], each = step_width)[1:n_samples_output]
                 }))
      } else if (type_aggr == 'last') {
        #n_samples_output <- (n_samples_input - 1) %/% step_width
        res_quali <- as.data.frame(
          sapply(columns_quali,
                 function(x) {
                   c(rep(data[[x]], each = step_width))[seq(step_width,
                                                            n_samples_output
                                                            + step_width - 1)]
                 }))
      } else {
        stop(paste0("Unknwown aggregration type 'type_aggr' (",
                    type_aggr, ")."))
      }
    } else {
      step_width <- target_timestep / initial_timestep
      if (type_aggr == 'first') {
        res_quali <- subset(data[seq(1, dim(data)[[1]], step_width), ],
                            select = columns_quali)
      } else if (type_aggr == 'last') {
        res_quali <- subset(data[seq(step_width, dim(data)[[1]], step_width), ],
                            select = columns_quali)
      } else {
        stop(paste0("Unknwown aggregration type 'type_aggr' (",
                    type_aggr, ")."))
      }
    }
    res <- cbind(res, res_quali)
  }
  res <- res[, initial_column_order]

  if (aggregation_needed & (type_aggr == 'last')) {
    res[[col_date]] <- res[[col_date]] + target_timestep
  }

  if (initial_timezone == 'CET24') {
    res[, col_date] <- format.POSIXct(res[, col_date], "%Y-%m-%d %H:%M:%S")
    class(res[, col_date]) <- "CET24"
  }
  res
}


# Function to compute the Greatest Common Divisor (GCD) between two numbers
gcd <- function(a, b) {
  if (abs(b - 0) < 1e-7) {
    pgs <- a
  }
  else {
    r <- a %% b
    pgs <- gcd(b, r)
  }

  pgs
}

#' Extraction of a daily statistic for a given variable in a dataset
#'
#' If a day is uncomplete, the nthe statistic will be computed on less
#' observations for that day (no warning is given).
#'
#' @param data Dataframe which contains the variable to be summarized
#' @param variable_name Variable that should be summarized
#' @param stat Statistic that must be used to summarize the variable
#'
#' @return A vectore that can be directly added to the original dataset
#'
#' @export
extract_daily_statistic <- function(data, variable_name, stat = mean) {
  date_control <- R39Toolbox::check_dates(data)
  data$date_str <- strftime(data$date, format = "%Y%m%d", tz = date_control$tz)
  tmp <- aggregate(
    data[, c(variable_name)], by = list(date_str = data$date_str), stat)
  merge(data, tmp, by = 'date_str', sort = FALSE, all.x = TRUE)$x
}
