

#' Linear model
#'
#' A linear model is entirely defined by a (linear) formula.
#'
#' @param formula : The (linear) formula corresponding to the model.
#'                  Note that the specification of the formula puts
#'                  a constraint on the data the model will be used on
#'                  (column names).
#'
#' @examples
#' model <- R39Toolbox::LinearModel('conso ~ Temperature + Posan')
#'
#' @export
LinearModel <- function(formula, fit_default = NULL,
                        transformation_function = NULL) {
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)

  # TODO : add LM options such as "na.action", "weights", ...
  this$formula <- formula

  class(this) <- append(class(this), "LinearModel")
  return(this)
}


#' Estimation of a LinearModel
#'
#' We use R's base interface to fit a linear model.
#' If specified by the user, the model is fit by a factor via the
#' mecanism that is defined in the MidTermForecastModel fit method.
#'
#' @rdname fit
#' @export
fit.LinearModel <- function(model, data_train,
                            bypass_transform = FALSE,
                            leading_period = NULL, weights = NULL,
                            by = NULL) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- model$fit_default[["by"]]  # NULL if not defined
  }

  # TODO: check data_train columns are ok
  model$model_ <- lm(
    formula = as.formula(model$formula),
    data = data_train, weights = weights)
  return(model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @method predict LinearModel
#' @export
predict.LinearModel <- function(model, data_prediction,
                                bypass_transform = FALSE,
                                leading_period = NULL) {
  prediction <- predict(model$model_, data_prediction)
  return(as.numeric(prediction)[leading_period == 0])
}
