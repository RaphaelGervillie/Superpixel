GeneralizedAdditiveModelShortTerm <- function(formula,
                                              fit_default = NULL,
                                              transformation_function = NULL,
                                              clean = FALSE, knots = NULL,
                                              short_term_variables = NULL) {
  if (is.null(short_term_variables)) {
    this <- MidTermForecastModel(
      fit_default = fit_default,
      transformation_function = transformation_function)
  } else {
    this <- ShortTermForecastModel(target_variable = short_term_variables[[1]],
                                   fit_default = fit_default,
                                   transformation_function = transformation_function)
  }

  this$clean   <- clean
  this$formula <- formula
  this$knots   <- knots
  this$short_term_variables <- short_term_variables

  model_classes <- c("ForecastModel", "MidTermForecastModel")
  if (is.null(short_term_variables)) {
    model_classes <- append(model_classes, "ShortTermForecastModel")
  }
  model_classes <- append(model_classes, "GeneralizedAdditiveModel")
  class(this) <- model_classes
  return(this)
}

predict.GeneralizedAdditiveModelShortTerm <- function(model, data_prediction,
                                                      bypass_transform = FALSE,
                                                      leading_period = NULL,
                                                      ...) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the model has been fit
  if (is.null(model$model_)) {
    stop(paste0("Please fit the GAM model before it can be used to ",
                "make a prediction."))
  }
  ## # check the presence of the target variable
  ## if (!model$target_variable %in% names(data_prediction)) {
  ##   stop(paste0("No signal ('", model$target_variable,
  ##               "') found to apply the short-term GAM model."))
  ## }

  if (!is.null(model$by_) && (model$by_ != FALSE)) {
   # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_,
      expected_n_levels = length(model$model_))
    prediction <- rep(NA, nrow(data_prediction))
    check <- lapply(
        names(ind_split),
        function(x) {
          level_pos <- which(model$levels_ == x)[[1]]
          if (is.null(level_pos)) {
            stop("Could not find level ", level, " in the levels the ",
                 "model has been trained with.")
          }
          if (length(which(leading_period[ind_split[[x]]] == 0)) > 0) {
            prediction[ind_split[[x]]][leading_period[ind_split[[x]]] == 0] <<- predict(
              model$model_[[level_pos]], data_prediction[ind_split[[x]], ],
              bypass_transform = TRUE,
              leading_period = leading_period[ind_split[[x]]])
          }
        })
  } else {
    start_prediction <- which(leading_period == 0)[[1]]
    if (all(model$lags == 'auto')) {
      model_order <- model$model_$order
    } else {
      model_order <- max(model$lags)
    }
    # check the presence of leading data to apply the model
    if (model_order >= start_prediction) {
      stop(paste0('Cannot predict with an AR model if not ',
                  'enough leading data is provided'))
    } else {
      # check the presence of the target variable on the leading period
      check_tmp <- data_prediction[[model$target_variable]][
        (start_prediction - model_order):(start_prediction - 1)]
      if (all(model$lags == 'auto')) {
        if (any(is.na(check_tmp))) {
          warning("NA in AR model's leading data.")
        }
      } else {
        if (any(is.na(check_tmp[length(check_tmp) + 1 - model$lags]))) {
          warning("NA in AR model's leading data.")
        }
      }
    }

    prediction <- rep(NA, nrow(data_prediction))
    y <- data_prediction[[model$target_variable]]
    if (all(model$lags != 'auto')) {
      sapply(start_prediction:length(prediction),
             function(x) {
               lags_observations <- y[x - model$lags]
               prediction[x] <<- sum(model$coefficients_ * lags_observations)
               #if (mode != 'online') {
               # use AR's own prediction for the sequel
               y[x] <<- prediction[x]
               #}
             })
    } else {
      sapply(start_prediction:length(prediction),
             function(x) {
               mask_fit <- 1:(x - 1)
               data_fit <- data.frame(y[mask_fit])
               colnames(data_fit) <- model$target_variable
               #if (online_refit) && (mode == 'online')) {
               #  # refit makes no real sense if mode is not online
               #  model <- R39Toolbox::fit(model, data_fit,
               #                           bypass_transform = bypass_transform)
               #}
               prediction[x] <<- as.numeric(
                 predict(
                   model$model_, data_fit[[model$target_variable]],
                   n.ahead = 1)$pred)
               #if (mode != 'online') {
               # use AR's own prediction for the sequel
               y[x] <<- prediction[x]
               #}
             })
    }
  }

  return(prediction[leading_period == 0])
}
