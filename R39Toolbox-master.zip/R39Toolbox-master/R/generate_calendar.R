## R39Toolbox
## @copyright EDF R&D 2015
## 2015-09-10
## Benoit Thieurmel


#' Calendar generator
#'
#' Function to generate calendar data
#'
#' @param date_begin : Calendar start date. "YYYY-MM-DD HH:MM:SS" or
#'   "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or "YYYY/MM/DD" are also
#'   accepted)
#' @param date_end : Calendar end date. "YYYY-MM-DD HH:MM:SS" or
#'   "YYYY-MM-DD"
#' @param ts : Time increment between the observations, in seconds.
#'   Default to 10 * 60 (10 minutes).
#'   When ts > 24 * 60 * 60 (24 hours), then the hours/minutes/seconds
#'   information is considered as not relevant and the timestep between
#'   two consecutive calendar rows mights not be uniform. This creates a
#'   difference only when 'CET' is used as the timezone.
#' @param tz : Time zone. One of "UTC", "GMT", "CET" or "CET24"
#' @param holidays : Either a character string vector of
#'   holidays we have to consider, or a single character taking value
#'   in "FR" or "PT".  If a character vector, see
#'   listHolidays(pattern=".*") from timeDate package for details. If
#'   it is equal to "FR", all french bank holidays will be
#'   computed. If it is equal to "PT", all portuguese bank holidays
#'   will be computed.
#' @param Variables : List of the wanted variables as character strings.
#'                    \describe{
#'                      \item{date}{Date in POSIXlt format}
#'                      \item{DateNum}{Numeric date (+ time).
#'                                     YYYYMMDDYYMM format.
#'                                     Not kept by default}
#'                      \item{Annee}{Year}
#'                      \item{Mois}{Month, from 1 to 12}
#'                      \item{Jour}{Day of the month, from 1 to 31}
#'                      \item{Heure}{Hour, from 0 to 23}
#'                      \item{Minute}{Minute, from 0 to 59}
#'                      \item{Instant}{Instant of the day. Depends of ts}
#'                      \item{Posan}{Position in the year, from 0 to 1}
#'                      \item{Tendance}{Date in numeric format, with
#'                                      origin = "1960-01-01" and tz = tz}
#'                      \item{Mois}{Month, from 1 to 12}
#'                      \item{JourSemaine}{Weekday, from 0 (sunday)
#'                                         to 6 (saturday).}
#'                      \item{JourFerie}{1 if day-off, 0 otherwise}
#'                      \item{Ponts}{1 if bridging day, 0 otherwise}
#'                      \item{isoSemaine}{Week of year in ISO 8601 format}
#'                      \item{isoAnnee}{Year in ISO 8601 format}
#'                    }
#' @param keep_last : whether or not to include the end date as part
#'   of the calendar.
#' @param convention : Date representation to be used. Default is
#'   NULL, which correspond to "no specification". If 'begin'
#'   (resp. 'end'), the date column is assumed to correspond to the
#'   lower (resp.  upper) bound of a period interval that is
#'   associated to the values in the same row.
#'
#' @return a data.frame.
#'
#' @examples
#' # 10 minutes
#' c1 <- generate_calendar(
#'   "2010-01-01 10:00", "2010-12-31 23:50", ts = 10 * 60)
#'
#' # hourly
#' c2 <- generate_calendar(
#'   "2010/01/01 00:00", "2010/12/31 23:50", ts = 60 * 60)
#'
#' # 3-hourly, CET24
#' c3 <- generate_calendar(
#'   "2010-01-01 00:00", "2010-12-31 23:50", ts = 3 * 60 * 60, tz = "CET24")
#'
#' @note Copyright 2014 EDF
#' @import timeDate
#' @export
generate_calendar <- function(date_begin, date_end, ts = 10 * 60, tz = "UTC",
                              holidays = "FR",
                              variables = c("date", "Annee", "Mois", "Jour",
                                            "Heure", "Minute", "Instant",
                                            "Posan", "Tendance", "JourSemaine",
                                            "JourFerie", "Ponts", "isoSemaine",
                                            "isoAnnee"),
                              keep_last = TRUE, convention = NULL) {
  # Do some checks ---------------------------
  # check date input format
  if ("character" %in% class(date_begin)) {
    if (regexpr('/', date_begin)[[1]] != -1) {
      stop(paste0("'date_begin' argument should be specified using the ",
                  "following format : \"%Y-%m-%d[ %H:%M[:%S]]\"."))
    }
    date_begin <- R39Toolbox::format_character_date(date_begin)
  }
  if ("character" %in% class(date_end)) {
    if (regexpr('/', date_end)[[1]] != -1) {
      stop(paste0("'date_end' argument should be specified using the ",
                  "following format : \"%Y-%m-%d[ %H:%M[:%S]]\"."))
    }
    date_end <- R39Toolbox::format_character_date(date_end)
  }
  # check that provided variables are ok
  all_variables <- c("date", "DateNum", "Annee", "Mois", "Jour", "Heure",
                     "Minute", "Instant", "Posan", "Tendance", "JourSemaine",
                     "JourFerie", "Ponts", "isoSemaine", "isoAnnee")
  # select default variables if none is provided
  if (is.null(variables)) {
    selected_variables <- NULL
  } else {
    selected_variables <- match.arg(variables, all_variables,
                                    several.ok = TRUE)
  }
  # check that ts divides a regular 24-hour day
  if ((24 * 60 * 60) %% ts != 0) {
    stop(paste0("Wrong value for 'ts' argument : must divide a regular ",
                "24-hour day"))
  }
  # if ts > 24 * 60 * 60, then assume hours, minutes and seconds are not
  # significant to the user, and use CET24 instead of CET to avoid having
  # half of the dataset at 00:00 and the other half at 23:00.
  orig_tz <- tz
  if ((tz == 'CET') && (ts >= 24 * 60 * 60)) {
    tz <- 'CET24'
  }

  # Generate date sequence ---------------------------
  check_cet24 <- FALSE
  if (tz == "CET24") {
    tz <- 'UTC'
    check_cet24 <- TRUE
  }
  if ("character" %in% class(date_begin)) {
    date_begin <- as.POSIXct(date_begin, format = "%Y-%m-%d %H:%M", tz = tz)
  } else if ("Date" %in% class(date_begin)) {
    date_begin <- as.POSIXct(
      as.character(date_begin), format = "%Y-%m-%d", tz = tz)
  }
  if ("character" %in% class(date_end)) {
    date_end   <- as.POSIXct(date_end, format = "%Y-%m-%d %H:%M", tz = tz)
  } else if ("Date" %in% class(date_end)) {
    date_end <- as.POSIXct(
      as.character(date_end), format = "%Y-%m-%d", tz = tz)
  }
  date_range <- as.POSIXlt(seq(from = date_begin, to = date_end, by = ts))
  if (!is.null(convention) && convention == 'end') {
    date_range2 <- date_range + ts
  } else {
    date_range2 <- date_range
  }

  # Generate custom variables ---------------------------
  # Default variables {"date", "Annee", "Mois", "Jour", "Heure", "Minute"}
  calendar <- data.frame(date  = date_range2,
                         Annee = (date_range$year + 1900L),
                         Mois  = (date_range$mon + 1L))
  # "Jour" variable
  if (ts > 24 * 60 * 60 & !is.null(convention)) {
    calendar$Jour <- NA
  } else {
    calendar$Jour <- date_range$mday
  }
  # "Heure" variable
  if (ts > 60 * 60 & !is.null(convention)) {
    calendar$Heure <- NA
  } else {
    calendar$Heure <- date_range$hour
  }
  # "Minute" variable
  if (ts > 60 & !is.null(convention)) {
    calendar$Minute <- NA
  } else {
    calendar$Minute <- date_range$min
  }

  unique_years <- unique(calendar$Annee)

  # "Instant" variable. Needed to later compute the "Posan" variable
  if (any(c("Posan", "Instant") %in% selected_variables)) {
    instant <- as.numeric(format(date_range, "%H%M%S"))
    reencode_instant <- data.frame(tmp_instant = sort(unique(instant)))
    reencode_instant$Instant <- 0:(nrow(reencode_instant) - 1)
    rownames(reencode_instant) <- reencode_instant$tmp_instant
    calendar$Instant <- reencode_instant[as.character(instant), "Instant"]
  }

  # "DateNum" variable
  if ("DateNum" %in% selected_variables) {
    calendar$DateNum <- format(date_range2, "%Y%m%d%H%M")
  }

  # "Posan" variable
  if ("Posan" %in% selected_variables) {
    n_days_year <- sapply(unique_years, R39Toolbox:::year_days)
    names(n_days_year) <- unique_years
    dates_in_instants <- (
      (date_range$yday * (max(calendar$Instant) + 1)) + calendar$Instant)
    n_instants_year <- (
      (n_days_year[as.character(calendar$Annee)] * 24 * (3600 / ts)) - 1)
    calendar$Posan <- dates_in_instants / n_instants_year
  }

  # "Tendance" (trend) variable
  if ("Tendance" %in% selected_variables) {
    calendar$Tendance <- as.numeric(date_range)
  }

  # "JourSemaine" (weekday) variable. Also needed for "Ponts"
  if (any(c("JourSemaine", "Ponts") %in% selected_variables)) {
    calendar$JourSemaine <- date_range$wday
  }

  # Deal with FR, PT, ..
  if (isTRUE(holidays %in% c("FR", "PT"))){
    holidays <- switch(
      holidays, FR = frenchHolidays(), PT = portugueseHolidays())
  }

  # "JourFerie" (days off). Also needed for "Ponts"
  if (any(c("JourFerie", "Ponts") %in% selected_variables)) {
    day_off <- rep(0L, nrow(calendar))
    jf <- sapply(holidays, do.call,
                 list(year = unique_years),
                 env = asNamespace("R39Toolbox"))

    data_date <- as.Date(date_range)

    sapply(names(jf), function(k) {
      ind_holidays <- which(data_date %in% as.Date(jf[[k]]@Data))
      if (length(ind_holidays) > 0) {
        day_off[ind_holidays] <<- 1
      }
    })
    calendar$JourFerie <- day_off
  }

  # "Ponts" (bridging days) variable
  if ("Ponts" %in% selected_variables) {
    # a raffiner
    data_tmp <- (
      calendar[-which(duplicated(calendar[, c("Annee", "Mois", "Jour")])),
               c("Annee", "Mois", "Jour", "JourSemaine", "JourFerie")])
    rownames(data_tmp) <- NULL
    if (dim(data_tmp)[[1]] == 0) {
      data_tmp <- calendar
    }

    mask_day_off  <- data_tmp[, "JourFerie"] == 1
    # thursday off => next friday is a bridging day
    mask_thursday <- data_tmp[, "JourSemaine"] == 4
    friday_bridge <- data_tmp[which(mask_day_off & mask_thursday) + 1, ]
    # tuesday off => previous monday is a bridging day
    mask_tuesday  <- data_tmp[, "JourSemaine"] == 2
    monday_bridge <- data_tmp[which(mask_day_off & mask_tuesday) - 1, ]

    bridging_days <- rbind(monday_bridge, friday_bridge)
    key_bridging_days <- paste(bridging_days$Annee, bridging_days$Mois,
                               bridging_days$Jour, sep = "-")
    key_dates <- paste(calendar$Annee, calendar$Mois, calendar$Jour, sep = "-")

    calendar$Ponts <- 0
    calendar$Ponts[key_dates %in% key_bridging_days] <- 1
  }


  if (any(c("isoAnnee", "isoSemaine") %in% selected_variables)) {
    # annee ISO et semaine ISO
    isoInfo <- R39Toolbox:::iso_week_year(
      as.POSIXlt(as.Date(date_range)), calendar$Annee)
    calendar$isoAnnee   <- isoInfo$ISOYear
    calendar$isoSemaine <- isoInfo$ISOWeek
  }

  ### Finalize calendar construction ---------------------------
  calendar <- calendar[, c(selected_variables), drop = FALSE]

  if (!keep_last) {
    calendar <- calendar[1:(dim(calendar)[[1]] - 1), ]
  }
  # convert to CET24 if needed
  if (check_cet24 & ("date" %in% names(calendar))) {
    calendar[, "date"]        <- format.POSIXct(calendar[, "date"],
                                                "%Y-%m-%d %H:%M:%S")
    class(calendar[, "date"]) <- "CET24"
  }

  if (("date" %in% names(calendar)) && (orig_tz == 'CET')
      && (ts >= 24 * 60 * 60)) {
    calendar[, "date"] <- as.POSIXct(
      as.character(calendar[, "date"]), tz = 'CET')
  }

  if (!is.null(convention) & ("date" %in% names(calendar))) {
    calendar <- R39Toolbox::set_date_convention(calendar, convention)
  }

  calendar
}


#' Create standard temperature variable
#'
#' Create standard temperature variable based on the French standard
#' temperature (mean of 32 whether stations).
#'
#' @param data : Date frame for which to generate a stnadard
#'               temperature variable. Once it is created, one can
#'               add it directly and manually to 'data' as a new
#'               column.
#'               One of the column in 'data' must be named 'date'
#'               and contain POSIXct elements.
#'
#' @return A vector that can directly be added to the original
#'         data frame 'data' that has been provided as input to
#'         the createStandardTemperatureVariable function.
#          The output might contain NA values in case a low time
#'         step (ts) is used in 'data'.
#'
#' @examples
#'
#' data <- R39Toolbox::R39ExData
#' data$StandardTemperature <- get_standard_temperature(data)
#'
#' @export
get_standard_temperature <- function(data) {
  # get dataset time properties (timezone, time sampling rate)
  date_control <- R39Toolbox::check_dates(data)

  # interpolation/extrapolation to match ts
  standard_temperature_data <- R39Toolbox::StandardTemperature
  ## standard_temperature_data <- R39Toolbox::switch_time_zone(
  ##   standard_temperature_data, target_timezone = date_control$tz)
  working_ts <- min(60 * 60, date_control$ts)
  standard_temperature_data <- R39Toolbox::resample(
    standard_temperature_data, target_timestep = working_ts)
  # drop last value ((day, month) equal to the first value's)
  standard_temperature_data <- (
    standard_temperature_data[1:(dim(standard_temperature_data)[[1]] - 1), ])

  # remove the year indication from dates of standard temperature for the merge
  if (date_control$tz == "CET24") {
    data$date.without.year <- substring(as.character(data$date), 6)
    standard_temperature_data$date.without.year <- substring(
      as.character(standard_temperature_data$date), 6)
  } else {
    data$date.without.year <- format(data$date, "%m-%d %H:%M:%S",
                                     tz = date_control$tz)
    standard_temperature_data$date.without.year <- format(
      standard_temperature_data$date, "%m-%d %H:%M:%S")
  }
  # merge 'data' and standard temperatures while preserving the same row number
  data$Temperature <- NULL  # prevent multiple Temperature columns in output
  temp <- base::merge(data, standard_temperature_data,
                      by = 'date.without.year', sort = FALSE, all.x = TRUE)
  # reoder columns
  if (date_control$tz == "CET24") {
    temp <- temp[order(as.character(temp$date.x)), ]
  } else {
    temp <- temp[order(temp$date.x), ]
  }

  temp$Temperature
}
