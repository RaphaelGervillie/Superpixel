#' @title BayesianRegularizedNNModel
#' @description fitting a BRNN model using the Toolbox gives you 
#' possibity to only choice the number of neurons,
#'  all others parametrs are fixed by default, reference to brnn package for more informations
#' @param target_variable the variable to predict
#' @param neurons the number of neurons.
#' @param formula a formula (optional)
#' @param fit_default R39Toolbox model parameter
#' @param fit.default R39Toolbox model parameter (deprecated)
#' @param transformation_function R39Toolbox model parameter
#'
#' @export
BayesianRegularizedNNModel <- function(target_variable = NULL,
                                       neurons = 2,
                                       formula = NULL,
                                       fit_default = list(),
                                       fit.default = NULL,
                                       seed = 27,
                                       transformation_function = NULL) {
  # <deprecated>
  if (!is.null(fit.default)
      && (class(fit_default) == "list") && length(fit_default) == 0) {
    fit_default <- fit.default
  }
  # </deprecated>
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable <- target_variable
  
  
  # algorithm parameters
  this$neurons <- neurons
  
  this$seed <- seed 
  if (!is.null(formula)) this$formula <- formula
  
  
  class(this) <- append(class(this), "BayesianRegularizedNNModel")
  return(this)
}


#' Estimation of a BayesianRegularizedNNModel
#'
#' @importFrom brnn brnn
#' @rdname fit
#' @export
fit.BayesianRegularizedNNModel <- function(model, data_train,
                                           bypass_transform = FALSE,
                                           leading_period = NULL,
                                           weights = NULL, by = NULL) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- model$fit_default[["by"]]
  }
  
  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }
  mask_train <- which(weights == 1)
  
  # TODO: check data_train columns are ok
  if (!is.null(model$formula)) {
    # fit by formula
    library(brnn)
    set.seed(model$seed)
    model$model_ <- brnn::brnn(as.formula(model$formula),
                               data = data_train, 
                               neurons =  model$neuron, 
                               verbose = FALSE)
    
  } else {
    # get the target index
    ind_target <- which(names(data_train) == 
                          model$target_variable)
    
    # fit with all columns other than target variable
    set.seed(model$seed)
    model$model_ <- brnn(x = as.matrix(
      data_train[mask_train, - ind_target]),
      y = data_train[mask_train, ][[model$target_variable]],
      neurons = model$neurons)
    
    # then record the explanatory_variables
    # for later prediction use
    model$explanatory_variables <- 
      names(data_train)[-ind_target]
  }
  
  return(model)
}




#' Prediction of the target variable from observations
#'
#' @importFrom brnn predict.brnn
#' @rdname predict
#' @method predict BayesianRegularizedNNModel
#' @export
predict.BayesianRegularizedNNModel <- function(model, data_prediction,
                                               bypass_transform = FALSE,
                                               leading_period = NULL) {
  library(brnn)
  
  if (is.null(model$formula)) {
    prediction <- predict(
      model$model_, as.matrix(data_prediction[, model$explanatory_variables]))
  } else {
    prediction <- predict(model$model_, data_prediction)
  }
  
  return(as.numeric(prediction))
}
