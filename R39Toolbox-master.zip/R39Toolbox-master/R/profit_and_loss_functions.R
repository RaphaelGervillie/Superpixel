# Supprime un warning de rcheck
globalVariables(c(".", "DONNEES_PANDL_TOOLBOX"))

DONNEES_PANDL_TOOLBOX <- new.env()


#' Charger une base MAPE pour utiliser les fonctions de calcul P&L
#'
#' @param path_to_base_mape chemin vers la base MAPE (chr)
#'
#' @importFrom dplyr select_at mutate lag filter
#' @importFrom utils head tail
#' @importFrom lubridate ymd_hm
#' @importFrom rlang .data
#'
#' @export
load_MAPE_base <- function(
  path_to_base_mape
) {
  
  start_time <- Sys.time()
  
  # Variables d'interet a extraire de MAPE
  variables_utiles <- c(
    "DATE",
    "INSTANT",
    "POINT_DEMI_HORAIRE_DEB",
    "ECART_FRANCE_RTE",
    "MIX_IJ",
    "REALISE_RE",
    "ECART_EDF",
    "PMPH",
    "PMPB",
    "PRIX_SPOT",
    "TENDANCE"
  )
  
  # Charger l'environnement de la base MAPE
  envir_MAPE <- new.env()
  load(path_to_base_mape, envir_MAPE, verbose = FALSE)
  
  # Premiers traitements
  EntrepotConso <- select_at(
    envir_MAPE$EntrepotConso,
    variables_utiles
  )
  
  EntrepotConso <- mutate(
    EntrepotConso,
    # On produit un MIX en puissance moyenne pour créer l'écart EDF
    # en énergie
    MIX_IJ_LAG = lag(.data$MIX_IJ, 1),
    MIX_IJ_MOY = (.data$MIX_IJ + .data$MIX_IJ_LAG) / 2,
    ECART_EDF_MIX = (.data$MIX_IJ_MOY - .data$REALISE_RE) / 2
  )
  
  # Créer date CET. Warnings connus : failed to parse (format 24/24)
  suppressWarnings(
    EntrepotConso <- mutate(
      EntrepotConso,
      date = ymd_hm(paste(.data$DATE, .data$POINT_DEMI_HORAIRE_DEB), tz="CET")
    ) %>% 
      # On retire les dates invalidées (changements d'heure dupliqués)
      filter(!is.na(.data$date))
  )
  
  # Ceci est stocké dans une variable globale
  DONNEES_PANDL_TOOLBOX$mape_data <- EntrepotConso
  
  end_time <- Sys.time()
  
  message("Base MAPE loaded in ", round(as.double(end_time - start_time, units="secs"), 2), "s.")
  message("First date : ", head(get_loaded_MAPE_base()$date, 1))
  message("Last date : ", tail(get_loaded_MAPE_base()$date, 1))
}

#' Recuperer la base MAPE chargee en session
#'
#' @return data.frame
#' @export
get_loaded_MAPE_base <- function() {
  
  # Vérifier que les données du package sont chargées
  if (is.null(DONNEES_PANDL_TOOLBOX$mape_data)) {
    stop("MAPE base is not loaded. Use load_MAPE_base to load a MAPE base first (once per session).")
  }
  
  DONNEES_PANDL_TOOLBOX$mape_data
}

#' Remplacer la base MAPE chargee en session
#'
#' @param mape_data Base de remplacement
#'
#' @return data.frame
#' @export
set_loaded_MAPE_base <- function(mape_data) {
  DONNEES_PANDL_TOOLBOX$mape_data <- mape_data
}

#' Calcule l'écart France simulé d'après les prévisions
#'
#' @param imbalance_to_cancel écart à annuler à l'écart France (MWh)
#' @param imbalance_to_add écart à ajouter à l'écart France (MWh)
#' @param france_imbalance écart France (MWh)
#'
#' @return vecteur
compute_simulated_france_imbalance <- function(
  imbalance_to_cancel,
  imbalance_to_add,
  france_imbalance
) {
  
  france_imbalance - imbalance_to_cancel + imbalance_to_add
  
}


#' Calcule le prix de règlement des écarts en fonction de l'écart France et des PMP
#'
#' @param france_imbalance écart France (MWh)
#' @param prix_SPOT prix SPOT (€)
#' @param PMPH prix moyen pondéré à la hausse (€)
#' @param PMPB prix moyen pondéré à la baisse (€)
#' @param k_regl_ecarts k du règlement des écarts (typiquement 0.08 ou 0.05)
#'
#' @importFrom dplyr case_when
#'
#' @return data.frame(PRP, PRN)
#' @export
compute_imbalance_settlement_price <- function(
  france_imbalance,
  prix_SPOT,
  PMPH,
  PMPB,
  k_regl_ecarts
) {
  
  message("Computing imbalance settlement prices")
  message("Using rule: Single Price, k=", k_regl_ecarts)
  
  # Single price
    
  PRN <- case_when(
    # Tendance à la hausse
    france_imbalance <  0 ~ pmax(PMPH*(1+k_regl_ecarts), PMPH*(1-k_regl_ecarts)),
    # Tendance à la baisse
    france_imbalance >= 0 ~ pmax(PMPB*(1+k_regl_ecarts), PMPB*(1-k_regl_ecarts)),
    # Autre cas
    TRUE ~ as.numeric(NA)
  )
  
  PRP <- case_when(
    is.na(france_imbalance) ~ as.numeric(NA),
    # Tendance à la hausse
    france_imbalance <  0 ~ pmin(PMPH*(1+k_regl_ecarts), PMPH*(1-k_regl_ecarts)),
    # Tendance à la baisse
    france_imbalance >= 0 ~ pmin(PMPB*(1+k_regl_ecarts), PMPB*(1-k_regl_ecarts)),
    # Autre cas
    TRUE ~ as.numeric(NA)
  )
  
  return(data.frame(PRP = PRP, PRN = PRN))
}

#' Calcule le PandL pour le RE
#'
#' @param PRP prix règlement des écarts positifs (€)
#' @param PRN prix règlement des écarts négatifs (€)
#' @param prix_SPOT prix SPOT (€)
#' @param ecart_RE écart RE (MWh)
#' 
#' @importFrom dplyr case_when
#'
#' @return vecteur
compute_PandL <- function(
  PRP,
  PRN,
  prix_SPOT,
  ecart_RE
) {
  
  PandL <- case_when(
    ecart_RE >  0 ~ ecart_RE * (PRP - prix_SPOT),
    ecart_RE <= 0 ~ ecart_RE * (PRN - prix_SPOT),
    TRUE ~ as.numeric(NA)
  )
  
  return(PandL)
}


#' Actualise les colonnes d'écart et de prix en fonction d'une prev et d'un réalisé.
#' L'écart MIX_IJ_MOY - REALISE_RE est annulé et remplacé par l'écart lié aux
#' prev et realise fournis.
#'
#' @param prev prévision en puissance moyenne (MW)
#' @param realise réalisé en puissance moyenne (MW)
#' @param france_imbalance écart France (MWh)
#' @param imbalance_to_cancel écart RE à annuler (MWh)
#' @param prix_SPOT prix SPOT (€)
#' @param PMPH prix moyen pondéré à la hausse (€)
#' @param PMPB prix moyen pondéré à la baisse (€)
#' @param k_regl_ecarts k du règlement des écarts (typiquement 0.08 ou 0.05)
#'
#' @return data.frame
refresh_system_state <- function(
  prev,
  realise,
  france_imbalance,
  imbalance_to_cancel,
  prix_SPOT,
  PMPH,
  PMPB,
  k_regl_ecarts
) {
  
  # 1. Calculer le nouvel écart RE (MWh)
  ecart_RE <- (prev - realise) / 2.0
  
  # 2. Simuler l'écart France
  france_imbalance_simule <- compute_simulated_france_imbalance(
    imbalance_to_cancel = imbalance_to_cancel,
    imbalance_to_add = ecart_RE,
    france_imbalance = france_imbalance
  )
  
  # 3. Recalculer les prix
  prix <- compute_imbalance_settlement_price(
    # On utilise le nouvel écart France
    france_imbalance = france_imbalance_simule,
    prix_SPOT = prix_SPOT,
    PMPH = PMPH,
    PMPB = PMPB,
    k_regl_ecarts = k_regl_ecarts
  )
  
  # 4. Calculer PandL
  PandL <- compute_PandL(
    PRP = prix$PRP,
    PRN = prix$PRN,
    prix_SPOT = prix_SPOT,
    ecart_RE = ecart_RE
  )
  
  return(
    data.frame(
      ecart_RE = ecart_RE,
      france_imbalance_simule = france_imbalance_simule,
      PRP = prix$PRP,
      PRN = prix$PRN,
      PandL = PandL
    )
  )
}


#' Calcule le PandL conso en simulant l'écart France, le prix du règlement des écarts
#' (en Single ou Dual Price).
#'
#' @param dates_CET Vecteur de dates au format POSIXct (tz = CET)
#' @param prevision Vecteur de valeurs de prévision en puissance moyenne (MW)
#' @param realise Vecteur de valeurs de réalisés en puissance moyenne (MW)
#' @param k_regl_ecarts k du règlement des écarts (0.08 jusqu'au 31/12/2018, 0.05 à partir du 01/01/2019)
#' @param variables Parmi c("PandL", "PRP", "PRN", "PRIX_SPOT", "ecart_RE", "france_imbalance_simule")
#'
#' @importFrom dplyr left_join distinct bind_cols pull
#' @importFrom magrittr %>% 
#' 
#' @return Vecteur si variables est de longueur 1 ; sinon, data.frame
#' @export
compute_PandL_conso <- function(
  dates_CET, 
  prevision, 
  realise, 
  k_regl_ecarts,
  variables = c("PandL")
) {
  
  d <- data.frame(
    date = dates_CET,
    prevision = prevision,
    realise = realise
  ) %>% 
    left_join(
      distinct(get_loaded_MAPE_base(), date, .keep_all=TRUE),
      by="date"
    ) %>% 
    bind_cols(
      refresh_system_state(
        prev = prevision,
        realise = realise,
        france_imbalance = .$ECART_FRANCE_RTE,
        imbalance_to_cancel = .$ECART_EDF_MIX,
        prix_SPOT = .$PRIX_SPOT,
        PMPH = .$PMPH,
        PMPB = .$PMPB,
        k_regl_ecarts = k_regl_ecarts
      )
    )
  
  if (length(variables) == 1) {
    d1 <- d %>% 
      pull(variables)
  } else {
    d1 <- d %>% 
      select_at(variables)
  }
  
  d1
}


#' Calcule le P&L du RE EDF (application formule P&L conso sur l'écart RE)
#'
#' @param dates_CET Vecteur de dates au format POSIXct (tz = CET)
#' @param k_regl_ecarts k du règlement des écarts
#'
#' @importFrom dplyr distinct
#' @importFrom magrittr %>% 
#'
#' @return Vecteur
#' @export
get_RE_historical_PandL <- function(
  dates_CET, 
  k_regl_ecarts
) {
  
  mape_data <- left_join(
    data.frame(
      date = dates_CET
    ),
    distinct(get_loaded_MAPE_base(), date, .keep_all=TRUE),
    by="date"
  )
  
  # 3. Recalculer les prix
  prix <- compute_imbalance_settlement_price(
    france_imbalance = mape_data$ECART_FRANCE_RTE,
    prix_SPOT = mape_data$PRIX_SPOT,
    PMPH = mape_data$PMPH,
    PMPB = mape_data$PMPB,
    k_regl_ecarts = k_regl_ecarts
  )
  
  mape_data <- mutate(
    mape_data,
    PRP=prix$PRP,
    PRN=prix$PRN
  )
  
  # 4. Calculer PandL
  mape_data <- mutate(
    mape_data,
    PandL = compute_PandL(
      PRP = mape_data$PRP,
      PRN = mape_data$PRN,
      prix_SPOT = mape_data$PRIX_SPOT,
      ecart_RE = mape_data$ECART_EDF
    )
  )
  
  mape_data$PandL
}

#' Calcule le P&L conso du MIX historique (application formule P&L conso sur l'écart conso du MIX historique)
#'
#' @param dates_CET Vecteur de dates au format POSIXct (tz = CET)
#' @param k_regl_ecarts k du règlement des écarts
#'
#' @importFrom dplyr distinct
#' @importFrom magrittr %>% 
#'
#' @return Vecteur
#' @export
get_MIX_historical_PandL <- function(
  dates_CET, 
  k_regl_ecarts
) {
  
  mape_data <- left_join(
    data.frame(
      date = dates_CET
    ),
    distinct(get_loaded_MAPE_base(), date, .keep_all=TRUE),
    by="date"
  )
  
  # 3. Recalculer les prix
  prix <- compute_imbalance_settlement_price(
    france_imbalance = mape_data$ECART_FRANCE_RTE,
    prix_SPOT = mape_data$PRIX_SPOT,
    PMPH = mape_data$PMPH,
    PMPB = mape_data$PMPB,
    k_regl_ecarts = k_regl_ecarts
  )
  
  mape_data <- mutate(
    mape_data,
    PRP=prix$PRP,
    PRN=prix$PRN
  )
  
  # 4. Calculer PandL
  mape_data <- mutate(
    mape_data,
    PandL = compute_PandL(
      PRP = mape_data$PRP,
      PRN = mape_data$PRN,
      prix_SPOT = mape_data$PRIX_SPOT,
      ecart_RE = mape_data$ECART_EDF_MIX
    )
  )
  
  mape_data$PandL
}
