#' Check if a model is fit
#'
#' R39Toolbox's models, once fitted, have their attribute $model_ filled 
#' with the raw model from which it is build on (i.e. an mgcv object in the
#' case of a GeneralizedAdditiveModel). In some specific cases, we have no
#' underlying model and "fit->ok" is put as a surrogate. Thus, in order to know
#' if a model has been fit, one can be tempted to write something similar to
#' if (model$model_ %in% "fit->ok") { ... }., the search for
#' "fit->ok" in a list can take a very long time when using the intuitive
#' alternative for match, %in%. This function is here to prevent this loss 
#' of time.
#'
#' @details We iterate over all the element under model$model_ to find
#' if "fit->ok" is in. In this case a simple for loop correct the latency one
#' can observed.
#'
#' @param model The model to be scanned
#'
#' @return boolean indicating whether "fit->ok" is present
#' @export
has_empty_alphas <- function(model) {
    if (class(model$model_) == "list") {
        #here we search for the length of each element in model$model_
        number_of_sub_model <- lengths(model$model_)
        #here we search for the total length of model$model_
        list_length <- length(model$model_)
        for (i in 1:list_length) {
            if (number_of_sub_model[i] != 0) {
                #if length is greater than one "fit->ok" is not here
                if (length(model$model_[[i]]$fit_default) == 1) {
                    if (model$model_[[i]]$fit_default == "fit->ok") {
                        return(TRUE)
                    }
                }
            }
        }
        return(FALSE)
    } else {
        return("fit->ok" %in% model$model_)
    }
}
