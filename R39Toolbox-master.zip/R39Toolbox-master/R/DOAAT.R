# In this file, we define variables that are specific to DOAAT's needs.
# They can be day types, breaks or anything else.
# Ideally, they should be moved to another package that would gather all
# DOAAT-specific processings.

#' Set an interval presentation associated with dates
#'
#' Most of the datasets that are used with R39Toolbox have a 'date' column
#' the purpose of which is to associate observations to a time point.
#' Energy data often need to be matched to a period of time instead of a
#' single timestamp. However, experts still use a single date to represent
#' the whole period. This implicit knowledge can lead to discrepancies in
#' the data. DOAAT specificaly uses a representation that is different
#' from EDF's divisions: the date that is provided refers to the end
#' time point of the period (i.e. an observation tagged with 07:00 is actually
#' a quantity measuured between 06:30 and 07:00).
#' We provide a set of functions that should be used to switch from a
#' representation to another. Most of the functions related to DOAAT will fail
#' if they are not applied on a dataset for which an explicit representation
#' has been chosen.
#'
#' caveat: only works on datasets with regular timestep.
#'
#' @param data : Dataset we want to define a representation for.
#' @param convention : Representation that should be considered.
#'                     (can be "begin", "end", or "none").
#'
#' @return The input dataset with the date convention set.
#'
#' @export
set_date_convention <- function(data, convention) {
  # check that a 'date' column does exist + get info about it
  date_control <- R39Toolbox::check_dates(data)
  if (date_control$ts == "non-uniform") {
    stop("This function only works for data with uniform timestep.")
  }

  # is a convention already set?
  actual.convention <- attr(data, 't')

  # apply the wanted representation
  if (is.null(actual.convention)) {
    attr(data, 't') <- convention
  } else if (actual.convention != convention) {
    if (convention == 'end') {
      date_offset <- 1
    } else {
      date_offset <- -1
    }
    # add 'ts' to each date
    if (date_control$tz == 'CET24') {
      # use UTC instead
      dates_utc <- as.POSIXct(as.character(data$date),
                              format = "%Y-%m-%d %H:%M:%S", tz = 'UTC')
      dates_utc <- dates_utc + date_offset * date_control$ts
      # go back to CET24
      data$date <- strftime(dates_utc, "%Y-%m-%d %H:%M:%S", tz = 'UTC')
      class(data$date) <- "CET24"
    } else {
        data$date <- data$date + date_offset * date_control$ts
    }
    # set 't' attr
    attr(data, 't') <- convention
  }

  data
}

#' DOAAT's (short-term) daytype computation
#'
#' DOAAT's short-term day types are only defined for half-hourly
#' datasets. It is not allowed to use this function with another
#' timestep.
#'
#' Date format compatibility:
#' We consider that the reference is CET24, that is DOAAT's date format.
#' If we pass a dataset with another date format, say, corresponding to
#' another country, we still get the daytype *as DOAAT gets it* in the
#' meanwhile. At each time point, we have the value of the daytype as seen by
#' DOAAT at the exact same universal time.
#'
#' @param data : data.frame, with at least columns 'date'
#'               in POSIXct (with tz attribute), or CET24 (character) format
#'               or a column of type 'Date'
#'
#' @return Vector corresponding to DOAAT's short-term day types
#'
#' @export
generate_daytype_DOAAT_CT <- function(data) {
  # check that the dataset has a date convention set
  convention <- attr(data, 't')
  if (is.null(convention)) {
    stop(paste0("Les traitements DOAAT necessitent de choisir une ",
                "convention pour l'association entre les dates et les ",
                "autres variables (convention commencante ou finissante). ",
                "Aucune convention n'est associee au jeu de donnees actuel. ",
                "Merci d'utiliser la fonction 'set_date_convention' ",
                "pour preciser la convention a utiliser."))
  }
  # check that a 'date' column does exist + get info about it
  date_control <- R39Toolbox::check_dates(data)
  if (date_control$ts != 30 * 60) {
    stop("Erreur seul le format demi-horaire est supporte")
  }

  if (convention == 'end') {
    if (date_control$tz != 'CET24') {
      date_begin <- data$date[[1]] - date_control$ts
      date_end   <- tail(data$date, 1) - date_control$ts
    } else {
      date_begin <- as.POSIXct(data$date[[1]], format = "%Y-%m-%d %H:%M:%S")
      date_end   <- as.POSIXct(as.character(tail(data$date, 1)),
                               format = "%Y-%m-%d %H:%M:%S")
      date_begin <- strftime(date_begin - date_control$ts,
                             format = "%Y-%m-%d %H:%M:%S")
      date_end   <- strftime(date_end - date_control$ts,
                             format = "%Y-%m-%d %H:%M:%S")
    }
  } else {
    if (date_control$tz != 'CET24') {
      date_begin <- data$date[[1]]
      date_end   <- tail(data$date, 1)
    } else {
      date_begin <- as.character(data$date[[1]])
      date_end   <- as.character(tail(data$date, 1))
    }
  }
  date_begin <- as.character(date_begin, tz = 'CET')
  date_end   <- as.character(date_end, tz = 'CET')
  date_begin <- R39Toolbox::format_character_date(date_begin, verbose = FALSE)
  date_end   <- R39Toolbox::format_character_date(date_end, verbose = FALSE)
  if (date_control$tz != 'CET24') {
    working_timezone <- date_control$tz
  } else {
    working_timezone <- 'UTC'
  }
  # create 'JourSemaine' and 'Month' variables
  calendar <- R39Toolbox::generate_calendar(
    date_begin, date_end, ts = 30 * 60, tz = working_timezone,
    variables = c('JourSemaine', 'Mois'), convention = convention)

  daytype_doaat <- calendar$JourSemaine
  # July/August Sunday --> 7
  sunday_july_august <- which((calendar$JourSemaine == 0)
                               & (calendar$Mois %in% 7:8))
  if (length(sunday_july_august) > 0) {
    daytype_doaat[sunday_july_august] <- 7L
  }
  # December Sunday --> 8
  sunday_december <- which((calendar$JourSemaine == 0)
                           & (calendar$Mois == 12))
  if (length(sunday_december) > 0) {
    daytype_doaat[sunday_december] <- 8L
  }

  daytype_doaat
}

#' Offset variable for DOAAT studies
#'
#' Default offset is 0.
#' From summer daylight saving time switch (included) to September 1st
#' (not included) --> 1
#' From September 1st (included) to winter daylight saving time switch
#' (not included) --> 2
#'
#' DOAAT's offsets are ony defined for half-hourly datasets.
#' It is not allowed to use this function with another timestep.
#'
#' Date format compatibility:
#' We consider that the reference is CET24, that is DOAAT's date format.
#' If we pass a dataset with another date format, say, corresponding to
#' another country, we still get the offset *as DOAAT gets it* in the
#' meanwhile. At each time point, we have the value of the offset as seen by
#' DOAAT at the exact same universal time.
#'
#' @param data : data.frame, with at least columns 'date'
#'               in POSIXct (with tz attribute), or CET24 (character) format
#'               or a column of type 'Date',
#'               and a column for InstantModele (optional),
#' @param convention : convention used ('begin' or 'end')
#'
#' @return Vector corresponding to DOAAT's offsets
#'
#' @export
generate_offset_DOAAT <- function(data) {
  # check that the dataset has a date convention set
  convention <- attr(data, 't')
  if (is.null(convention)) {
    stop(paste0("Les traitements DOAAT necessitent de choisir une ",
                "convention pour l'association entre les dates et les ",
                "autres variables (convention commencante ou finissante). ",
                "Aucune convention n'est associee au jeu de donnees actuel. ",
                "Merci d'utiliser la fonction 'set_date_convention' ",
                "pour preciser la convention a utiliser."))
  }
  # check that a 'date' column does exist + get info about it
  date_control <- R39Toolbox::check_dates(data)
  if (date_control$ts != 30 * 60) {
    stop("Erreur seul le format demi-horaire est supporte")
  }

  if (convention == "end") {
    offset_convention <- date_control$ts
  } else {
    offset_convention <- 0
  }
  if (date_control$tz != 'CET24') {
    date_begin <- data$date[[1]] - offset_convention
    date_end   <- tail(data$date, 1) - offset_convention
  } else {
    if (convention == 'end') {
      date_begin <- as.POSIXct(data$date[[1]], format = "%Y-%m-%d %H:%M:%S")
      date_end   <- as.POSIXct(as.character(tail(data$date, 1)),
                               format = "%Y-%m-%d %H:%M:%S")
      date_begin <- strftime(date_begin - offset_convention,
                             format = "%Y-%m-%d %H:%M:%S")
      date_end   <- strftime(date_end - offset_convention,
                             format = "%Y-%m-%d %H:%M:%S")
    } else {
      date_begin <- as.character(data$date[[1]])
      date_end   <- as.character(tail(data$date, 1))
    }
  }
  date_begin <- R39Toolbox::format_character_date(date_begin, verbose = FALSE)
  date_end   <- R39Toolbox::format_character_date(date_end, verbose = FALSE)
  # create 'Annee' and 'Instant' variables
  calendar <- R39Toolbox::generate_calendar(
    date_begin, date_end, ts = 30 * 60, tz = date_control$tz,
    variables = c('date', 'Annee'))

  offset_doaat <- as.integer(rep(0, nrow(data)))  # default offset is 0
  for (year in unique(calendar$Annee)) {
    # daylight saving change days (CET format)
    saving_days <- R39Toolbox::hour_change_year(year)
    date_hour_change_winter <- saving_days[[1]]
    date_hour_change_summer <- saving_days[[2]]
    # September 1st, 00:00 (CET)
    date_september_first <- as.POSIXct(paste0(year, "-09-01 00:00:00"),
                                       format = "%Y-%m-%d %H:%M:%S",
                                       tz = "CET")
    # shift key dates if "convention == 'end'"
    if (convention == "end") {
      date_hour_change_winter <- date_hour_change_winter + 30 * 60
      date_hour_change_summer <- date_hour_change_summer + 30 * 60
      date_september_first    <- date_september_first    + 30 * 60
    }
    # deal with CET24 case
    if (date_control$tz == 'CET24') {
      date_hour_change_winter <- strftime(
        date_hour_change_winter, format = "%Y-%m-%d %H:%M:%S")
      date_hour_change_summer <- strftime(
        date_hour_change_summer, format = "%Y-%m-%d %H:%M:%S")
      date_september_first    <- strftime(
        date_september_first, format = "%Y-%m-%d %H:%M:%S")
    }

    ### Actual offset computation
    # offset 1: summer daylight saving time switch to Sept. 1st (not included)
    offset_doaat[(data$date  >= date_hour_change_summer)
                 & (data$date < date_september_first)] <- 1L
    # offset 2: September 1st (included) to winter daylight saving time switch
    offset_doaat[(data$date  >= date_september_first)
                 & (data$date < date_hour_change_winter)] <- 2L
  }

  offset_doaat
}


#' Break periods for DOAAT's studies
#'
#' @param data : data.frame, with at least columns 'date'
#'               in POSIXct (with tz attribute), or CET24 (character) format
#'               or a column of type 'Date',
#'               and a column for InstantModele (optional),
#' @param convention : convention used ('begin' or 'end')
#' @param horizon : CT or MT (defaut CT)
#'
#' @return Vector corresponding to DOAAT's breaks
#'
#' @export
generate_break_DOAAT <- function(data, horizon = "CT")
{
  # check that the dataset has a date convention set
  convention <- attr(data, 't')
  if (is.null(convention)) {
    stop(paste0("Les traitements DOAAT necessitent de choisir une ",
                "convention pour l'association entre les dates et les ",
                "autres variables (convention commencante ou finissante). ",
                "Aucune convention n'est associee au jeu de donnees actuel. ",
                "Merci d'utiliser la fonction 'set_date_convention' ",
                "pour preciser la convention a utiliser."))
  }
  # check that a 'date' column does exist + get info about it
  date_control <- R39Toolbox::check_dates(data)
  if (date_control$ts != 30 * 60) {
    stop("DOAAT's break only defined for half-hourly datasets")
  }

  # create 'Annee', 'Instant' and 'JourFerie' variables
  calendar <- R39Toolbox::generate_calendar(
    data$date[[1]], data$date[[nrow(data)]],
    ts = 30 * 60, tz = date_control$tz,
    holidays = c(timeDate::listHolidays(pattern = "*FR"),
      "NewYearsDay", "Easter", "EasterMonday", "LaborDay",
      "Pentecost", "PentecostMonday", "ChristmasDay"),
    variables = c('date', 'Annee', 'Instant', 'JourFerie'))

  instant.chgt <- 5:8
  if (convention == "end") {
    offset_convention <- 30 * 60
  } else {
    offset_convention <- 0
  }

  break_doaat <- rep(1, nrow(data))  # default value is 1
  for (year in unique(calendar$Annee)) {
    # daylight saving change days (CET format)
    saving_days <- R39Toolbox::hour_change_year(year)
    date_hour_change_winter <- saving_days[[1]] + offset_convention
    date_hour_change_summer <- saving_days[[2]] + offset_convention
    date_hour_change_winter <- strftime(
      date_hour_change_winter, format = "%Y-%m-%d")
    date_hour_change_summer <- strftime(
      date_hour_change_summer, format = "%Y-%m-%d")

    # daylight saving time switch instants
    if (date_control$tz == 'CET24') {
      date_day <- as.vector(
        t(as.data.frame(strsplit(calendar$date, ' '))[1, ]))
    } else {
      date_day <- strftime(calendar$date, format = "%Y-%m-%d")
    }
    ind <- which(
      (calendar$Instant %in% instant.chgt)
      & (date_day %in% c(date_hour_change_winter, date_hour_change_summer)))
    break_doaat[ind] <- 0

    ###################################################################
    # Christmas period: December 21st to January 4th
    ###################################################################
    date_begin1 <- as.POSIXct(paste0(year, "-01-01 00:00:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    date_end1   <- as.POSIXct(paste0(year, "-01-05 00:00:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    date_begin2 <- as.POSIXct(paste0(year, "-12-21 00:00:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    date_end2   <- as.POSIXct(paste0(year, "-12-31 23:30:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    if (date_control$tz == 'CET24') {
      date_begin1 <- strftime(date_begin1, format = "%Y-%m-%d %H:%M:%S")
      date_end1   <- strftime(date_end1, format = "%Y-%m-%d %H:%M:%S")
      date_begin2 <- strftime(date_begin2, format = "%Y-%m-%d %H:%M:%S")
      date_end2   <- strftime(date_end2, format = "%Y-%m-%d %H:%M:%S")
    }
    break1 <- which((calendar$date >= date_begin1)
                    & (calendar$date < date_end1))
    if (length(break1) > 0) {
      break_doaat[break1] <- 0
    }
    break2 <- which((calendar$date >= date_begin2)
                    & (calendar$date <= date_end2))
    if (length(break2) > 0) {
      break_doaat[break2] <- 0
    }

    ###################################################################
    # Summer period: July 28th to September 5th
    ###################################################################
    date_begin <- as.POSIXct(paste0(year, "-07-28 00:00:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    date_end   <- as.POSIXct(paste0(year, "-09-06 00:00:00"),
                              format = "%Y-%m-%d %H:%M:%S",
                              tz = "CET") + offset_convention
    if (date_control$tz == 'CET24') {
      date_begin <- strftime(date_begin, format = "%Y-%m-%d %H:%M:%S")
      date_end   <- strftime(date_end, format = "%Y-%m-%d %H:%M:%S")
    }
    break_summer <- which((calendar$date >= date_begin)
                          & (calendar$date < date_end))
    if (length(break_summer) > 0) {
      break_doaat[break_summer] <- 0
    }
  }
  ########################################################################
  # Days off (+ day before and day after if short-term is considered)
  ########################################################################
  if (horizon == "CT") {
    days_off <- which(calendar$JourFerie == 1) + offset_convention / (30 * 60)
    break_doaat[days_off] <- 0
    # days before day-off
    days_before_day_off <- days_off - 48
    days_before_day_off <- days_before_day_off[days_before_day_off > 0]
    break_doaat[days_before_day_off] <- 0
    # days after day-off
    days_after_day_off <- days_off + 48
    days_after_day_off <- days_after_day_off[days_after_day_off
                                             <= nrow(calendar)]
    break_doaat[days_after_day_off] <- 0
  }

  break_doaat
}

#' Preprocessing DOAAT csv file into an R39Toolbox compatible dataframe
#'
#' This functions allows the conversion of a dataframe from a "DOAAT format"
#' style into one that can be use by the R39Toolbox package functions.
#'
#' @param chemin_donnees : file Path to the file to be read
#'
#' @details The following columns will be returned with the
#' following types:
#'
#' @details Year        -> type = character
#' @details Month       -> type = character
#' @details Dat         -> type = character
#' @details Instant     -> type = integer
#' @details Offset      -> type = integer
#' @details DayType     -> type = integer
#' @details Temperature -> type = numeric
#' @details Disruption  -> type = numeric
#'
#' @return Dataset ready to be use with R39Toolbox
#'
#' @export
read_doaat_file <- function(chemin_donnees) {
  tmp <- read.table(chemin_donnees, header = TRUE, sep = "\t")
  transform(
    tmp,
    Year        = as.character(tmp$Year),
    Month       = as.character(tmp$Month),
    Day         = as.character(tmp$Day),
    Instant     = as.integer(tmp$Instant),
    Offset      = as.integer(tmp$Offset),
    DayType     = as.integer(tmp$DayType),
    Temperature = as.numeric(tmp$Temperature),
    Disruption  = as.numeric(tmp$Disruption))
}


#' Preprocessing DOAAT csv file into an R39Toolbox-compatible dataframe
#'
#' This functions allows the conversion of a dataframe from a "DOAAT format"
#' style into one that can be use by the R39Toolbox package functions.
#'
#' @param chemin_cibles : file Path to the file to be read
#'
#' @details The following columns will be returned with the
#' following types:
#'
#' @details Year                -> type = character
#' @details Cible_Glob          -> type = integer
#' @details Cible_Chauffage     -> type = integer
#' @details Cible_Climatisation -> type = integer
#'
#' @return Dataset ready to be use with R39Toolbox
#'
#' @export
read_doaat_targets <- function(chemin_cibles) {
  tmp <- read.csv(chemin_cibles, header = TRUE, sep = ";")
  transform(
    tmp,
    Year                = as.character(Year),
    Cible_Glob          = as.integer(Cible_Glob),
    Cible_Chauffage     = as.integer(Cible_Chauffage),
    Cible_Climatisation = as.integer(Cible_Climatisation))
}


#' @export
simulate_DOAAT <- function(model, data_simulation,
                           bypass_transform = FALSE,
                           leading_period = NULL,
                           update_frequency = NULL,
                           launch_frequency = NULL,
                           delay = 1, horizon = 0,
                           verbose = FALSE,
                           output_model = FALSE,
                           save_history = FALSE,
                           use_history = FALSE,
                           ...) {

  update_model <- function(model, from, to, data_simulation,
                           delay, bypass_transform, save_history = FALSE,
                           leading_period = NULL, verbose = FALSE) {
    fit_block_start <- from - delay
    fit_block_end   <- to - delay
    if ((fit_block_end > 0) && (fit_block_start <= fit_block_end)) {
      mask_fit <- 1:fit_block_end
      leading_period_tmp  <- rep(0, fit_block_end)
      if (fit_block_start > 0) {
        leading_period_tmp[1:fit_block_start] <- 1
      }
      leading_period_tmp[leading_period[mask_fit] == 1] <- 1
      weights <- rep(1, fit_block_end)
      if (verbose) {
        if (length(which(leading_period_tmp == 0)) > 0) {
          start_date <- head(
            data_simulation[mask_fit, c('date')][leading_period_tmp == 0], 1)
        } else {
          start_date <- head(
            data_simulation[mask_fit, c('date')][leading_period_tmp == 0], 1)
        }
        message(
          paste0(
            "Fitting model from ",
            head(data_simulation[mask_fit, c('date')][leading_period_tmp == 0], 1),
            " to ",
            data_simulation$date[fit_block_end], "."))
      }
      if (save_history) {
        hist <- data_simulation$date[[fit_block_end]]
      } else {
        hist <- NULL
      }
      model <- R39Toolbox::fit(
        model, data_simulation[mask_fit, ],
        leading_period = leading_period_tmp, weights = weights,
        bypass_transform = bypass_transform, hist = hist)
    }

    model
  }

  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_simulation)

  launch_ind <- R39Toolbox:::check_frequency(
    launch_frequency, data_simulation, leading_period)
  if (!is.null(update_frequency) && update_frequency == 0) {
    update_ind <- 0
  } else {
    update_ind <- R39Toolbox:::check_frequency(
      update_frequency, data_simulation, leading_period)
  }

  simulation <- rep(NA, nrow(data_simulation))
  start_simulation <- which(leading_period == 0)[[1]]
  s1 <- unique(c(start_simulation, launch_ind, nrow(data_simulation) + 1))
  s1_map <- Map(c, s1[-length(s1)], s1[-1])
  last_update_pos <- 1  # keep track of the last model update date
  for (i in s1_map) {
    # Update the model if the launch date corresponds to an update date
    # (exception though: do not perform an update on the first launch date)
    if ((i[[1]] %in% update_ind) && (i[[1]] != s1[[1]])) {
      model2 <- update_model(
        model,
        1, #start_simulation,
        i[[1]], data_simulation,
        delay, bypass_transform, save_history = save_history,
        leading_period = leading_period, verbose = verbose)
      last_update_pos <- i[[1]]
    } else {
      model2 <- model
    }

    # Prediction
    # use all the data available before the current time
    predict_block_end <- min(i[[2]] - 1 + horizon, nrow(data_simulation))
    mask_prediction <- 1:predict_block_end
    # leading period corresponds to the period on which we have observations
    leading_period_tmp   <- rep(0, predict_block_end)
    if ((i[[1]] - delay) >= 1) {
      leading_period_tmp[1:(i[[1]] - delay)] <- 1
    }
    # target perdiod corresponds to the moments we want to forecast
    target_period   <- rep(0, predict_block_end)
    if ((i[[1]] + horizon) <= predict_block_end) {
      target_period[(i[[1]] + horizon):predict_block_end] <- 1
    }
    # split data
    data_simulation_tmp <- data_simulation[mask_prediction, , drop = FALSE]
    # perform prediction
    if (length(which(leading_period_tmp == 0)) > 0) {
      data_simulation_tmp[[model$target_variable]][
        leading_period_tmp == 0] <- NA
    }
    if (length(which(target_period == 1)) > 0) {
      if (verbose) {
        message(
          paste0(
            "Prediction on ",
            head(data_simulation_tmp[, c('date')][leading_period_tmp == 0], 1)))
      }
      if (use_history) {
        predict_as_date <- head(
          data_simulation_tmp[, c('date')][leading_period_tmp == 0], 1)
      } else {
        predict_as_date <- NULL
      }
      simulation[(i[[1]] + horizon):predict_block_end] <- predict(
        model2, data_simulation_tmp, leading_period = leading_period_tmp,
        bypass_transform = TRUE,
        predict_as_date = predict_as_date)[
          target_period[leading_period_tmp == 0] == 1]
    }
    #XXX: mettre bypass_transform a FALSE?

    # Estimation
    # if and only if an update date falls inside the prediction block
    update_candidate <- which((update_ind > i[[1]]) & (update_ind < i[[2]]))
    if (length(update_candidate) > 0) {
      model2 <- update_model(
        model,
        1, #start_simulation,
        tail(update_candidate, 1),
        data_simulation, delay, bypass_transform,
        leading_period = leading_period,
        save_history = save_history, verbose = verbose)
      last_update_pos <- tail(update_candidate, 1)
    }
  }

  res <- simulation[leading_period == 0]
  if (output_model) {
    list(simulation = res, model = model2)
  } else {
    res
  }
}
