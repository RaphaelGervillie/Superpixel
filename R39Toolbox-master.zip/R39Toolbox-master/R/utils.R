month_days <- function(time) {
  time <- as.POSIXlt(time)
  time$mday[] <- 0
  time$sec[]  <- 0
  time$min    <- 0
  time$hour   <- 0
  time$mon    <- time$mon + 1
  as.POSIXlt(as.POSIXct(time))$mday
}


year_days <- function(time) {
  time <- as.POSIXlt(paste0(time, "-01-01"))
  time$mon[]  <- 0
  time$mday[] <- 0
  time$sec[]  <- 0
  time$min    <- 0
  time$hour   <- 0
  time$year   <- time$year + 1
  as.POSIXlt(as.POSIXct(time))$yday + 1
}


#' Leap year check
#'
#' Test if a given year is a leap year
#'
#' @param year Year to be tested. Can be a vector of years.
#'
#' @return TRUE if the given year is a leap year, FALSE otherwise
is_leap_year <- function(year) {
  (year %% 4 == 0 & !(year %% 100 == 0)) | (year %% 400 == 0)
}


#' ISO week-numbering year
#'
#' Convert years to ISO week date format
#'
#' @param date_posix Sequence of dates in posixlt format
#' @param year The corresponding (Gregorian) years
#'
#' @return List of the weeks and the years corresponding to the
#'   provided dates in date_posix.
#'
iso_week_year <- function(date_posix, year) {
  jan1_wday <- rep(strptime(paste0(unique(year), "-01-01"), "%Y-%m-%d")$wday,
                   table(year))
  date_yday <- date_posix$yday + 1
  date_wday <- date_posix$wday
  # Sundays as '7's, not '0's
  jan1_wday[jan1_wday == 0] <- 7
  date_wday[date_wday == 0] <- 7

  year_iso <- year
  week_iso <- (date_yday - date_wday + jan1_wday + 6) / 7 - (jan1_wday > 4)
  # if these dates exist for the year Y:
  #   - Sun Jan 1st,
  #   - Sat Jan 1st and Sun Jan 2nd,
  #   - Fri Jan 1st, Sat Jan 2nd and Sun Jan 3rd,
  # then set up their corresponding iso year number to Y-1.
  # When this is the case, then the days above belong to the last iso week (53)
  mask_first_week <- (date_yday + jan1_wday) <= 8
  mask_tmp <- mask_first_week & (jan1_wday > 4)
  year_iso[mask_tmp] <- year[mask_tmp] - 1
  week_iso[mask_tmp & (jan1_wday == (5 + is_leap_year(year - 1)))] <- 53
  # if these dates exist for the year Y:
  #   - Mon Dec 31st,
  #   - Tue Dec 31st and Mon Dec 30th,
  #   - Wed Dec 31st, Tue Dec 30th and Mon Dec 29th,
  # then set up their corresponding iso year number to Y+1
  mask_tmp <- (365 + is_leap_year(year) - date_yday + date_wday) <= 3
  year_iso[mask_tmp] <- year[mask_tmp] + 1
  week_iso[mask_tmp] <- 1

  list(ISOYear = year_iso, ISOWeek = week_iso)
}

#' @export
hour_change_year <- function(year) {
  # get whole year calendar
  date_begin <- as.POSIXct(paste0(year, "-01-01"), tz = "CET")
  date_end   <- as.POSIXct(paste0(year, "-12-31"), tz = "CET")
  dates <- as.POSIXlt(seq(from = date_begin, to = date_end, by = 60 * 60L))
  hours <- dates$hour

  hours_diff <- hours[2:length(hours)] - hours[1:(length(hours) - 1)]
  # get winter daylight saving time
  ind_winter_time <- which(hours_diff == 0)
  winter_time <- dates[c(ind_winter_time + 1)]
  # get summer daylight saving time
  ind_summer_time <- which(hours_diff == 2)
  summer_time <- dates[c(ind_summer_time + 1)]

  list(winter_time, summer_time)
}


compute_date_sequence_cet <- function(date, ts) {
  seq_date <- seq(date[1], date[length(date)], by = 60 * 60)

  # generate a regular 24-hours day grid
  regular_day_grid <- format(
    seq(as.POSIXct("1910-01-01 00:00:00", tz = "UTC"),
        as.POSIXct("1910-01-01 23:50:00", tz = "UTC"), by = ts),
    format = "%H:%M:%S")

  # generate the summer daylight saving day for each year in the calendar
  get_summer_time_day_of_year <- function(year) {
    hour_change <- hour_change_year(year)
    gsub(" 02:", " 03:",
         paste(format(hour_change[[2]], "%Y-%m-%d"), regular_day_grid))
  }
  summer_time_day <- do.call(
    "c", lapply(unique(format(date, "%Y")), get_summer_time_day_of_year))
  # ?
  ind_keep <- unique(
    sort(c(which(format(seq_date, "%H:%M:%S") %in% regular_day_grid),
           which(seq_date %in% as.POSIXct(summer_time_day, tz = "CET")))))
  seq_date <- seq_date[ind_keep]

  # remove duplicated observations
  # (winter daylight saving day and instants that have been introduced
  #  artifically in summer daylight saving day)
  ind_dup <- which(duplicated(format(seq_date, "%Y%m%d %H:%M:%S"),
                              fromLast = FALSE))
  if (length(ind_dup) > 0) {
    seq_date <- seq_date[-ind_dup]
  }

  attr(seq_date, "tzone") <- "CET"
  seq_date
}


#' Convert "UTC" or "CET" (class POSIXct) to local hour 24 (class CET24)
#'
#' @param data data.frame
#' @param ind_date column index of POSIXct date
#' @return a data.frame.
#' @examples
#'
#' tz = "CET"
#'
#' date.begin = "2010/10/30 23:00:00"
#' date.end = "2010/10/31 03:00:00"
#'
#' date <- seq.POSIXt(as.POSIXct(date.begin, tz = tz), as.POSIXct(date.end, tz = tz), by = "10 min")
#' data <- data.frame(date = date, value = rnorm(length(date)))
#'
#' res <- to_cet24(data, ind_date = 1)
#' data
#' res
#'
#' date.begin = "2010/03/27 22:00:00"
#' date.end = "2010/03/28 03:50:00"
#'
#' date <- seq.POSIXt(as.POSIXct(date.begin, tz = tz), as.POSIXct(date.end, tz = tz), by = "10 min")
#' data <- data.frame(date = date, value = rnorm(length(date)))
#'
#' res <- to_cet24(data, ind_date = 1)
#' data
#' res
#'
#' @note Copyright 2015 EDF
#' @export
to_cet24 <- function(data, ind_date){
  if ("NULL" %in% data[, ind_date]) {
    stop("Date column has NA elements.")
  }

  if (!"POSIXct" %in% class(data[, ind_date])) {
    stop("Date must be in POSIXct format.")
  }

  # if not CET, first convert to CET
  if (attr(data[, ind_date], "tzone") != "CET") {
    attr(data[, ind_date], "tzone") <- "CET"
  }

  # character and CET24 class
  data[, ind_date] <- as.character(data[, ind_date])

  # years
  vector_year <- as.numeric(
    unique(substring(as.character(data[, ind_date]), 1, 4)))
  for (year in vector_year) {
    hour_changed <- hour_change_year(year)

    # suppress a line in october ?
    ind_rm_october_start <- which(
      data[, ind_date] >= as.character(hour_changed[[1]] - 3600))
    if (length(ind_rm_october_start) != 0) {
      ind_rm_october_start <- ind_rm_october_start[[1]]
    }
    ind_rm_october_end <- which(
      data[, ind_date] <= as.character(hour_changed[[1]] + 3600))
    if (length(ind_rm_october_end) != 0) {
      ind_rm_october_end <- tail(ind_rm_october_end, 1)
    }
    if ((length(ind_rm_october_start) > 0)
        && (length(ind_rm_october_end) > 0)) {
      ind_rm_october <- seq(
        ind_rm_october_start,
        ind_rm_october_end - (ind_rm_october_end
          - ind_rm_october_start) / 2 - 1,
        1)
      data <- data[-ind_rm_october, ]
      ## if(!1 %in% ind_rm_october) {
      ##   ind_rm_october <- ind_rm_october[which(duplicated(data[ind_rm_october,
      ##                                                          ind_date]))]
      ##   if (length(ind_rm_october) > 0) {
      ##     data <- data[-ind_rm_october, ]
      ##   }
      ## }
    }

    # duplicate a line in march ?
    ind_dup_march <- which(
        data[, ind_date] >= as.character(hour_changed[[2]] - 3600)
      & data[, ind_date] <= as.character(hour_changed[[2]]))
    if (length(ind_dup_march) > 1) {
      # if(!1%in%ind_dup_march){
      if (max(ind_dup_march) < nrow(data)) {
        ind_keep <- c(
          1:(max(ind_dup_march) - 1),
          ind_dup_march, (max(ind_dup_march) + 1):nrow(data))
      } else {
        ind_keep <- c(1:(max(ind_dup_march) - 1), ind_dup_march)
      }
      data <- data[ind_keep, ]

      hour_to_change  <- seq((max(ind_dup_march)), by = 1,
                             length = length(ind_dup_march) - 1)
      hour_for_change <- seq((min(ind_dup_march)), by = 1,
                             length = length(ind_dup_march) - 1)

      complete_new_hour <- sapply(hour_for_change, function(x) {
        complete_new_hour <- data[x, ind_date]
        new_hour <- as.character(
          as.numeric(substring(complete_new_hour, 12, 13)) + 1)
        if (nchar(new_hour) == 1) {
          new_hour <- paste("0", new_hour, sep = "")
        }
        complete_new_hour <- paste(
          substring(complete_new_hour, 1, 11),
          new_hour,
          substring(complete_new_hour, 14, nchar(complete_new_hour)), sep = "")
      })
      data[hour_to_change, ind_date] <- complete_new_hour
    }

    # }
  }
  class(data[, ind_date]) <- "CET24"
  return(data)
}

#' Specification of subsetting operator for CET24 objects
#' in order to preserve class information
#' @export
`[.CET24` <- function(x, i, ...) {
  attrs <- attributes(x)
  out <- unclass(x)
  out <- out[i]
  attributes(out) <- attrs
  out
}

#' Specification of subsetting function for CET24 objects
#' in order to preserve class information
#' @export
subset.CET24 <- function(x, ...) {
  attrs <- attributes(x)
  out <- unclass(x)
  out <- subset(x, ...)
  attributes(out) <- attrs
  out
}

#
compute_daily_standard_temperature_shape <- function(data_temperature) {
  standard_temperature <- R39Toolbox::get_standard_temperature(
    data_temperature)
  dates_day <- as.numeric(
    strftime(data_temperature$date, format = "%Y%m%d"))
  data_temperature$DateDay <- dates_day
  temp  <- data.frame(StdTemperature = standard_temperature,
                      DateDay = dates_day)
  temp2 <- stats::aggregate(temp[, c('StdTemperature')],
                            by = list(DateDay = temp$DateDay),
                            mean, na.action = na.omit, na.rm = TRUE)
  daily_temperature_level <- merge(temp, temp2, by = 'DateDay',
                                   sort = FALSE, all.x = TRUE)$x
  shape_temperature <- standard_temperature - daily_temperature_level

  shape_temperature
}
