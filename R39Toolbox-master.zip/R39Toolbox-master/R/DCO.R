#' Generate DCO's Calhisto daytypes (Profiles)
#'
#' 16 daytypes are used in Calhisto daytypes. This function generates
#' them for any dataset provided as an input (with a compulsory 'date'
#' column).
#'
#' @param data The input dataset for which one wants to generate daytypes
#'
#' @return The column vector (as a factor) that correspond to the daytypes
#'
#' @export
generate_daytypes_calhisto_profiles <- function(data) {
  col_date <- 'date'
  # Check dates
  date_control <- R39Toolbox::check_dates(data)
  # check initial timezone and set working timezone accordingly
  initial_timezone <- date_control$tz
  if (initial_timezone == "CET24") {
    data[[col_date]] <- as.POSIXct(as.character(data[[col_date]]), tz = 'UTC')
    working_timezone <- 'UTC'
  } else {
    working_timezone <- date_control$tz
  }

  ### Base: general daytypes
  daytypes <- R39Toolbox::generate_daytypes(
    data,
    daytypes = c(1, 14, 5, 6, 0, 20:22, 30, 33, 47, 471, 472, 40, 401))
  daytypes <- as.numeric(levels(daytypes)[daytypes])
  daytypes_dayoff <- R39Toolbox::generate_daytypes(
    data,
    daytypes = c(40, 41, 42, 43, 44, 45, 46, 47, 50, 51, 52))
  days     <- as.Date(data$date, tz = working_timezone)
  weekdays <- as.numeric(
    strftime(data$date, format = "%w", timezone = working_timezone))
  hours    <- strftime(data$date, format = "%H%M", timezone = working_timezone)
  years    <- as.numeric(
    strftime(data$date, format = "%Y", timezone = working_timezone))

  ### Calhisto adjustments
  # Sunday in June
  mask_sunday <- weekdays == 0
  mask_june   <- as.numeric(
    strftime(data$date, format = "%m", timezone = working_timezone)) == 6
  mask_sunday_june <- mask_sunday & mask_june
  daytypes[mask_sunday_june & (hours < "0900")] <- 0

  # May 1st
  mask_may1st <- daytypes_dayoff == 41
  # monday
  mask_tmp <- mask_may1st & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "1800")] <- 34
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 34
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after & (hours < "1300")] <- 1
  }
  # tuesday
  mask_tmp <- mask_may1st & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "1800")] <- 34
  }
  # wednesday
  mask_tmp <- mask_may1st & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # thursday
  mask_tmp <- mask_may1st & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # friday
  mask_tmp <- mask_may1st & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # sunday
  mask_tmp <- mask_may1st & (weekdays == 0)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "0900")] <- 0
    daytypes[mask_tmp & (hours >= "0900")] <- 34
  }

  # Ascension (before May 8th to avoid conflict when VirginMaryAscension
  # falls on May 10th)
  mask_assumption <- daytypes_dayoff == 51
  if (length(which(mask_assumption)) > 0) {
    mask_tmp_before <- days %in% (days[mask_assumption] - 1)
    daytypes[mask_tmp_before] <- 5
  }

  # May 8th
  mask_may8th <- daytypes_dayoff == 42
  # monday
  mask_tmp <- mask_may8th & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "0900")] <- 34
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours >= "0900")] <- 34
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # tuesday
  mask_tmp <- mask_may8th & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 30
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 1
    mask_tmp_after2 <- days %in% (days[mask_tmp] + 2)
    mask_tmp_special2 <- daytypes_dayoff == 51 & mask_tmp_after2
    mask_tmp_special  <- days %in% (days[mask_tmp_special2] - 1)
    daytypes[mask_tmp_special] <- 33
  }
  # wednesday
  mask_tmp <- mask_may8th & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 30
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # thursday
  mask_tmp <- mask_may8th & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 30
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # friday
  mask_tmp <- mask_may8th & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 30
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # saturday
  mask_tmp <- mask_may8th & (weekdays == 6)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 30
  }
  # sunday
  mask_tmp <- mask_may8th & (weekdays == 0)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "0900")] <- 0
    daytypes[mask_tmp & (hours >= "0900")] <- 34
  }

  # Easter
  # before 2007
  mask_year <- years <= 2007
  if (length(which(mask_year)) > 0) {
    mask_easter <- (daytypes_dayoff == 50) & mask_year
    if (length(which(mask_easter)) > 0) {
      daytypes[mask_easter & (hours < "0900")]  <- 34
      daytypes[mask_easter & (hours >= "0900")] <- 0
      mask_tmp_before <- days %in% (days[mask_easter] - 1)
      daytypes[mask_tmp_before & (hours >= "0900")] <- 34
      mask_tmp_after  <- days %in% (days[mask_easter] + 1)
      daytypes[mask_tmp_after] <- 1
    }
  }
  # after 2007
  mask_year <- years > 2007
  if (length(which(mask_year)) > 0) {
    mask_easter <- (daytypes_dayoff == 50) & mask_year
    if (length(which(mask_easter)) > 0) {
      mask_tmp_before <- days %in% (days[mask_easter] - 1)
      daytypes[mask_tmp_before] <- 30
      mask_tmp_before2 <- days %in% (days[mask_easter] - 2)
      daytypes[mask_tmp_before2 & (hours < "0430")]  <- 30
      daytypes[mask_tmp_before2 & (hours >= "0430")] <- 33
      mask_tmp_after   <- days %in% (days[mask_easter] + 1)
      daytypes[mask_tmp_after & (hours < "0430")] <- 30
    }
  }

  # Pentecost
  # 2005 to 2007
  mask_year <- years %in% 2005:2007
  if (length(which(mask_year)) > 0) {
    mask_pentecost <- (daytypes_dayoff == 52) & mask_year
    if (length(which(mask_pentecost)) > 0) {
      daytypes[mask_pentecost] <- 6
      mask_tmp_before <- days %in% (days[mask_pentecost] - 1)
      daytypes[mask_tmp_before & (hours >= "0900")] <- 34
      mask_tmp_after  <- days %in% (days[mask_pentecost] + 1)
      daytypes[mask_tmp_after] <- 1
    }
  }
  # other years
  mask_year <- !years %in% 2005:2007
  if (length(which(mask_year)) > 0) {
    mask_pentecost <- (daytypes_dayoff == 52) & mask_year
    if (length(which(mask_pentecost)) > 0) {
      daytypes[mask_pentecost & (hours >= "0900")] <- 0
      daytypes[mask_pentecost & (hours < "0900")]  <- 34
      mask_tmp_before <- days %in% (days[mask_pentecost] - 1)
      daytypes[mask_tmp_before & (hours >= "0900")] <- 34
      mask_tmp_after   <- days %in% (days[mask_pentecost] + 1)
      daytypes[mask_tmp_after] <- 1
    }
  }

  # July 14th
  mask_july14th <- daytypes_dayoff == 43
  if (length(which(mask_july14th)) > 0) {
    daytypes[mask_july14th] <- 20
  }
  # monday
  mask_tmp <- mask_july14th & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours >= "1800")] <- 34
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # tuesday
  mask_tmp <- mask_july14th & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # wednesday
  mask_tmp <- mask_july14th & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # thursday
  mask_tmp <- mask_july14th & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }

  # August 15th
  mask_august15th <- daytypes_dayoff == 44
  if (length(which(mask_august15th)) > 0) {
    daytypes[mask_august15th] <- 21
  }
  # monday
  mask_tmp <- mask_august15th & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours >= "1800")] <- 34
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # tuesday
  mask_tmp <- mask_august15th & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # wednesday
  mask_tmp <- mask_august15th & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 1
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 1
  }
  # thursday
  mask_tmp <- mask_august15th & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 1
  }
  # friday
  mask_tmp <- mask_august15th & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 1
  }

  # November 1st
  mask_november1st <- daytypes_dayoff == 45
  # monday
  mask_tmp <- mask_november1st & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1300")]  <- 30
    daytypes[mask_tmp_before & (hours >= "1300")] <- 34
  }
  # tuesday
  mask_tmp <- mask_november1st & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1300")]  <- 6
  }
  # wednesday
  mask_tmp <- mask_november1st & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after & (hours < "1300")]  <- 472
    daytypes[mask_tmp_after & (hours >= "1300")] <- 1
  }
  # thursday
  mask_tmp <- mask_november1st & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # friday
  mask_tmp <- mask_november1st & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # saturday
  mask_tmp <- mask_november1st & (weekdays == 6)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours >= "0430")] <- 6
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 30
  }

  # November 11th
  mask_november11th <- daytypes_dayoff == 46
  # monday
  mask_tmp <- mask_november11th & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1300")]  <- 30
    daytypes[mask_tmp_before & (hours >= "1300")]  <- 34
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 1
  }
  # tuesday
  mask_tmp <- mask_november11th & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 1
  }
  # wednesday
  mask_tmp <- mask_november11th & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # thursday
  mask_tmp <- mask_november11th & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # friday
  mask_tmp <- mask_november11th & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "0430")] <- 5
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before] <- 5
  }
  # saturday
  mask_tmp <- mask_november11th & (weekdays == 6)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp] <- 6
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours >= "1300")] <- 6
  }

  # Christmas
  mask_christmas <- daytypes_dayoff == 47
  # monday
  mask_tmp <- mask_christmas & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1800")]  <- 6
    mask_tmp_after2 <- days %in% (days[mask_tmp] + 2)
    daytypes[mask_tmp_after2] <- 1
    mask_tmp_after3 <- days %in% (days[mask_tmp] + 3)
    daytypes[mask_tmp_after3] <- 5
    mask_tmp_after4 <- days %in% (days[mask_tmp] + 4)
    daytypes[mask_tmp_after4] <- 33
  }
  # tuesday
  mask_tmp <- mask_christmas & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before2 <- days %in% (days[mask_tmp] - 2)
    daytypes[mask_tmp_before2] <- 34
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1800")] <- 33
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 6
    mask_tmp_after2 <- days %in% (days[mask_tmp] + 2)
    daytypes[mask_tmp_after2] <- 33
    mask_tmp_after3 <- days %in% (days[mask_tmp] + 3)
    daytypes[mask_tmp_after3] <- 33
    mask_tmp_after5 <- days %in% (days[mask_tmp] + 5)
    daytypes[mask_tmp_after5] <- 20
  }
  # thursday
  mask_tmp <- mask_christmas & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before2 <- days %in% (days[mask_tmp] - 2)
    daytypes[mask_tmp_before2] <- 5
    mask_tmp_after2 <- days %in% (days[mask_tmp] + 2)
    daytypes[mask_tmp_after2] <- 472
  }
  # friday
  mask_tmp <- mask_christmas & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before2 <- days %in% (days[mask_tmp] - 2)
    daytypes[mask_tmp_before2] <- 5
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 6
  }
  # saturday
  mask_tmp <- mask_christmas & (weekdays == 6)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before2 <- days %in% (days[mask_tmp] - 2)
    daytypes[mask_tmp_before2] <- 5
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after] <- 20
  }
  # sunday
  mask_tmp <- mask_christmas & (weekdays == 0)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before2 <- days %in% (days[mask_tmp] - 2)
    daytypes[mask_tmp_before2] <- 5
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1300")] <- 33
    mask_tmp_after <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after & (hours < "0430")]  <- 6
    daytypes[mask_tmp_after & (hours >= "0430")] <- 1
  }
  # cas particulier du 23/12/2013
  # (probablement lie a une erreur dans Calhisto)
  mask_tmp <- days %in% as.Date("2013-12-23", tz = working_timezone)
  if (length(which(mask_tmp)) > 0) {
    daytypes[mask_tmp & (hours < "0430")] <- 6
  }

  # New Years Day
  mask_newyear <- daytypes_dayoff == 40
  # monday
  mask_tmp <- mask_newyear & (weekdays == 1)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1800")]  <- 6
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 1
  }
  # tuesday
  mask_tmp <- mask_newyear & (weekdays == 2)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1800")]  <- 33
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 1
  }
  # wednesday
  mask_tmp <- mask_newyear & (weekdays == 3)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 1
  }
  # thursday
  mask_tmp <- mask_newyear & (weekdays == 4)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 6
  }
  # friday
  mask_tmp <- mask_newyear & (weekdays == 5)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after]  <- 6
  }
  # saturday
  mask_tmp <- mask_newyear & (weekdays == 6)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_after  <- days %in% (days[mask_tmp] + 1)
    daytypes[mask_tmp_after & (hours < "0430")]  <- 6
    daytypes[mask_tmp_after & (hours >= "0430")] <- 0
  }
  # sunday
  mask_tmp <- mask_newyear & (weekdays == 0)
  if (length(which(mask_tmp)) > 0) {
    mask_tmp_before <- days %in% (days[mask_tmp] - 1)
    daytypes[mask_tmp_before & (hours < "1300")] <- 6
  }

  factor(daytypes,
         levels = c(0, 1, 5, 6, 14, 20:22, 30, 33, 34, 40, 401, 47, 471, 472),
         labels = c(0, 1, 5, 6, 14, 20:22, 30, 33, 34, 40, 401, 47, 471, 472))
}


#' Generate DCO's Calhisto offsets (France)
#'
#' 11 offsets are used in Calhisto offsets. This function generates
#' them for any dataset provided as an input (with a compulsory 'date'
#' column).
#'
#' @param data The input dataset for which one wants to generate offsets
#'
#' @return The column vector (as a factor) that correspond to the offsets
#'
#' @export
generate_offsets_calhisto_france <- function(data) {
  col_date <- 'date'
  # Check dates
  date_control <- R39Toolbox::check_dates(data)
  # check initial timezone and set working timezone accordingly
  initial_timezone <- date_control$tz
  if (initial_timezone == "CET24") {
    data[[col_date]] <- as.POSIXct(as.character(data[[col_date]]), tz = 'UTC')
    working_timezone <- 'UTC'
  } else {
    working_timezone <- date_control$tz
  }
  days <- as.Date(data$date, tz = working_timezone)

  offsets <- R39Toolbox::generate_offsets(
    data, offsets = c(1, 3, 4, 11:15, 21:23))
  offsets <- as.numeric(levels(offsets)[offsets])
  # cas particulier du 02/01/2012
  # (probablement lie a une erreur dans Calhisto)
  mask_tmp <- days %in% as.Date("2012-01-02", tz = working_timezone)
  if (length(which(mask_tmp)) > 0) {
    offsets[mask_tmp] <- 1
  }
  factor(offsets,
         levels = c(1, 3, 4, 11:15, 21:23), labels = c(1, 3, 4, 11:15, 21:23))
}


#' Load DCo csv file into an R39Toolbox-compatible dataframe
#'
#' DCo fournit en entree des dates au format 23/25 sous forme d'une
#' chaine de caracteres (colonne 'Date', doit etre continue).
#' On convertit la date de debut et la date de fin en POSIXct,
#' puis on genere toutes les dates intermediaires directement
#' en CET/CEST au pas demi horaire.
#'
#' @param file Path to the file to be read
#' @param required_columns Columns that must be in the dataset
#'
#' @return Dataset ready to be used with R39Toolbox
#'
#' @export
read_dco_data <- function(file, required_columns = NULL) {
  data <- read.table(file, sep = ';', header = TRUE, dec = '.')
  # date conversion
  date_d <- as.POSIXct(
    data$Date[[1]], format = "%d/%m/%Y %H:%M", tz = 'CET')
  date_f   <- as.POSIXct(
    data$Date[[nrow(data)]], format = "%d/%m/%Y %H:%M", tz = 'CET')
  data$date <- seq(from = date_d, to = date_f, by = 30 * 60)

  # check for required columns
  R39Toolbox::check_data(data, required_columns)

  data
}


#' Write an R39Toolbox-compatible dataframe into a DCo csv file
#'
#' DCo recoit des dates au format 23/25 sous forme d'une
#' chaine de caracteres (colonne 'Date').
#'
#' @param data Data to be written to a csv file
#' @param file Path to the file to be written
#'
#' @export
write_dco_data <- function(data, file) {
  # format and rename column containing dates
  data$date <- strftime(data$date, format = "%d/%m/%Y %H:%M")
  names_tmp <- colnames(data)
  names_tmp[names_tmp == 'date'] <- 'Date'
  colnames(data) <- names_tmp

  # actually write file
  write.table(data, file = file, sep = ';', dec = '.',
              quote = FALSE, row.names = FALSE, col.names = TRUE)
}
