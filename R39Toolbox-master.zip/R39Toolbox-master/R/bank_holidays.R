#  International bank holidays

#' List all french national holidays
#' @export
#' @examples
#'# Create a calendar data.frame with French holidays.
#'tz = "UTC"
#'ts = 60*60*12
#'FR_calendar = generate_calendar(
#'   "2010-01-01 00:00", "2010-12-31 23:50",
#'   ts = ts, tz = tz, holidays = "FR")
frenchHolidays = function() c(
  "NewYearsDay",
  "Easter",
  "EasterMonday",  # new
  "LaborDay",
  "Pentecost",
  "PentecostMonday",  # new
  "ChristmasDay",  # new
  "FRAllSaints",
  "FRArmisticeDay",
  "FRAscension",
  "FRAssumptionVirginMary",
  "FRBastilleDay",
  "FRFetDeLaVictoire1945"
)

#' List all portuguese national holidays
#' @export
#' @examples
#'# Create a calendar data.frame with Portuguese holidays.
#'tz = "UTC"
#'ts = 60*60*12
#'PT_calendar = generate_calendar(
#'   "2010-01-01 00:00", "2010-12-31 23:50",
#'   ts = ts, tz = tz, holidays = "PT")
portugueseHolidays = function() c(
  "NewYearsDay",
  "GoodFriday",
  "PtFreedomDay",  # new
  "LaborDay",
  "CorpusChristi",
  "PtPortugalDay",  # new
  "StAnthony",  # new
  "StJeanBaptist",  # new
  "AssumptionOfMary",
  "PtRepublicDay",  # new
  "AllSaints",
  "PtRestorationOfIndependance",  # new
  "ITImmaculateConception",
  "ChristmasDay"
)

PtFreedomDay <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 425
  timeDate::timeDate(as.character(ans))
}

PtPortugalDay <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 610
  timeDate::timeDate(as.character(ans))
}

StAnthony <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 613
  timeDate::timeDate(as.character(ans))
}

StJeanBaptist <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 624
  timeDate::timeDate(as.character(ans))
}

PtRepublicDay <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 1005
  timeDate::timeDate(as.character(ans))
}

PtRestorationOfIndependance <- function(year = timeDate::getRmetricsOptions("currentYear")) {
  ans = year * 10000 + 1201
  timeDate::timeDate(as.character(ans))
}

#' Format holidays
#'
#' @import timeDate
format_holidays <- function(date_begin, date_end, dates_holidays) {
  if (!is.Date(date_begin)) {
    date_begin <- as.Date(date_begin)
  }
  if (!is.Date(date_end)) {
    date_end   <- as.Date(date_end)
  }

  mask_period <- (dates_holidays >= date_begin) & (dates_holidays <= date_end)
  dates_holidays[mask_period]
}


#' Test for days off on a given period
#'
#' @author Aurelie Frechet
#'
#' @param data_period period to test, date vector,
#'   "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or
#'   "YYYY/MM/DD"
#' @param country determines the country
#'
#' @return vector of boolean. TRUE if the day is off.
#' @examples
#' # Wih a character string in Date format
#' \dontrun{
#' #' is_day_off("2016-01-01")
#' }
#' # With a sequence of dates
#' \dontrun{
#' moment <- seq.Date("2016-09-01", "2017-02-01", "days")
#' is_day_off(moment)
#' }
#'
#' @export
is_day_off <- function(data_period, country = "FR") {
  if (!is.Date(data_period)) {
    data_period <- as.Date(data_period)
  }

  holidays <- switch(toupper(country),
                     FR = frenchHolidays(),
                     PT = portugueseHolidays())

  days_off <- rep(FALSE, length(data_period))
  jf <- sapply(holidays, do.call, list(year = unique(year(data_period))))

  sapply(names(jf),
         function(k) {
           ind_holidays <- which(data_period %in% as.Date(jf[[k]]@Data))
           if (length(ind_holidays) > 0) {
             days_off[ind_holidays] <<- TRUE
           }
         })

  days_off
}


#' Test for bridging days on a given period
#'
#' @author Aurelie Frechet
#'
#' @param data_period period to test, date vector,
#'   "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or
#'   "YYYY/MM/DD"
#' @param country determines the country
#'
#' @return vector of boolean. TRUE if the day is a bridging day.
#'
#' @examples
#' \dontrun{
#' data_period <- seq.Date(as.Date("2017-05-01"),
#'                         as.Date("2017-05-30"), "days")
#' createBridgingDay(data_period)
#' }
#' @export
is_bridging_day <- function(data_period, country = "FR") {
  if (!is.Date(data_period)) {
    data_period <- as.Date(data_period)
  }
  sapply(
    data_period,
    function(x) {
      ((is_day_off(x + 1, country) == 1 & wday(x) == 2)
        || (is_day_off(x - 1 , country) == 1 & wday(x) == 6))
    })
}


#' Test if a day is before a day off on a given period
#'
#' @param data_period period to test, date vector,
#'   "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or
#'   "YYYY/MM/DD"
#' @param country determines the country
#'
#' @return vector of boolean. TRUE if the day is before a day off.
#'
#' @examples
#' \dontrun{
#' data_period <- seq.Date(as.Date("2017-05-01"),
#'                         as.Date("2017-05-30"), "days")
#' is_before_day_off(data_period)
#' }
#' @export
is_before_day_off <- function(data_period, country = "FR") {
  if (!is.Date(data_period)) {
    data_period <- as.Date(data_period)
  }
  is_day_off(data_period + 1, country)
}


#' Test if a day is after a day off on a given period
#'
#' @param data_period period to test, date vector,
#'   "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or
#'   "YYYY/MM/DD"
#' @param country determines the country
#'
#' @return vector of boolean. TRUE if the day is after a day off.
#'
#' @examples
#' \dontrun{
#' data_period <- seq.Date(as.Date("2017-05-01"),
#'                         as.Date("2017-05-30"), "days")
#' is_after_day_off(data_period)
#' }
#' @export
is_after_day_off <- function(data_period, country = "FR") {
  if (!is.Date(data_period)) {
    data_period <- as.Date(data_period)
  }
  is_day_off(data_period - 1, country)
}


#' Test for school vacation days on a given period
#'
#' @author Aurelie Frechet
#' @param data_period period to test, date vector, "YYYY-MM-DD HH:MM:SS" or
#'                     "YYYY-MM-DD" ("YYYY/MM/DD HH:MM:SS" or "YYYY/MM/DD"
#' @return vector of boolean (TRUE) if the day is in school vacation period
#' @export
#' @examples
#' # Wih a character string in Date format
#' \dontrun{
#' is_school_break("2016-01-01", zone = "A")
#' }
#' # With a sequence of dates
#' \dontrun{
#' moment <- seq.Date("2016-09-01", "2017-02-01", "days")
#' is_school_break(moment, zone = "A")
#' }
#' @note Available from 2011-09 to 2018-09 at last update
is_school_break <- function(data_period, zone, country = "FR") {
  # Controles
  if (!is.Date(data_period)) data_period <- as.Date(data_period)

  holidays <- switch(toupper(country),
                     FR = french_school_break(zone))

  days_off <- rep(FALSE, length(data_period))
  jf <- sapply(holidays, do.call, list(date_begin = min(data_period),
                                       date_end   = max(data_period)))

  sapply(
    names(jf),
    function(k) {
      if (length(jf[[k]]) > 0){
        ind_holidays <- which(data_period %in% as.Date(jf[[k]]))
        if (length(ind_holidays) > 0) {
          days_off[ind_holidays] <<- TRUE
        }
      }
    })

  days_off
}

#' List of all french school vacations by zone
#'
#' @param zone "A", "B" or "C"
#'
#' @return list of school vacations
french_school_break <- function(zone) {
  zone <- toupper(zone)
  if (!zone %in% c("A", "B", "C")) {
    stop("'Zone' must be in 'A', 'B' or 'C'")
  }
  holidays_FR <- c("french_summer_holidays", "french_all_saints_holidays",
                   "french_christmas_holidays")
  switch(
    zone,
    A = {holidays_FR <- c(
      holidays_FR, "french_winter_holidays_A", "french_spring_holidays_A")},
    B = { holidays_FR <- c(
      holidays_FR, "french_winter_holidays_B", "french_spring_holidays_B")},
    C = {holidays_FR <- c(
      holidays_FR, "french_winter_holidays_C", "french_spring_holidays_C")}
  )

  holidays_FR
}


#' Gives French summer scholar holidays
#' @author Aurelie Frechet
#'
#' We consider that the first day of the scholar holidays is the first
#' day that is entirely off. On the contrary, the website of the
#' French government marks the first day as the scholar holidays as
#' the day corresponding to the last scholar day.
#'
#' @param date_begin First date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#'
#' @examples
#' \dontrun{
#' FRSummerHoliday("2016-09-01","2017-09-01")
#' }
#' @note Available from 2011-07 to 2018-09 at last update
#'
#' @export
french_summer_holidays <- function(date_begin, date_end) {
  dates_holidays <- c(
    seq.Date(from = as.Date("2011-07-03"),
             to   = as.Date("2011-09-04"),
             by   = "days"),
    seq.Date(from = as.Date("2012-07-06"),
             to   = as.Date("2012-09-03"),
             by   = "days"),
    seq.Date(from = as.Date("2013-07-07"),
             to   = as.Date("2013-09-02"),
             by   = "days"),
    seq.Date(from = as.Date("2014-07-06"),
             to   = as.Date("2014-09-01"),
             by   = "days"),
    seq.Date(from = as.Date("2015-07-05"),
             to   = as.Date("2015-08-31"),
             by   = "days"),
    seq.Date(from = as.Date("2016-07-06"),
             to   = as.Date("2016-08-31"),
             by   = "days"),
    seq.Date(from = as.Date("2017-07-09"),
             to   = as.Date("2017-09-03"),
             by   = "days"),
    seq.Date(from = as.Date("2018-07-08"),
             to   = as.Date("2018-09-02"),
             by   = "days"))

  format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French AllSaints scholar holidays
#' @title FRAllSaintsHoliday
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#'
#' @examples
#' \dontrun{
#' FRAllSaintsHoliday("2016-09-01","2017-09-01")
#' }
#' @note Available from 2011 to 2017 at last update
#' @export
french_all_saints_holidays <- function(date_begin, date_end){
  dates_holidays <- c(
    seq.Date(from = as.Date("2011-10-23"),
             to   = as.Date("2011-11-02"),
             by   = "days"),
    seq.Date(from = as.Date("2012-10-28"),
             to   = as.Date("2012-11-11"),
             by   = "days"),
    seq.Date(from = as.Date("2013-10-20"),
             to   = as.Date("2013-11-03"),
             by   = "days"),
    seq.Date(from = as.Date("2014-10-19"),
             to   = as.Date("2014-11-02"),
             by   = "days"),
    seq.Date(from = as.Date("2015-10-18"),
             to   = as.Date("2015-11-01"),
             by   = "days"),
    seq.Date(from = as.Date("2016-10-20"),
             to   = as.Date("2016-11-02"),
             by   = "days"),
    seq.Date(from = as.Date("2017-10-22"),
             to   = as.Date("2017-11-05"),
             by   = "days"),
    seq.Date(from = as.Date("2018-10-21"),
             to   = as.Date("2018-11-04"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Christmass Scholar Holidays
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#'
#' @examples
#' \dontrun{
#' FRChristmassHoliday("2016-09-01","2017-09-01")
#' }
#' @note Available from 2011 to 2017 at last update
#' @export
french_christmas_holidays <- function(date_begin, date_end){
  dates_holidays <- c(
    seq.Date(from = as.Date("2011-12-18"),
             to   = as.Date("2012-01-02"),
             by   = "days"),
    seq.Date(from = as.Date("2012-12-23"),
             to   = as.Date("2013-01-06"),
             by   = "days"),
    seq.Date(from = as.Date("2013-12-22"),
             to   = as.Date("2014-01-05"),
             by   = "days"),
    seq.Date(from = as.Date("2014-12-21"),
             to   = as.Date("2015-01-04"),
             by   = "days"),
    seq.Date(from = as.Date("2015-12-20"),
             to   = as.Date("2016-01-03"),
             by   = "days"),
    seq.Date(from = as.Date("2016-12-18"),
             to   = as.Date("2017-01-02"),
             by   = "days"),
    seq.Date(from = as.Date("2017-12-24"),
             to   = as.Date("2018-01-07"),
             by   = "days"),
    seq.Date(from = as.Date("2018-12-23"),
             to   = as.Date("2019-01-06"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Winter Scholar Holidays in Zone A
#' @title FRWinterHolidayA
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#' @export
#' @examples
#' \dontrun{
#' FRWinterHolidayA("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
french_winter_holidays_A <- function(date_begin, date_end){
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-02-12"),
             to   = as.Date("2012-02-26"),
             by   = "days"),
    seq.Date(from = as.Date("2013-02-24"),
             to   = as.Date("2013-03-10"),
             by   = "days"),
    seq.Date(from = as.Date("2014-03-02"),
             to   = as.Date("2014-03-16"),
             by   = "days"),
    seq.Date(from = as.Date("2015-02-08"),
             to   = as.Date("2015-02-22"),
             by   = "days"),
    seq.Date(from = as.Date("2016-02-14"),
             to   = as.Date("2016-02-28"),
             by   = "days"),
    seq.Date(from = as.Date("2017-02-19"),
             to   = as.Date("2017-03-05"),
             by   = "days"),
    seq.Date(from = as.Date("2018-02-11"),
             to   = as.Date("2018-03-25"),
             by   = "days"),
    seq.Date(from = as.Date("2019-02-17"),
             to   = as.Date("2019-03-03"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Winter Scholar Holidays in Zone B
#' @title FRWinterHolidayB
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#' @export
#' @examples
#' \dontrun{
#' FRWinterHolidayB("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
french_winter_holidays_B <- function(date_begin, date_end){
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-02-26"),
             to   = as.Date("2012-03-11"),
             by   = "days"),
    seq.Date(from = as.Date("2013-02-17"),
             to   = as.Date("2013-03-03"),
             by   = "days"),
    seq.Date(from = as.Date("2014-02-23"),
             to   = as.Date("2014-03-09"),
             by   = "days"),
    seq.Date(from = as.Date("2015-02-21
      "),
             to   = as.Date("2015-03-08"),
             by   = "days"),
    seq.Date(from = as.Date("2016-02-07"),
             to   = as.Date("2016-02-21"),
             by   = "days"),
    seq.Date(from = as.Date("2017-02-12"),
             to   = as.Date("2017-02-26"),
             by   = "days"),
    seq.Date(from = as.Date("2018-02-25"),
             to   = as.Date("2018-03-11"),
             by   = "days"),
    seq.Date(from = as.Date("2019-02-10"),
             to   = as.Date("2019-02-24"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Winter Scholar Holidays in Zone C
#' @title FRWinterHolidayC
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#' @export
#' @examples
#' \dontrun{
#' FRWinterHolidayC("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
french_winter_holidays_C <- function(date_begin, date_end) {
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-02-19"),
             to   = as.Date("2012-03-04"),
             by   = "days"),
    seq.Date(from = as.Date("2013-03-03"),
             to   = as.Date("2013-03-17"),
             by   = "days"),
    seq.Date(from = as.Date("2014-02-16"),
             to   = as.Date("2014-03-02"),
             by   = "days"),
    seq.Date(from = as.Date("2015-02-15"),
             to   = as.Date("2015-03-01"),
             by   = "days"),
    seq.Date(from = as.Date("2016-02-21"),
             to   = as.Date("2016-03-06"),
             by   = "days"),
    seq.Date(from = as.Date("2017-02-05"),
             to   = as.Date("2017-02-19"),
             by   = "days"),
    seq.Date(from = as.Date("2018-02-18"),
             to   = as.Date("2018-03-04"),
             by   = "days"),
    seq.Date(from = as.Date("2019-02-24"),
             to   = as.Date("2019-03-10"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}


#' Gives French Spring Scholar Holidays in Zone A
#' @title FRSpringHolidayA
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#' @export
#' @examples
#' \dontrun{
#' FRSpringHolidayA("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
french_spring_holidays_A <- function(date_begin, date_end) {
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-04-08"),
             to   = as.Date("2012-04-22"),
             by   = "days"),
    seq.Date(from = as.Date("2013-04-21"),
             to   = as.Date("2013-05-05"),
             by   = "days"),
    seq.Date(from = as.Date("2014-04-27"),
             to   = as.Date("2014-05-11"),
             by   = "days"),
    seq.Date(from = as.Date("2015-04-12"),
             to   = as.Date("2015-04-26"),
             by   = "days"),
    seq.Date(from = as.Date("2016-04-10"),
             to   = as.Date("2016-04-24"),
             by   = "days"),
    seq.Date(from = as.Date("2017-04-16"),
             to   = as.Date("2017-05-01"),
             by   = "days"),
    seq.Date(from = as.Date("2018-04-08"),
             to   = as.Date("2018-04-22"),
             by   = "days"),
    seq.Date(from = as.Date("2019-04-14"),
             to   = as.Date("2019-04-28"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Spring Scholar Holidays in Zone B
#' @title FRSpringHolidayB
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#'
#' @examples
#' \dontrun{
#' FRSpringHolidayB("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
#' @export
french_spring_holidays_B <- function(date_begin, date_end) {
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-04-22"),
             to   = as.Date("2012-05-06"),
             by   = "days"),
    seq.Date(from = as.Date("2013-04-14"),
             to   = as.Date("2013-04-29"),
             by   = "days"),
    seq.Date(from = as.Date("2014-04-20"),
             to   = as.Date("2014-05-04"),
             by   = "days"),
    seq.Date(from = as.Date("2015-04-26"),
             to   = as.Date("2015-05-10"),
             by   = "days"),
    seq.Date(from = as.Date("2016-04-03"),
             to   = as.Date("2016-04-17"),
             by   = "days"),
    seq.Date(from = as.Date("2017-04-09"),
             to   = as.Date("2017-04-23"),
             by   = "days"),
    seq.Date(from = as.Date("2018-04-22"),
             to   = as.Date("2018-05-06"),
             by   = "days"),
    seq.Date(from = as.Date("2019-04-07"),
             to   = as.Date("2019-04-22"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}

#' Gives French Spring Scholar Holidays in Zone C
#' @author Aurelie Frechet
#' @param date_begin Begin date of the period
#' @param date_end Last date of the period
#' @return dates of holidays
#'
#' @examples
#' \dontrun{
#' FRSpringHolidayC("2016-09-01","2017-09-01")
#' }
#' @note Available from 2012 to 2018 at last update
#' @export
french_spring_holidays_C <- function(date_begin, date_end) {
  dates_holidays <- c(
    seq.Date(from = as.Date("2012-04-16"),
             to   = as.Date("2012-04-28"),
             by   = "days"),
    seq.Date(from = as.Date("2013-04-28"),
             to   = as.Date("2013-05-12"),
             by   = "days"),
    seq.Date(from = as.Date("2014-04-13"),
             to   = as.Date("2014-04-27"),
             by   = "days"),
    seq.Date(from = as.Date("2015-04-19"),
             to   = as.Date("2015-05-03"),
             by   = "days"),
    seq.Date(from = as.Date("2016-04-17"),
             to   = as.Date("2016-05-01"),
             by   = "days"),
    seq.Date(from = as.Date("2017-04-02"),
             to   = as.Date("2017-04-17"),
             by   = "days"),
    seq.Date(from = as.Date("2018-04-15"),
             to   = as.Date("2018-04-29"),
             by   = "days"),
    seq.Date(from = as.Date("2019-04-21"),
             to   = as.Date("2019-05-05"),
             by   = "days"))

  R39Toolbox:::format_holidays(date_begin, date_end, dates_holidays)
}
