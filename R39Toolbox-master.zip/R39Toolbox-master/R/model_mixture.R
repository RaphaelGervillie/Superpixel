

#' Mixture model
#'
#' @param model_list : List of models to be considered in the mix.
#' @param expert_corrections : correction parameter that should be
#'   applied to each expert
#' @param expert_corrections_type : type of correction that is applied
#'   to the expert ("additive" or "multiplicative").
#'   "E" beeing the expert, "a" the correction factor,
#'   "addiditive" means that the correction is of the form : "E + a" ;
#'   "multiplicative" means that the correction is of the form : "aE".
#'
#' Optional parameters to be given in 'fit.default' :
#'  - algorithm : default = 'MLpol'. Algorithm for the mixture model.
#'  - loss_type : default = 'square'. Loss type in the mixture algorithm.
#'
#' @return MixtureModel instance
#'
#' @export MixtureModel
MixtureModel <- function(model_list, target_variable,
                         fit_default = NULL, predict_default = NULL,
                         transformation_function = NULL,
                         expert_corrections = NULL,
                         expert_corrections_type = NULL) {
  this <- ShortTermForecastModel(target_variable, fit_default = fit_default,
                                 predict_default = predict_default,
                                 transformation_function = transformation_function)

  # are all models Forecast objects?
  if (!all(sapply(model_list,
                  function(x) {
                    "ForecastModel" %in% class(x)
                  }))) {
    stop("Only 'ForecastModel' objects can be considered in a 'MixtureModel'")
  }

  if (is.null(fit_default$algorithm)) {
    fit_default$algorithm <- 'MLpol'
  }
  if (is.null(fit_default$loss_type)) {
    fit_default$loss_type <- 'square'
  }
  if (is.null(predict_default$mode)) {
    predict_default$mode <- 'online'
  }
  this$fit_default <- append(this$fit_default, fit_default)
  this$predict_default <- append(this$predict_default, predict_default)
  this$model_list <- model_list
  if (!is.null(expert_corrections)
      && (length(expert_corrections) != length(model_list))) {
    stop(paste0("Discrepancy between 'expert_corrections' ",
                "length and 'model_list' length."))
  }
  this$expert_corrections <- expert_corrections
  this$expert_corrections_type <- expert_corrections_type

  class(this) <- append(class(this), "MixtureModel")
  return(this)
}


#' Estimation of a MixtureModel
#'
#' @param algorithm Algorithm to be used to fit the mixture model
#' @param loss_type Loss to be used when fitting the mixture model
#' @param precomputed_experts Dataframe gathering the expert
#'   predictions as its columns. Useful to avoid calling the
#'   transformation function several time, or in case the latter takes
#'   a very long time.
#'
#' @return the short term forecast model with estimated weights for the experts
#'
#' @rdname fit
#' @export
fit.MixtureModel <- function(model, data_train,
                             bypass_transform = FALSE,
                             leading_period = NULL,
                             weights = NULL, hist = NULL,
                             algorithm = NULL, loss_type = NULL,
                             precomputed_experts = NULL,
                             by = NULL) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- model$fit_default[["by"]]  # NULL if not defined
  }
  if (is.null(algorithm)) {  # default is 'MLpol'
    algorithm <- model$fit_default[["algorithm"]]
  }
  if (is.null(loss_type)) {  # default is 'square'
    loss_type <- model$fit_default[["loss_type"]]
  }
  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }

  # are all models fit already?
  all_models_fit <- all(
    sapply(model$model_list,
           function(x) {!is.null(x$model_) || !is.null(x$ar_model)}))
  if (!all_models_fit) {
    stop("Not all experts fit")
  }

  # experts' predictions on 'data_train'
  if (is.null(precomputed_experts)) {
    expert_predictions <- sapply(
      model$model_list, predict,
      data_train, bypass_transform = TRUE,
      leading_period = leading_period)
    if (is.null(dim(expert_predictions))
        && (length(expert_predictions) == length(model$model_list)) ){
      expert_predictions <- t(as.data.frame(expert_predictions))
      rownames(expert_predictions) <- NULL
    }
  } else {
    expert_predictions <- precomputed_experts
  }
  if (!is.null(model$expert_corrections) && is.null(precomputed_experts)) {
    for (i in 1:ncol(expert_predictions)) {
      expert_predictions[, i] <- (
        switch(model$expert_corrections_type,
               "additive" = {
                 expert_predictions[, i] + model$expert_corrections[[i]]
               },
               "multiplicative" = {
                 expert_predictions[, i] * model$expert_corrections[[i]]
               }))
    }
  }

  # drop the leading period
  data_train <- data_train[leading_period == 0, ]
  weights    <- weights[leading_period == 0]

  if (!is.null(by) && (by != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(data_train, by)
    if (is.null(model$levels_)) {
      model$model_  <- list()
      model$levels_ <- names(ind_split)
      model$by_     <- by
    }
    for (x in names(ind_split)) {
      level_pos <- which(levels(data_train[[by]]) == x)[[1]]
      new_fit_default <- model$fit_default
      new_fit_default[["by"]] <- NULL
      new_fit_default[["by"]] <- NULL
      if ((length(model[["model_"]]) != length(model$levels_))
          || is.null(model$model_[[level_pos]])) {
        model_tmp <- R39Toolbox::MixtureModel(
          model$model_list, model$target_variable,
          fit_default = new_fit_default,
          predict_default = model$predict_default,
          transformation_function = model$transformation_function,
          expert_corrections = model$expert_corrections,
          expert_corrections_type = model$expert_corrections_type)
      } else {
        model_tmp <- model$model_[[level_pos]]
      }
      model$model_[[level_pos]] <- R39Toolbox::fit(
        model_tmp,
        data_train[ind_split[[x]], , drop = FALSE],
        bypass_transform = TRUE,
        weights = weights[ind_split[[x]]],
        algorithm = algorithm, loss_type = loss_type,
        precomputed_experts = expert_predictions[ind_split[[x]], , drop = FALSE])
    }
  } else {
    # The mixture model is fed in a online mode with all the observations
    # that do not have a weight equal to zero.
    # Note that there is no use of leading_period anymore.
    mask_predict <- which(
      (weights == 1) & (!is.na(rowSums(expert_predictions))))
    if (is.null(model[["model_"]]) || ("list" %in% class(model$model_))) {
      model$model_ <- opera::mixture(model = algorithm, loss.type = loss_type)
    }
    model$model_ <- predict(
      model$model_,
      newexperts = as.matrix(
        expert_predictions[mask_predict, , drop = FALSE]),
      data_train[mask_predict, model$target_variable],
      type = "model")
    new_weights <- predict(
      model$model_,
      newexperts = as.matrix(
        expert_predictions[mask_predict, , drop = FALSE]),
      data_train[mask_predict, model$target_variable],
      type = "weights")
    if (is.null(dim(new_weights))
        && (length(new_weights) == length(model$model_list)) ){
      new_weights <- t(as.data.frame(new_weights))
    }
    # save structure (= dates and corresponding weights)
    # save all mix weights (e.g. if one wants to visualize the mix evolution)
    date_control <- R39Toolbox::check_dates(data_train)
    if (date_control$tz == 'CET24') {
      rownames(new_weights) <- as.character(data_train[mask_predict, "date"])
    } else {
      rownames(new_weights) <- strftime(
        data_train[mask_predict, "date"],
        format = "%Y-%m-%d %H:%M %Z", tz = date_control$tz)
    }
    if (is.null(model$weights_)) {
      model$weights_ <- new_weights
    } else {
      model$weights_ <- rbind(model$weights_, new_weights)
    }
    # save this last weights upon this particular update in 'history' attribute
    if (!is.null(hist) || (model$fit_default[["hist"]] != FALSE)) {
      if ("character" %in% class(hist)) {
        hist_label <- hist
        hist_date  <- as.POSIXct(
          hist, format = "%F %H:%M:%S %Z", tz = date_control$tz)
      } else if ("POSIXct" %in% class(hist)) {
        hist_label <- strftime(
          hist, format = "%F %H:%M:%S %Z", tz = date_control$tz)
        hist_date  <- hist
      } else {
        hist_date  <- tail(data_train$date[weights == 1], 1)
        hist_label <- strftime(
          hist_date,
          format = "%F %H:%M:%S %Z", tz = date_control$tz)
      }
      model$history[[hist_label]] <- list(
        date   = hist_date,
        weights = model$model_$coefficients)
    }
  }
  return(model)
}


#' Prediction with a mixture model
#'
#' The prediction can be made in two manners: The first one is to
#' use fixed weights in the mixture (these weights have been
#' learnt by previously calling the 'fit' function) and to compute the
#' prediction as a weighted mean of the experts predictions.
#' This is not the way a short-term model is meant to be used, but it
#' is still used that way in some situations (e.g. to achieve a
#' prediction for several days ahead).
#'
#' The second and correct way to use a mixture model is to perform
#' several predictions with a weights update every time a new
#' observation comes. This is the purpose of the 'simulate' method
#' through which one can control the update dates and set a delay
#' after which the observations are available in an operational
#' situation.
#'
#' This method implements the "fixed-weights" prediction.
#'
#' @rdname predict
#' @method predict MixtureModel
#' @export
predict.MixtureModel <- function(model, data_prediction,
                                 bypass_transform = FALSE,
                                 precomputed_experts = NULL,
                                 leading_period = NULL,
                                 predict_as_date = NULL) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the model has been fit
  if (is.null(model$model_)) {
    stop(paste0("Please fit the mixture model before it can be used to ",
                "make a prediction."))
  }

  n_obs <- nrow(data_prediction)
  if (is.null(precomputed_experts)) {
    expert_predictions <- sapply(
      model$model_list, predict, data_prediction,
      bypass_transform = TRUE,
      leading_period = leading_period)
    if (is.null(dim(expert_predictions))
        && (length(expert_predictions) == length(model$model_list))) {
      expert_predictions <- t(as.data.frame(expert_predictions))
      rownames(expert_predictions) <- NULL
    }
  } else {
    expert_predictions <- precomputed_experts
  }
  if (!is.null(model$expert_corrections) && is.null(precomputed_experts)) {
    for (i in 1:ncol(expert_predictions)) {
      expert_predictions[, i] <- (
        switch(model$expert_corrections_type,
               "additive" = {
                 expert_predictions[, i] + model$expert_corrections[[i]]
               },
               "multiplicative" = {
                 expert_predictions[, i] * model$expert_corrections[[i]]
               }))
    }
  }

  # drop the leading period
  data_prediction <- data_prediction[leading_period == 0, , drop = FALSE]

  if (!is.null(model$by_) && (model$by_ != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_,
      expected_n_levels = length(model$model_))
    prediction <- rep(NA, length(which(leading_period == 0)))
    check <- lapply(
      names(ind_split),
      function(x) {
        level_pos <- which(model$levels_ == x)[[1]]
        if (is.null(level_pos)) {
          stop("Could not find level ", level, " in the levels the ",
               "model has been trained with.")
        }
        expert_predictions_tmp <- expert_predictions[ind_split[[x]], , drop = FALSE]
        data_prediction_tmp <- data_prediction[ind_split[[x]], , drop = FALSE]
        prediction[ind_split[[x]]] <<- predict(
          model$model_[[level_pos]], data_prediction_tmp,
          precomputed_experts = expert_predictions_tmp,
          bypass_transform = TRUE, predict_as_date = predict_as_date)
      })
  } else {
    # Perform a prediction with fixed weights
    # Note that there is no use of leading_period anymore.
    if (is.null(predict_as_date)) {
      if (is.null(model$model_$coefficients)) {
        #print("Using latest weights (uniform)")
        prediction <- as.numeric(rowMeans(expert_predictions))
      } else {
        #print(paste0("Using latest weights (", model$model_$coefficients, ")"))
        prediction <- predict(
          model$model_, newexperts = as.matrix(expert_predictions),
          type = 'response', online = FALSE)
      }
    } else {
      # get historized weights
      if (length(model$history) > 0) {
        all_past_dates <- lapply(
          1:length(model$history),
          function(x) { model$history[[x]]$date })
        all_past_dates <- do.call('c', all_past_dates)
        all_past_dates_filtered <- sort(
          all_past_dates[which(all_past_dates <= predict_as_date)])
        if (length(all_past_dates_filtered) > 0) {
          date_ind <- which(all_past_dates == tail(all_past_dates_filtered, 1))
          past_mix_weights <- model$history[[date_ind]]$weights
        } else {
          warning(
            paste0("No history available for specified date. ",
                   "Using uniform weights."))
            n_experts <- length(model$model_$coefficients)
            past_mix_weights <- rep(1 / n_experts, n_experts)
        }
      } else {
        warning("Cannot find historized weights. Using current weights.")
        past_mix_weights <- NULL
      }
      #print(paste0("Using weights: ", past_mix_weights))
      if (!is.null(past_mix_weights)) {
        model_histo <- model$model_
        # transform model
        model_histo$coefficients <- past_mix_weights
      } else {
        model_histo <- model$model_
      }
      prediction <- predict(
        model_histo, newexperts = as.matrix(expert_predictions),
        type = 'response', online = FALSE)
    }
  }

  return(as.numeric(prediction))
}
