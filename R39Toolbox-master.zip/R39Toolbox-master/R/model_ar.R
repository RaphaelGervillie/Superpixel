
#' Auto-regressive model
#'
#' @param target_variable Name of the target variable
#' @param lags Past observations to be considered to compute the forecast
#'
#' @return AutoRegressiveModel instance
#'
#' @export AutoRegressiveModel
AutoRegressiveModel <- function(target_variable, lags = 'auto',
                                transformation_function = NULL,
                                fit_default = NULL,
                                predict_default = NULL) {
  this <- ShortTermForecastModel(
    target_variable, transformation_function = transformation_function,
    fit_default = fit_default, predict_default = predict_default)

  this$predict_default <- append(this$predict_default, predict_default)

  this$lags <- lags

  class(this) <- append(class(this), "AutoRegressiveModel")
  return(this)
}


#' Estimation of an AutoRegressiveModel
#'
#' @param model : Mixture model to be considered
#' @param data_train : Data the model should be trained from
#'
#' @return the autoregressive model fit on the train data
#'
#' @rdname fit
#' @export
fit.AutoRegressiveModel <- function(model, data_train,
                                    bypass_transform = FALSE,
                                    leading_period = NULL, weights = NULL,
                                    by = NULL, ...) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- model$fit_default[["by"]]  # NULL if not defined
  }
  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }

  if (!is.null(by) && (by != FALSE)) {
    ind_split <- R39Toolbox:::split_data_by_factor(data_train, by)
    if (is.null(model$levels_)) {
      model$model_  <- list()
      model$levels_ <- levels(data_train[[by]])
      model$by_     <- by
    }
    for (x in names(ind_split)) {
      level_pos <- which(levels(data_train[[by]]) == x)[[1]]
      new_fit_default <- model$fit_default
      new_fit_default[["by"]] <- NULL
      new_fit_default[["by"]] <- NULL
      model_tmp <- R39Toolbox::AutoRegressiveModel(
        model$target_variable, model$lags,
        fit_default = new_fit_default,
        predict_default = model$predict_default,
        transformation_function = model$transformation_function)
      model$model_[[level_pos]] <- R39Toolbox::fit(
        model_tmp,
        data_train[ind_split[[x]], , drop = FALSE],
        bypass_transform = TRUE,
        weights = weights[ind_split[[x]]])
    }
  } else {
    mask_fit <- which(weights == 1)
    if (all(model$lags == 'auto')) {
      model$model_ <- ar(data_train[mask_fit, model$target_variable])
    } else {
      data_train_tmp <- data_train[mask_fit, ]
      model_order <- max(model$lags)
      n_obs_train <- nrow(data_train_tmp) - model_order
      data_train_tmp2 <- matrix(ncol = n_obs_train, nrow = length(model$lags))
      for (i in 1:length(model$lags)) {
        current_lag <- model$lags[[i]]
        data_train_tmp2[i, ] <- data_train_tmp[[model$target_variable]][
          current_lag:(current_lag + n_obs_train - 1)]
      }
      data_train_tmp2 <- as.data.frame(t(data_train_tmp2))
      data_train_tmp2$y <- data_train_tmp[[
        model$target_variable]][(model_order + 1):nrow(data_train_tmp)]
      lm_tmp <- lm(
        as.formula(paste(
          "y ~",
          paste(colnames(data_train_tmp2)[1:(ncol(data_train_tmp2) - 1)],
                collapse = "+"),
          "-1",
          sep = "")),
        data = data_train_tmp2)
      model$model_ <- lm_tmp
      model$coefficients_ <- as.numeric(coefficients(lm_tmp))
    }
  }

  model
}

#' Prediction with an autoregressive model
#'
#' The resulting prediction has the size of the input data. The
#' distinction between observed values and values to be predicted is
#' made using the 'leading_period' argument (1 for an observed value and 0
#' for a value to be predicted by the model). The observations for
#' which the associated weight is equal to 0 are copied (because they
#' are not forecasted) while the others are computed according to the
#' autoregressive model.
#'
#' @rdname predict
#' @method predict AutoRegressiveModel
#' @export predict.AutoRegressiveModel
#' @export
predict.AutoRegressiveModel <- function(model, data_prediction,
                                        bypass_transform = NULL,
                                        leading_period = NULL, ...) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the model has been fit
  if (is.null(model$model_)) {
    stop(paste0("Please fit the AR model before it can be used to ",
                "make a prediction."))
  }
  # check the presence of the target variable
  if (!model$target_variable %in% names(data_prediction)) {
    stop(paste0("No signal ('", model$target_variable,
                "') found to apply the autoregressive model."))
  }

  if (!is.null(model$by_) && (model$by_ != FALSE)) {
   # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_,
      expected_n_levels = length(model$model_))
    prediction <- rep(NA, nrow(data_prediction))
    check <- lapply(
        names(ind_split),
        function(x) {
          level_pos <- which(model$levels_ == x)[[1]]
          if (is.null(level_pos)) {
            stop("Could not find level ", level, " in the levels the ",
                 "model has been trained with.")
          }
          if (length(which(leading_period[ind_split[[x]]] == 0)) > 0) {
            prediction[ind_split[[x]]][leading_period[ind_split[[x]]] == 0] <<- predict(
              model$model_[[level_pos]], data_prediction[ind_split[[x]], ],
              bypass_transform = TRUE,
              leading_period = leading_period[ind_split[[x]]])
          }
        })
  } else {
    start_prediction <- which(leading_period == 0)[[1]]
    if (all(model$lags == 'auto')) {
      model_order <- model$model_$order
    } else {
      model_order <- max(model$lags)
    }
    # check the presence of leading data to apply the model
    if (model_order >= start_prediction) {
      stop(paste0('Cannot predict with an AR model if not ',
                  'enough leading data is provided'))
    } else {
      # check the presence of the target variable on the leading period
      check_tmp <- data_prediction[[model$target_variable]][
        (start_prediction - model_order):(start_prediction - 1)]
      if (all(model$lags == 'auto')) {
        if (any(is.na(check_tmp))) {
          warning("NA in AR model's leading data.")
        }
      } else {
        if (any(is.na(check_tmp[length(check_tmp) + 1 - model$lags]))) {
          warning("NA in AR model's leading data.")
        }
      }
    }

    prediction <- rep(NA, nrow(data_prediction))
    y <- data_prediction[[model$target_variable]]
    if (all(model$lags != 'auto')) {
      sapply(start_prediction:length(prediction),
             function(x) {
               lags_observations <- y[x - model$lags]
               prediction[x] <<- sum(model$coefficients_ * lags_observations)
               #if (mode != 'online') {
               # use AR's own prediction for the sequel
               y[x] <<- prediction[x]
               #}
             })
    } else {
      sapply(start_prediction:length(prediction),
             function(x) {
               mask_fit <- 1:(x - 1)
               data_fit <- data.frame(y[mask_fit])
               colnames(data_fit) <- model$target_variable
               #if (online_refit) && (mode == 'online')) {
               #  # refit makes no real sense if mode is not online
               #  model <- R39Toolbox::fit(model, data_fit,
               #                           bypass_transform = bypass_transform)
               #}
               prediction[x] <<- as.numeric(
                 predict(
                   model$model_, data_fit[[model$target_variable]],
                   n.ahead = 1)$pred)
               #if (mode != 'online') {
               # use AR's own prediction for the sequel
               y[x] <<- prediction[x]
               #}
             })
    }
  }

  return(prediction[leading_period == 0])
}


###############################################################################
### Combination mid-term forecast model + autoregressive model

#' Readjusted model
#'
#' @param target_variable Name of the target variable
#' @param forecast_model Model to be readjusted with AR
#' @param ar_model AR model for readjustment
#'
#' @return ReadjustedModel instance
#'
#' @export ReadjustedModel
ReadjustedModel <- function(target_variable,
                            forecast_model, ar_model,
                            recal_variable = NULL,
                            fit_default = NULL) {
  this <- ShortTermForecastModel(target_variable, fit_default = fit_default)

  this$base_model <- forecast_model
  this$ar_model   <- ar_model
  if (is.null(recal_variable)) {
    this$recal_variable <- this$target_variable
  } else {
    this$recal_variable <- recal_variable
  }

  class(this) <- append(class(this), "ReadjustedModel")
  return(this)
}


#' @export
fit.ReadjustedModel <- function(model, data_train,
                                bypass_transform = FALSE,
                                leading_period = NULL, weights = NULL,
                                by = NULL, ...) {
  prediction_base <- predict(model$base_model, data_train)
  data_train[[model$ar_model$target_variable]] <- (
    data_train[[model$target_variable]] - prediction_base)
  model$ar_model <- R39Toolbox::fit(
    model$ar_model, data_train, bypass_transform = bypass_transform,
    leading_period = leading_period, weights = weights, by = by)

  model
}

#' @method predict ReadjustedModel
#' @export
predict.ReadjustedModel <- function(model, data_prediction,
                                    bypass_transform = NULL,
                                    leading_period = NULL,
                                    by = NULL, ...) {
  if (!model$recal_variable %in% colnames(data_prediction)) {
    stop(paste0(
      "'", model$recal_variable, "' variable not found ",
      "in 'data_prediction'"))
  }
  prediction_base <- predict(model$base_model, data_prediction)
  data_prediction[[model$ar_model$target_variable]] <- (
    data_prediction[[model$recal_variable]] - prediction_base)
  prediction_readjusted <- predict(
    model$ar_model, data_prediction, leading_period = leading_period)
  if (length(which(leading_period == 0)) > 0) {
    prediction <- prediction_readjusted + prediction_base[leading_period == 0]
  } else {
    prediction <- prediction_readjusted + prediction_base
  }

  return(prediction)
}
