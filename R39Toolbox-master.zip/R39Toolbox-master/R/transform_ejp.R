## R39Toolbox
## @copyright EDF R&D 2015
## 2015-09-10
## Benoit Thieurmel

#' Transform EJP
#'
#' Transform EJP. Function to transform daily EJP data to other ts.
#'
#' Daily data, so there is no input timezone to be considered.
#'
#'
#' @param data : data.frame to transform
#' @param col_ejp : Column name(s) of quantitative EJP variable(s) to
#'   be be transformed. Default to setdiff(colnames(data), "date")
#' @param ts : Increment of the sequence, in seconds.  Default to 10 *
#'   60 (10 min)
#' @param tz : Timezone for the output. Defaut to 'UTC'. Can be
#'   'CET24'.
#' @param time_begin: time of beginning EJP. "HH:MM:SS"
#' @param time_end: time of ended EJP. "HH:MM:SS".
#'
#' @return a data.frame.
#'
#' @seealso \itemize{
#' \item \code{\link{transform_EJP}}
#' \item \code{\link{generate_calendar}}, \code{\link{convertToLocalHour24}}
#' }
#' @export transform_EJP
#' @examples
#' date <- seq(as.Date("2010/10/10"), as.Date("2010/10/12"), "days")
#' data <- data.frame(date = date, NORD = c(0, 1, 1), SUD = c(1, 0, 0))
#'
#' res <- transform_EJP(data, ts = 150 * 60)
#' View(res)
#'
#' res <- transform_EJP(data, tz = "CET",
#'                     time_begin = "08:00:00", time_end = "04:30:00")
#' View(res)
#'
#' res <- transform_EJP(data, tz = "CET", ts = 30*60,
#'                     time_begin = "08:00:00", time_end = "10:30:00")
#' View(res)
#'
#' # changement d'heure et CET24
#' date <- seq(as.Date("2010/03/27"), as.Date("2010/03/29"), "days")
#' data <- data.frame(date = date, NORD = c(0, 1, 1), SUD = c(1, 0, 0))
#'
#' res <- transform_EJP(data, tz = "CET")
#' View(res)
#' res <- transform_EJP(data, tz = "CET24")
#' View(res)
#'
#' date <- seq(as.Date("2010/10/30"), as.Date("2010/11/01"), "days")
#' data <- data.frame(date = date, NORD = c(0, 1, 1), SUD = c(1, 0, 0))
#'
#' res <- transform_EJP(data, tz = "CET")
#' View(res)
#' res <- transform_EJP(data, tz = "CET24")
#' View(res)
#'
#' @note Copyright 2015 EDF
transform_EJP <- function(data, col_ejp = setdiff(colnames(data), "date"),
                         tz = "UTC", ts = 10 * 60,
                         time_begin = "06:00:00", time_end = "05:50:00") {
  col_date <- "date"
  check_out_cet24 <- tz == "CET24"
  if (check_out_cet24) {
    tz <- "UTC"
  }

  ### Check function arguments ----------------------------
  # check data are daily data
  date_without_hour <- strptime(data$date, format = "%Y-%m-%d")
  if (length(unique(date_without_hour)) != length(date_without_hour)) {
    stop("Please provide daily data to the 'transform_EJP' function.")
  }

  begin_ejp <- strptime(time_begin, format = "%H:%M:%S", tz = tz)
  if (is.na(begin_ejp)) {
    stop(paste0("Invalid 'time_begin' argument. ",
                "Must be in %H:%M:%S format, 06:00:00 for example"))
  }
  end_ejp <- strptime(time_end, format = "%H:%M:%S", tz = tz)
  if (is.na(end_ejp)) {
    stop(paste0("Invalid 'time_end' argument. ",
                "Must be in %H:%M:%S format, 05:50:00 for example"))
  }

  if (!col_date %in% colnames(data)) {
    stop(paste0("Can't find ", col_date, " column in 'data'"))
  }

  if (any(!col_ejp %in% colnames(data))) {
    stop(paste0("Can't find ", col_ejp, " column in 'data'"))
  }

  check_ejp <- sapply(data[, col_ejp, drop = FALSE], class)
  if (any(check_ejp %in% c("factor", "character", "logical"))) {
    stop("Some columns are not quantitative")
  }

  # les EJP sont recu par jour
  # passage en date si necessaire pour le controle
  if (!"Date" %in% class(data[, col_date])) {
    warning("Converting ", col_date, " to Date with as.Date()")
    data[, col_date] <- as.Date(as.character(data[, col_date]))
  }

  # controle : sequence complete de dates
  dates <- data[, col_date]
  check.seq_date <- identical(
    dates, seq(dates[1], dates[length(dates)], "day"))
  if (!check.seq_date) {
    warning(paste0("Incomplete data, missing some days. ",
                   "Complete missing value(s) with 0"))
  }

  data <- data[, intersect(colnames(data), c(col_date, col_ejp))]
  order_colmuns <- colnames(data)

  ### Preprocessings ----------------------------
  # donnees manquantes -> rajout de 0, et rajout d'un jour supplementaire
  data_check <- data.frame(
    date = seq(data[1, col_date], data[nrow(data), col_date] + 1, by = "days"))
  colnames(data_check)[1] <- col_date
  data <- base::merge(data, data_check, by = col_date, all = TRUE)
  data[is.na(data)] <- 0

  # generate output date sequence
  data[, col_date] <- as.POSIXct(as.character(data[, col_date]), tz = tz)
  seq_date <- as.POSIXlt(seq(from = data[1, col_date],
                             to   = data[nrow(data), col_date],
                             by   = ts))

  value_days <- table(format(seq_date, format = "%Y-%m-%d", tz = tz))
  data <- data[as.Date(data[, col_date], tz = tz)
               %in% as.Date(seq_date, tz = tz), ]
  extract_time <- format(seq_date, "%H:%M:%S")

  if (end_ejp < begin_ejp) {
    flage_ejp_date_current <- extract_time >= time_begin
    flage_ejp_date_next    <- extract_time <= time_end
    ejp_transform <- do.call("cbind", lapply(col_ejp, function(i) {
      value_ejp_current <- rep(data[, i], value_days) * flage_ejp_date_current
      value_ejp_next    <- (rep(c(0, data[-nrow(data), i]), value_days)
                            * flage_ejp_date_next)
      as.numeric(value_ejp_current) + as.numeric(value_ejp_next)
    }))
  } else {
    flage_ejp_date_current <- (extract_time <= time_end
                            & extract_time >= time_begin)
    ejp_transform <- do.call("cbind", lapply(2:ncol(data), function(i) {
      rep(data[, i], value_days) * flage_ejp_date_current
    }))
  }

  data_transform <- data.frame(date = seq_date, ejp_transform)
  colnames(data_transform) <- c(col_date, col_ejp)
  data_transform <- data_transform[-nrow(data_transform), order_colmuns]

  # convert to CET24 if needed
  if (check_out_cet24) {
    data_transform[, col_date] <- format.POSIXct(data_transform[, col_date],
                                                 "%Y-%m-%d %H:%M:%S")
    class(data_transform[, col_date]) <- "CET24"
  }

  data_transform
}


#' Create tarif variables
#'
#' Create one or several tarif variable column(s).
#'
#' The start and end hours can be specified according to the tarif
#' one wants to use. Standard values are:
#'  - 07:00:00 / 06:30:00 for EJPs
#'  - 06:00:00 / 05:30:00 for Tempos
#' Currently available tarifs are EJPs ('Nord', 'PACA', 'OUest', 'Sud') and
#' Tempos ('blanc' and 'rouge'). These are available from 2008-01-01 to
#' 2015-07-31, but this can be easily extended by modifying the corresponding
#' dataset (SpecialTarifs.rda) provided with this package.
#'
#' @param data : data.frame to which we want to add special tarif
#'   columns
#' @param type : Name of the special tarif column(s) one wants to
#'   create
#' @param hour_begin: Time at which the special tarif is supposed to
#'   start.  "HH:MM:SS" format.
#' @param hour_end: Time at which the special tarif is supposed to
#'   end.  "HH:MM:SS" format.
#'
#' @return a data.frame which consist of the special tarif column(s) only.
#'
#' @seealso \itemize{
#' \item \code{\link{transform_EJP}}}
#'
#' @examples
#' data <- R39Toolbox::R39ExData
#' data$EJPNord <- R39Toolbox::generate_tarif(data, type = c('EJPNord'))
#'
#' data <- R39Toolbox::R39ExData
#' data <- cbind(data, R39Toolbox::generate_tarif(data, type = c('Tempo'),
#'                                                hour_begin = "06:00:00",
#'                                                hour_end = "05:30:00"))
#'
#' @export
generate_tarif <- function(data, type = c('EJP', 'Tempo'),
                           hour_begin = "07:00:00", hour_end = "06:30:00") {
  col_date <- "date"
  valid_variables <- c("EJP", "EJPNord", "EJPPACA", "EJPOuest", "EJPSud",
                       "Tempo", "TempoBlanc", "TempoRouge")

  date_control <- R39Toolbox::check_dates(data)
  initial_timezone <- date_control$tz
  initial_timestep <- date_control$ts
  if (initial_timestep == "non-uniform") {
    if (length(columns_quali) > 0) {
      stop(paste0("The input dataset contains qualitative columns ",
                  "but its timestep is not uniform. It is therefore ",
                  "impossible to infer the values for the qualitative ",
                  "variables on the output grid."))
    } else {
      initial_timestep <- target_timestep
    }
  }

  # analyse provided data
  if (initial_timezone != 'CET24') {
    date_begin <- strftime(data$date[[1]], format = "%Y-%m-%d 00:00",
                           tz = initial_timezone)
    date_end   <- strftime(data$date[[dim(data)[[1]]]],
                           format = "%Y-%m-%d 00:00",
                           tz = initial_timezone)
  } else {
    date_begin <- paste0(strsplit(data$date[[1]], ' ')[[1]][[1]], " 00:00")
    date_end   <- paste0(strsplit(data$date[[dim(data)[[1]]]], ' ')[[1]][[1]],
                         " 00:00")
  }
  all_dates    <- R39Toolbox::generate_calendar(
    date_begin, date_end,
    ts = 24 * 60 * 60, tz = 'UTC', variables = c('date'))
  # get special tarifs information
  special_tarifs <- R39Toolbox::SpecialTarifs
  if ((data$date[[1]] < special_tarifs$date[[1]])
      | (data$date[[dim(data)[[1]]]]
         > special_tarifs$date[[dim(special_tarifs)[[1]]]])) {
    warning(paste0("Special tarifs information is not available for some ",
                   "dates in the dataset. These will be replaced by NAs"))
  }
  temp <- base::merge(all_dates, special_tarifs,
                      by = 'date', sort = FALSE, all.x = TRUE)

  # select tarifs variables
  if (!all(type %in% valid_variables)) {
    stop("Wrong variable provided in 'type'")
  }
  selected_variables <- c()
  if ('EJP' %in% type) {
    selected_variables <- c(selected_variables,
                            "EJPNord", "EJPPACA", 'EJPOuest', "EJPSud")
    type <- type[-which(type == 'EJP')]
  }
  if ('Tempo' %in% type) {
    selected_variables <- c(selected_variables, "TempoBlanc", "TempoRouge")
    type <- type[-which(type == 'Tempo')]
  }
  selected_variables <- unique(c(selected_variables, type))  # rmv duplicates
  # warning in case start or end hour are suspicious
  if (any(c("EJPNord", "EJPPACA", "EJPOuest", "EJPSud") %in% selected_variables)
      & ((hour_begin != '07:00:00') | (hour_end != '06:30:00'))) {
    warning(paste0("EJP variables will be generated but start hour is ",
                   hour_begin, " and end hour is ", hour_end, "."))
  }
  if (any(c("TempoRouge", "TempoBlanc") %in% selected_variables)
      & ((hour_begin != '06:00:00') | (hour_end != '05:30:00'))) {
    warning(paste0("Tempo variables will be generated but start hour is ",
                   hour_begin, " and end hour is ", hour_end, "."))
  }


  tarifs_variables <- temp[, c('date', selected_variables)]
  res <- transform_EJP(tarifs_variables, col_ejp = selected_variables,
                      tz = initial_timezone, ts = initial_timestep,
                      time_begin = hour_begin, time_end = hour_end)
  res[, selected_variables]
}