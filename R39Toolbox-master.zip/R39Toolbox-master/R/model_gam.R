

#' GAM model
#'
#' A GAM model is entirely defined by a formula.
#'
#' @param formula : The GAM-compatible formula corresponding to the model.
#'                  Note that the specification of the formula puts
#'                  a constraint on the data the model will be used on
#'                  (column names).
#'
#' @examples
#' model <- R39Toolbox::GeneralizedAdditiveModel(
#'   "conso ~ s(Temperature) + s(Posan)")
#'
#' @export
GeneralizedAdditiveModel <- function(formula, fit_default = NULL,
                                     transformation_function = NULL,
                                     clean = FALSE, knots = NULL) {
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)

  # TODO : add GAM options such as "family=gaussian()", "weights", ...
  this$clean   <- clean
  this$formula <- formula
  this$knots   <- knots

  class(this) <- append(class(this), "GeneralizedAdditiveModel")
  return(this)
}


#' Estimation of a GeneralizedAdditiveModel
#'
#' We use the mgcv interface to fit a GAM model.
#' If specified by the user, the model is fit according to a factor
#' via the mecanism that is defined in the MidTermForecastModel fit
#' method.
#'
#' @rdname fit
#' @export
fit.GeneralizedAdditiveModel <- function(model, data_train,
                                         bypass_transform = FALSE,
                                         leading_period = NULL, weights = NULL,
                                         by = NULL, ...) {
  # TODO: check data_train columns are ok
  library(mgcv)
  model$model_ <- gam(
    as.formula(model$formula),
    data = data_train[leading_period == 0, ],
    weights = weights[leading_period == 0],
    knots = model$knots)
  if (!is.null(model$clean) && (model$clean)) {
    model$model_$model <- NULL
    model$model_$weights <- NULL
    model$model_$prior_weights <- NULL
    model$model_$Ve <- NULL
    model$model_$Vp <- NULL
    model$model_$rV <- NULL
    model$model_$fitted_values <- NULL
  }

  return(model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @method predict GeneralizedAdditiveModel
#' @export
predict.GeneralizedAdditiveModel <- function(model, data_prediction,
                                             bypass_transform = FALSE,
                                             leading_period = NULL) {
  library(mgcv)
  as.numeric(predict(model$model_, data_prediction))[leading_period == 0]
}


#' Prediction of the target variable from observations
#'
#' @rdname predict_details
#' @export
predict_details.GeneralizedAdditiveModel <- function(model, data_prediction,
                                                     bypass_transform = FALSE,
                                                     leading_period = NULL) {
  library(mgcv)
  prediction <- predict(
    model$model_, data_prediction, type = 'terms')[
      leading_period == 0, , drop = FALSE]
  # adds intercept if there is one in the model
  # XXX: implements the offsets case
  if ("(Intercept)" %in% names(model$model_$coefficients)) {
    colnames_old <- colnames(prediction)
    prediction <- cbind(prediction, model$model_$coefficients[['(Intercept)']])
    colnames(prediction) <- c(colnames_old, '(Intercept)')
  }

  prediction
}
