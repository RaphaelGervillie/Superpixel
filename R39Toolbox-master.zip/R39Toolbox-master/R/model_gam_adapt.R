
#' GAM adaptative models
#'
#' A GAM adaptative model is defined from a GAM model and a set of fixed/adapted
#' effects that are corrected by some coefficients called "the alphas".
#'
#' @param gam_model Base GAM model on top of which we build an
#'   adaptation.
#' @param fixed_global_effects Name of the global effects we don't
#'   want to change.  (quantitative or qualitative) NULL by default
#' @param fixed_factor_effects Name of qualitative effects for which
#'   there is at least one level we do not want to adapt.  NULL by
#'   default
#' @param fixed_factor_levels Name of the modalities of the
#'   qualitative effects from fixed_factor_effects we do not want to
#'   adapt.  NULL by default
#' @param adapted_poly_effects Named list of adapted poly effects,
#'   with a vector of correponding degrees. For instance,
#'   list("effect" = c(2, 3, 4)).
#' @param mu Parameter that controls the depth with the which we take
#'   into the history during an adaptation
#'
#' @export
GeneralizedAdditiveModelAdaptative <- function(gam_model,
                                               fixed_global_effects = NULL,
                                               fixed_factor_effects = NULL,
                                               fixed_factor_levels = NULL,
                                               adapted_poly_effects = NULL,
                                               max_obs = NULL,
                                               mu = 1, fit_default = list(),
                                               transformation_function = NULL) {
  if (is.null(gam_model$model_)) {
    stop(paste0("Please fit the GAM model before using ",
                "it in an adaptative structure."))
  }
  target_variable <- as.character(gam_model$model_$formula)[2]
  if (is.null(gam_model$by_)) {
    target_variable <- as.character(gam_model$model_$formula)[2]
  } else {
    target_variable <- as.character(gam_model$model_[[1]]$model_$formula)[2]
  }
  this <- ShortTermForecastModel(
    target_variable, transformation_function = transformation_function,
    fit_default = fit_default)

  this$gam_model <- gam_model
  this$mu <- mu
  this$fixed_global_effects <- fixed_global_effects
  this$fixed_factor_effects <- fixed_factor_effects
  this$fixed_factor_levels  <- fixed_factor_levels
  this$adapted_poly_effects <- adapted_poly_effects
  this$max_obs              <- max_obs

  this$alphas_ <- NULL
  this$model_  <- "fit->ok"  # one can use an adaptative model with NULL alphas

  class(this) <- append(class(this), "GeneralizedAdditiveModelAdaptative")
  return(this)
}


#' @export
fit.GeneralizedAdditiveModelAdaptative <- function(model, data_train,
                                                   bypass_transform = FALSE,
                                                   leading_period = NULL,
                                                   weights = NULL, hist = NULL,
                                                   ...) {
  library(Adada)
  # adaptation according to a factor depending on the underlying GAM model
  by <- model$gam_model$by_
  # check weights
  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }

  if (!is.null(by) && (by != FALSE)) {
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_train, by, expected_n_levels = length(model$gam_model$model_))
    model$by_     <- by
    model$levels_ <- model$gam_model$levels_
    model$model_  <- list()
    for (x in names(ind_split)) {
      level_pos <- which(model$levels_ == x)[[1]]
      if (is.null(level_pos)) {
        stop("Could not find level ", level, " in the levels the ",
             "model has been trained with.")
      }
      new_fit_default <- model$fit_default
      new_fit_default[["by"]] <- NULL
      new_fit_default[["by"]] <- NULL
      model_gam_tmp <- model$gam_model$model_[[level_pos]]
      model_tmp <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
        model_gam_tmp,
        fixed_global_effects = model$fixed_global_effects,
        fixed_factor_effects = model$fixed_factor_effects,
        fixed_factor_levels  = model$fixed_factor_levels,
        adapted_poly_effects = model$adapted_poly_effects,
        mu = model$mu, fit_default = new_fit_default,
        max_obs = model$max_obs,
        transformation_function = model$transformation_function)
      model$model_[[level_pos]] <- R39Toolbox::fit(
        model_tmp, data_train[ind_split[[x]], ],
        bypass_transform = TRUE,
        by = FALSE,  # very important to avoid infinite loop
        leading_period = leading_period[ind_split[[x]]],
        weights = weights[ind_split[[x]]])
    }
  } else {
    if (nrow(data_train[leading_period == 0, ]) == 0) {
      warning("Empty data: no model will be fit")
      return(model)
    }
    model$alphas_ <- Adada::fit_alphas(
      model$gam_model$model_,
      data_train[leading_period == 0, ],
      invalid_obs = weights[leading_period == 0] == 0,
      mu = model$mu, method = "lmwithintercept",
      fixed_global_effects = model$fixed_global_effects,
      fixed_factor_effects = model$fixed_factor_effects,
      fixed_factor_levels  = model$fixed_factor_levels,
      adapted_poly_effects = model$adapted_poly_effects,
      max_obs = model$max_obs)
    model$model_ <- model$alphas_
    # save structure
    if (!is.null(hist) || (model$fit_default[["hist"]] != FALSE)) {
      date_control <- R39Toolbox::check_dates(data_train)
      if ("character" %in% class(hist)) {
        hist_label <- hist
        hist_date  <- as.POSIXct(
          hist, format = "%F %H:%M:%S %Z", tz = date_control$tz)
      } else if ("POSIXct" %in% class(hist)) {
        hist_label <- strftime(
          hist, format = "%F %H:%M:%S %Z", tz = date_control$tz)
        hist_date  <- hist
      } else {
        hist_date  <- tail(data_train$date[weights == 1], 1)
        hist_label <- strftime(
          hist_date,
          format = "%F %H:%M:%S %Z", tz = date_control$tz)
      }
      model$history[[hist_label]] <- list(
        date   = hist_date,
        alphas = model$alphas_)
    }
  }

  return(model)
}


#' @method predict GeneralizedAdditiveModelAdaptative
#' @export
predict.GeneralizedAdditiveModelAdaptative <- function(model, data_prediction,
                                                       bypass_transform = FALSE,
                                                       leading_period = NULL,
                                                       predict_as_date = NULL) {
  library(Adada)
  if (!(!is.null(model$by_) && (model$by_ != FALSE)) &&
        (model$model_ == "fit->ok")) {
    prediction <- predict(model$gam_model, data_prediction, bypass_transform = bypass_transform, leading_period = leading_period)
    return(as.numeric(prediction))
  }

  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # drop the leading period
  data_prediction <- data_prediction[leading_period == 0, , drop = FALSE]

  if (!is.null(model$by_) && (model$by_ != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_,
      expected_n_levels = length(model$model_))
    prediction <- rep(NA, length(which(leading_period == 0)))
    check <- lapply(
      names(ind_split),
      function(x) {
        level_pos <- which(model$levels_ == x)[[1]]
        if (is.null(level_pos)) {
          stop("Could not find level ", level, " in the levels the ",
               "model has been trained with.")
        }
        data_prediction_tmp <- data_prediction[ind_split[[x]], , drop = FALSE]
        prediction[ind_split[[x]]] <<- predict(
          model$model_[[level_pos]], data_prediction_tmp,
          bypass_transform = TRUE)
      })
  } else {
    # Perform a prediction with fixed weights
    # Note that there is no use of leading_period anymore.
    if (is.null(predict_as_date)) {
      prediction <- Adada::predict_adaptative(
        model$gam_model$model_, data_prediction,
        alphas = model$alphas_)
    } else {
      # get historized alphas
      if (length(model$history) > 0) {
        all_past_dates <- lapply(
          1:length(model$history),
          function(x) { model$history[[x]]$date })
        all_past_dates <- do.call('c', all_past_dates)
        all_past_dates_filtered <- sort(
          all_past_dates[which(all_past_dates <= predict_as_date)])
        if (length(all_past_dates_filtered) > 0) {
          date_ind <- which(all_past_dates == tail(all_past_dates_filtered, 1))
          past_alphas <- model$history[[date_ind]]$alphas
        } else {
          warning("No history available for specified date. Using no alphas.")
          past_alphas <- NULL
        }
      } else {
        warning("Cannot find historized alphas. Using current alphas.")
        past_alphas <- model$alphas_
      }
      # prediction as if date was predict_as_date
      prediction <- Adada::predict_adaptative(
        model$gam_model$model_, data_prediction,
        alphas = past_alphas)
    }
  }

  return(as.numeric(prediction))
}



#' @rdname predict_details
#' @export
predict_details.GeneralizedAdditiveModelAdaptative <- function(
    model, data_prediction, bypass_transform = FALSE,
    leading_period = NULL, predict_as_date = NULL) {
  library(Adada)
  if (R39Toolbox::has_empty_alphas(model)) {
    prediction <- predict_details(
      model$gam_model, data_prediction,
      bypass_transform = bypass_transform, leading_period = leading_period)
    return(prediction)
  } 

  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # drop the leading period
  data_prediction <- data_prediction[leading_period == 0, , drop = FALSE]

  if (!is.null(model$by_) && (model$by_ != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_,
      expected_n_levels = length(model$model_))
    level_pos <- which(model$levels_ == names(ind_split)[[1]])[[1]]
    prediction_tmp <- predict_details(
      model$model_[[level_pos]], bypass_transform = TRUE,
      data_prediction[ind_split[[names(ind_split)[[1]]]], ])
    prediction <- as.data.frame(matrix(
      nrow = nrow(data_prediction), ncol = ncol(prediction_tmp)))
    colnames(prediction) <- colnames(prediction_tmp)
    check <- lapply(
      names(ind_split),
      function(x) {
        level_pos <- which(model$levels_ == x)[[1]]
        if (is.null(level_pos)) {
          stop("Could not find level ", level, " in the levels the ",
               "model has been trained with.")
        }
        data_prediction_tmp <- data_prediction[ind_split[[x]], , drop = FALSE]
        prediction_tmp <- predict_details(
          model$model_[[level_pos]], data_prediction_tmp,
          bypass_transform = TRUE)
        prediction[ind_split[[x]], colnames(prediction_tmp)] <<- prediction_tmp
      })
  } else {
    gam_model <- model$gam_model$model_
    # Perform a prediction with fixed weights
    # Note that there is no use of leading_period anymore.
    prediction <- as.data.frame(Adada::predict_adaptative(
      gam_model, data_prediction,
      alphas = model$alphas_, detail = TRUE))
    # XXX <virgile> The code above was added before (Intercept) was dealt with
    # inside Adada. Now it is the cas so we removed that part of the code. But note
    # that there would be some variables that still need some extra treatment with
    # the template code above ((weights), (offsets)). That is why the code is still
    # here, but commented.
    ## # adds intercept if there is one in the model
    ## # XXX: implements the offsets case
    ## if ("(Intercept)" %in% names(gam_model$coefficients)) {
    ##   if ("(Intercept)" %in% names(model$alphas_)) {
    ##     prediction[['(Intercept)']] <- (
    ##       (model$alphas_[['(Intercept)']] + 1)
    ##       * gam_model$coefficients[['(Intercept)']])
    ##   } else {
    ##     prediction[['(Intercept)']] <- gam_model$coefficients[['(Intercept)']]
    ##   }
    ## }
  }

  return(as.data.frame(prediction))
}
