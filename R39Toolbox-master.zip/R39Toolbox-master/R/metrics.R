## R39Toolbox
## @copyright EDF R&D 2016


#' MAPE (Mean Absolute Percentage Error)
#'
#' @param obs, observed data
#' @param fit, fitted data
#' @param weights, for weighted indicators. Default = NULL means that
#'   all observations share the same weight.
#' @param na.rm, Remove NAs ? Default = TRUE.
#' @param normalized, logical. Default is FALSE. If TRUE, the RMSE
#'   value is divided by \code{mean(x)}.  Useful to compare
#'   performance of multiple curves forecasts with different mean
#'   values.
#' @examples
#'
#' mape(obs = c(1, 2), fit = c(2, 5))
#' mape(obs = c(0, 1, 2), fit = c(1, 2, 5))
#' mape(obs = c(1, 2), fit = c(2, 5), weights = c(1, 3))
#' mape(obs = c(1, 2), fit = c(2, 5), weights = c(3, 1))
#'
#' @export
mape <- function(obs, fit, weights = NULL, na.rm = TRUE) {
  if (length(obs) != length(fit)) {
    stop("'obs' & 'fit' must have same length")
  }
  if (is.null(weights)) {
    weights <- rep(1, length(obs))
  } else {
    if (length(weights) != length(obs)) {
      stop("'obs' & 'weights' must have the same length.")
    }
    if (any(weights < 0) | sum(weights) == 0) {
      stop("Weights must be positive and all least one weight must be non 0.")
    }
  }

  ind.0 <- which(obs == 0)
  ind.NA <- which((is.na(obs) | is.na(fit)) & na.rm)
  ind <- union(ind.NA, ind.0)
  if (length(ind) > 0) {
    obs <- obs[-ind]
    fit <- fit[-ind]
    weights <- weights[-ind]

    warning(sprintf("Excluding %i points where obs == 0 and %i points where obs or fit = NA.
                    Note that you can't divide by 0.
                    Maybe it is relevant changing indicator :
                    Try mae() or rmse() instead.", length(ind.0), length(ind.NA)),
            call. = FALSE)
  }
  return(1 / sum(weights) * sum(weights * abs((obs - fit) / obs)))
}


#' RMSE (Root Mean Square Error)
#'
#' @examples
#'
#' rmse(obs = c(0, 1, 2), fit = c(1, 2, 5))
#' rmse(obs = c(1, 2), fit = c(2, 5), weights = c(1, 3))
#' rmse(obs = c(1, 2), fit = c(2, 5), weights = c(3, 1))
#' rmse(obs = c(1, 2), fit = c(2, 5), weights = c(3, 1), normalized = TRUE)
#'
#' @export
rmse <- function(obs, fit, weights = NULL, na.rm = TRUE, normalized = FALSE) {
  if (length(obs) != length(fit)) {
    stop("'obs' & 'fit' must have the same length.")
  }
  if (is.null(weights)) {
    weights <- rep(1, length(obs))
  } else {
    if (length(weights) != length(obs)) {
      stop("'obs' & 'weights' must have the same length.")
    }
    if (any(weights < 0) | sum(weights) == 0) {
      stop("Weights must be positive and all least one weight must be non 0.")
    }
  }
  if (mean(obs) == 0 & normalized){
    stop("Cannot use normalized==TRUE with mean(obs) = 0.")
  }
  ind <- which((is.na(obs) | is.na(fit)) & na.rm)
  if (length(ind) > 0){
    obs <- obs[-ind]
    fit <- fit[-ind]
    weights <- weights[-ind]
    warning(sprintf("Excluding %i point(s) where obs or fit = NA.", length(ind)),
            call. = FALSE)
  }
  if (normalized)
    return(sqrt(1 / sum(weights) * sum(weights * (obs - fit) ^ 2)) / mean(obs, na.rm = na.rm))
  else return(sqrt(1 / sum(weights) * sum(weights * (obs - fit) ^ 2)))
}


#' MAE (Mean Absolute Error)
#'
#' @examples
#'
#' mae(obs = c(0, 1, 2), fit = c(1, 2, 5))
#' mae(obs = c(1, 2), fit = c(2, 5), weights = c(1, 3))
#' mae(obs = c(1, 2), fit = c(2, 5), weights = c(3, 1))
#'
#' @export
mae <- function(obs, fit, weights = NULL, na.rm = TRUE) {
  if (length(obs) != length(fit)) {
    stop("'obs' & 'fit' must have the same length.")
  }

  if (is.null(weights)) {
    weights <- rep(1, length(obs))
  } else {
    if (length(weights) != length(obs)) {
      stop("'obs' & 'weights' must have the same length.")
    }
    if (any(weights < 0) | sum(weights) == 0) {
      stop("Weights must be positive and all least one weight must be non 0.")
    }
  }
  ind <- which((is.na(obs) | is.na(fit)) & na.rm)
  if (length(ind) > 0){
    obs <- obs[-ind]
    fit <- fit[-ind]
    weights <- weights[-ind]
    warning(sprintf("Excluding %i point(s) where obs or fit = NA.", length(ind)),
            call. = FALSE)
  }
  return(1 / sum(weights) * sum(weights * abs(obs - fit)))
}
