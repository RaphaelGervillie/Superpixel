#' Random Forest Model
#' 
#' @param target_variable 
#' @param min_node_size 
#' @param mtry 
#' @param n_trees 
#' @param fit_seed 
#' @param num_threads 
#' @param formula 
#' @param fit_default 
#' @param transformation_function 
#'
#' @export
RandomForestModel <- function(target_variable,
                              min_node_size = NULL,
                              mtry = NULL,
                              max_depth = NULL,
                              splitrule = NULL,
                              n_trees = 500,
                              fit_seed = 1,
                              n_threads = 1, # avoid parallelization surprise
                              formula = NULL,
                              fit_default = NULL,
                              transformation_function = NULL) {
  
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable <- target_variable

  # object parameters
  this$min_node_size  <- min_node_size
  this$mtry           <- mtry
  this$max_depth      <- max_depth
  this$splitrule      <- splitrule
  this$n_trees        <- n_trees
  this$fit_seed       <- fit_seed
  this$n_threads      <- n_threads
  
  if (!is.null(formula)) {
    this$formula <- formula
  } else {
    this$formula <- paste0(target_variable, " ~ .")
  }
  
  class(this) <- append(class(this), "RandomForestModel")
  return(this)
}


#' Estimation of a RandomForestModel
#'
#' @rdname fit
#' @export
fit.RandomForestModel <- function(mid_term_model, data_train,
                                  bypass_transform = FALSE,
                                  leading_period = NULL, weights = NULL,
                                  by = NULL) {  
  mask_train <- which(weights == 1)
  # fit by formula
  library(ranger)
  mid_term_model$model_ <- ranger(
    as.formula(mid_term_model$formula),
    data = data_train[mask_train, ],
    min.node.size = mid_term_model$min_node_size,
    max.depth = mid_term_model$max_depth,
    splitrule = mid_term_model$splitrule,
    mtry = mid_term_model$mtry,
    seed = mid_term_model$fit_seed,
    num.threads = mid_term_model$n_threads,
    num.trees = mid_term_model$n_trees)
  
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @method predict RandomForestModel
#' @export
predict.RandomForestModel <- function(model, data_prediction,
                                      bypass_transform = FALSE,
                                      leading_period = NULL) {
  library(ranger)
  prediction <- predict(model$model_, data = data_prediction)$predictions
  
  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }

  return(prediction)
}
