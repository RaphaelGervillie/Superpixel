#' Xgboost implementation 
#' 
#' @param target_variable 
#'
#' @param eta 
#' @param gamma 
#' @param max_depth 
#' @param min_child_weight 
#' @param max_delta_step 
#' @param subsample 
#' @param colsample_bytree 
#' @param lambda 
#' @param alpha 
#' @param nrounds 
#' @param nthread 
#' @param fit_default 
#' @param fit.default 
#' @param transformation_function 
#'
#' @export
XgboostModel <- function(target_variable, eta = 0.3,
                         gamma = 0, max_depth = 6, 
                         min_child_weight = 1, 
                         max_delta_step = 0,
                         subsample = 1,
                         colsample_bytree = 1,
                         lambda = 1, alpha = 0,
                         nrounds = 500,
                         nthread = 1,
                         seed = 0,
                         fit_default = list(),
                         fit.default = NULL,
                         transformation_function = NULL) {
  
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable       <- target_variable
  
  # algorithm parameters
  this$eta              <- eta
  this$gamma            <- gamma
  this$max_depth        <- max_depth
  this$min_child_weight <- min_child_weight
  this$max_delta_step   <- max_delta_step
  this$subsample        <- subsample
  this$colsample_bytree <- colsample_bytree
  this$lambda           <- lambda
  this$alpha            <- alpha
  this$nthread          <- nthread
  this$seed             <- seed
  this$nrounds          <- nrounds
  
  if (!is.null(formula)) {
    this$formula <- formula
  } else {
    this$formula <- paste0(target_variable, " ~ .")
  }
  
  class(this) <- append(class(this), "XgboostModel")
  return(this)
}


#' Estimation of a XgboostModel
#'
#' @rdname fit
#' @export
fit.XgboostModel <- function(mid_term_model, data_train,
                             bypass_transform = FALSE,
                             leading_period = NULL,
                             weights = NULL, by = NULL) {
  
  mask_train <- which(weights == 1)
  
  # check data_train is numeric
  var_types <- sapply(data_train, class)
  
  if (!all(var_types == "numeric")) {
    message("all features will be transformed in numeric")
    
    data_train <- data_train %>% 
      dplyr::mutate_if(is.factor, as.numeric)
  }
  
  # get the target index
  target_ind <- which(names(data_train) == mid_term_model$target_variable)
  
  # fit with all columns other than target variable
  mid_term_model$model_ <- xgboost::xgboost(
    data  = as.matrix(
      data_train[mask_train, - target_ind]),
    label = data_train[mask_train, ][[mid_term_model$target_variable]],
    max_depth        = mid_term_model$max_depth,
    eta              = mid_term_model$eta,
    gamma            = mid_term_model$gamma,
    min_child_weight = mid_term_model$min_child_weight,
    max_delta_step   = mid_term_model$max_delta_step,
    subsample        = mid_term_model$subsample,
    colsample_bytree = mid_term_model$colsample_bytree,
    lambda           = mid_term_model$lambda,
    alpha            = mid_term_model$alpha,
    nrounds          = mid_term_model$nrounds,
    seed             = mid_term_model$seed,
    nthread          = mid_term_model$nthread,
    verbose = 0)
  
  # then record the explanatory_variables
  # for later prediction use
  # necessary to record to garantie the
  # right order of variables in matrix
  mid_term_model$explanatory_variables <-
    names(data_train)[-target_ind]
  
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @export
predict.XgboostModel <- function(model, data_prediction,
                                 bypass_transform = FALSE,
                                 leading_period = NULL) {
  prediction <- predict(
    model$model_, as.matrix(data_prediction[, model$explanatory_variables]))
  
  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }
  
  return(as.numeric(prediction))
}
