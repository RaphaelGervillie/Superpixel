generate_offsets_enedis <- function(data) {
  col_date <- 'date'
  # Check dates
  date_control <- R39Toolbox::check_dates(data)
  # check initial timezone and set working timezone accordingly
  initial_timezone <- date_control$tz
  if (initial_timezone == "CET24") {
    data[[col_date]] <- as.POSIXct(as.character(data[[col_date]]), tz = 'UTC')
    working_timezone <- 'UTC'
  } else {
    working_timezone <- date_control$tz
  }

  offset <- data.frame(rep(0, nrow(data)), rep(0, nrow(data)),
                       rep(0, nrow(data)), rep(0, nrow(data)))
  colnames(offset) <- as.character(5:9)
  dates_year <- as.numeric(
    strftime(data$date, format = "%Y", tz = working_timezone))
  unique_years <- unique(dates_year)
  # Summer break
  for (year in unique_years) {
    mask_year <- which(dates_year == year)

    large_date_range_year <- R39Toolbox::generate_calendar(
      paste0(year, "-06-01 00:00:00"),  paste0(year, "-09-30 00:00:00"),
      tz = working_timezone, ts = date_control$ts, variables = c('date'))$date
    if (length(mondays_break) > 0) {
      # add school start date as the final bound (if not a Monday)
      summer_break_dates <- c(
        date_summer_break_start, date_summer_break2,
        date_summer_break3, date_summer_break4,
        date_summer_break_end)
      # get distinct weeks
      for (i in 1:(length(summer_break_dates) - 1)) {
        mask_week <- (
          large_date_range_year >= summer_break_dates[[i]]
          & large_date_range_year < summer_break_dates[[i + 1]])
        mask_for_offset <- which(
          as.character(data$date)
          %in% as.character(large_date_range_year[mask_week]))
        if (length(mask_for_offset) > 0) {
          offset[[as.character(4 + i)]][mask_for_offset] <- 1
        }
      }
    }

    # determine which Monday the summer break is starting:
    #  - August 1st if it corresponds to a Monday
    #  - The Monday before August 1st if August 1st corresponds to a
    #    Tuesday, Wednesday or Thursday
    #  - The Monday after August 1st if August 1st corresponds to a
    #    Friday, Saturday or Sunday
    large_date_range_year <- R39Toolbox::generate_calendar(
       paste0(year, "-06-01 00:00:00"),  paste0(year, "-09-30 00:00:00"),
       tz = working_timezone, ts = date_control$ts, variables = c('date'))$date
    august_1st <- as.POSIXct(
      paste0(year, "-08-01 00:00:00"), tz = working_timezone)
    daytype    <- as.POSIXlt(august_1st)$wday
    if (daytype == 1) {
      mask_year_august <- (
        large_date_range_year >= august_1st
        & large_date_range_year < school_start)
    } else if (daytype %in% 2:4) {
      mask_year_august <- (
        large_date_range_year >= (august_1st - (daytype - 1) * 24 * 60 * 60)
        & large_date_range_year < school_start)
    } else if (daytype %in% 5:6) {
      mask_year_august <- (
        large_date_range_year >= (august_1st + (8 - daytype) * 24 * 60 * 60)
        & large_date_range_year < school_start)
    } else {
      mask_year_august <- (
        large_date_range_year >= (august_1st + 24 * 60 * 60)
        & large_date_range_year < school_start)
    }
    offset[["10"]][which(
      as.character(data$date)
      %in% as.character(large_date_range_year[mask_year_august]))] <- 1
    # Split August break into weeks
    unique_dates_break    <-  as.POSIXlt(
      unique(strftime(large_date_range_year[mask_year_august], format = "%F")))
    unique_daytypes_break <- unique_dates_break$wday
    mondays_break <- as.POSIXct(
      unique_dates_break[unique_daytypes_break == 1], tz = working_timezone)
    if (length(mondays_break) > 0) {
      # add school start date as the final bound (if not a Monday)
      mondays_break <- c(mondays_break, as.POSIXct(school_start))
      # get distinct weeks
      for (i in 1:(length(mondays_break) - 1)) {
        mask_week <- (
          large_date_range_year >= summer_break_dates[[i]]
          & large_date_range_year < summer_break_dates[[i + 1]])
        mask_for_offset <- which(
          as.character(data$date)
          %in% as.character(large_date_range_year[mask_week]))
        if (length(mask_for_offset) > 0) {
          offset[[as.character(10 + i)]][mask_for_offset] <- 1
        }
      }
    }
  }

  # Winter break

}
