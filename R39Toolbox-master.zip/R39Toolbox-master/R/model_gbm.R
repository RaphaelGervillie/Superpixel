#' @title GeneralizedBoostedModel
#'
#' @param target_variable the variable to predict
#' @param min_node_size n.minobsinnode in gbm model
#' @param shrinkage shrinkage in gbm model
#' @param interaction_depth interaction.depth in gbm model
#' @param n_trees n.trees in gbm model
#' @param fit_seed the seed used in fit (to make sure of reproductibility)
#' @param formula a formula (optional)
#' @param fit_default R39Toolbox model parameter
#' @param transformation_function R39Toolbox model parameter
#' @param min_node_size 
#' @param n_trees 
#'
#' @export
GeneralizedBoostedModel <- function(target_variable,
                                    min_node_size,
                                    shrinkage, interaction_depth,
                                    n_trees = 500,
                                    fit_seed = 1,
                                    formula = NULL,
                                    fit_default = NULL,
                                    transformation_function = NULL) {
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable <- target_variable
  
  # algorithm parameters
  this$interaction_depth <- interaction_depth
  this$shrinkage         <- shrinkage
  this$min_node_size     <- min_node_size
  this$n_trees           <- n_trees
  this$fit_seed          <- fit_seed
  if (!is.null(formula)) {
    this$formula <- formula
  } else {
    this$formula <- paste0(target_variable, " ~ .")
  }
  
  class(this) <- append(class(this), "GeneralizedBoostedModel")
  return(this)
}


#' Estimation of a GeneralizedBoostedModel
#'
#' @rdname fit
#' @export
fit.GeneralizedBoostedModel <- function(mid_term_model, data_train,
                                       bypass_transform = FALSE,
                                       leading_period = NULL,
                                       weights = NULL, by = NULL) {
  mask_train <- which(weights == 1)
  
  # fit by formula
  library(gbm)
  set.seed(mid_term_model$fit_seed)
  mid_term_model$model_ <- gbm(as.formula(mid_term_model$formula),
                               data = data_train[mask_train, ],
                               n.minobsinnode = mid_term_model$min_node_size,
                               shrinkage = mid_term_model$shrinkage,
                               interaction.depth = mid_term_model$interaction_depth,
                               n.trees = mid_term_model$n_trees)
  
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @export
predict.GeneralizedBoostedModel <- function(model, data_prediction,
                                           bypass_transform = FALSE,
                                           leading_period = NULL) {
  library(gbm)
  prediction <- predict(model$model_, data_prediction,
                        n.trees = model$n_trees)
  
  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }
  
  return(prediction)
}
