## R39Toolbox
## @copyright EDF R&D 2015
## 2015-09-10
## Raphaël Nedellec



#' R39ExData
#'
#' A dataset containing a load curve and several explicative variables
#'
#' @format A data frame with 35064 rows and 7 variables:
#' \describe{
#'   \item{date}{date, POSIXct}
#'   \item{conso}{load curve, numeric}
#'   \item{TypeJour7}{Day type, factor with 7 levels}
#'   \item{Temperature}{Temperature, numeric}
#'   \item{Instant}{Instant of the day, numeric}
#'   \item{Posan}{Time of year, 0 = first instant of the year, 1 = last}
#'   \item{Tendance}{Time variable}
#' }
#' @examples
#' head(R39ExData)
"R39ExData"

#' EdfColors
#'
#' Official EDF's colors
#'
#' A named vector of colors
#'
#' @format A named vector of 6 colors
#' \describe{
#'   \item{orange1}{#FE5815}
#'   \item{orange2}{#FFA02F}
#'   \item{vert1}{#C4D600}
#'   \item{vert2}{#509E2F}
#'   \item{bleu1}{#005BBB}
#'   \item{bleu2}{#001A70}
#' }
#' @source \url{https://brandcenter.edf.com/notre-marque/les-essentiels/les-couleurs/notre-univers-209996.html}
#' @examples
#' matplot(matrix(rnorm(60), ncol = 6), type = 'l', lty = 1, lwd = 3, col = EdfColors, xlim = c(-2,10),
#'   bty = 'n', xaxt = 'n', yaxt = 'n', ylab = "")
#' legend("left",legend = names(EdfColors), lty = 1, lwd = 3, col = EdfColors, horiz = FALSE, cex = 0.9, bty = 'n')
"EdfColors"

#' SpecialTarifs
#'
#' EJP and Tempo days from 2008-01-01 to 2015-07-31
#'
#' @format Special tarifs days
#' \describe{
#'   \item{EJPNord}{EJP days for 'Nord' zone}
#'   \item{EJPPACA}{EJP days for the 'PACA' zone}
#'   \item{EJPOuest}{EJP days for the 'Ouest' zone}
#'   \item{EJPSud}{EJP days for the 'Sud' zone}
#'   \item{TempoBlanc}{Tempo 'blanc' days}
#'   \item{TempoRouge}{Tempo 'rouge' days}
#' }
"SpecialTarifs"

#' StandardTemperature
#'
#' Half-hourly standard temperature over a reference leap year (2004), CET.
#' French standard temperature (mean of 32 wheather stations).
#'
#' @format A data frame with 2 columns:
#' \describe{
#'   \item{date}{To identify year, month, day and instant. Half-hourly dataset}
#'   \item{Temperature}{Standard temperature (the same for every year)}
#' }
#' @source ?
#'
"StandardTemperature"
