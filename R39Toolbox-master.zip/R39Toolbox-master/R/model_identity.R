
#' @export
RawVariable <- function(target_variable, fit_default = list(),
                        transformation_function = NULL) {
  this <- ForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  this$target_variable <- target_variable

  this$model_ <- "fit->ok"

  class(this) <- append(class(this), "RawVariable")
  return(this)
}


#' @export
fit.RawVariable <- function(model, data_train, bypass_transform = FALSE, ...) {
  return(model)
}

#' @method predict RawVariable
#' @export
predict.RawVariable <- function(model, data_prediction, bypass_transform = FALSE,
                                leading_period = NULL) {
  if (!model$target_variable %in% names(data_prediction)) {
    stop(paste0(model$target_variable, " not provided in data_prediction."))
  }

  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  return(data_prediction[[model$target_variable]][leading_period == 0])
}

