## R39Toolbox
## @copyright EDF R&D 2015
## 2015-09-10
## Benoit Thieurmel


#' Extract effects dataset from gam object
#'
#' @rdname get_model_effects
#' @export
get_model_effects <- function (model, ...) {
  UseMethod("get_model_effects")
}

#' @rdname get_model_effects
#' @method get_model_effects gam
#' @export
get_model_effects.gam <- function(model, ordering = FALSE, type = "terms",
                                  se.fit = FALSE) {
  suppressWarnings(suppressMessages(require(mgcv)))

  if (type %in% c("link", "response")) {
    stop("Please use predict function for type 'link' or 'response'")
  }

  res <- R39Toolbox:::get_effects_info(model, se.fit=se.fit,
                                                type=type)
  if (ordering) {
    R39Toolbox:::order_effects(res, se.fit=se.fit, type=type)
  } else {
    res$data.effets
  }
}

#' Multiply an effect by a coefficient
#'
#' @rdname scale_effects
#' @export
scale_effects <- function (model, ...) {
  UseMethod("scale_effects")
}

#' @rdname scale_effects
#' @method scale_effects gam
#' @export
scale_effects.gam <- function(model, data_lpmatrix) {
  coefficients <- model$coefficients
  names(coefficients) <- paste0("effect.fit.", names(coefficients))

  if (is.list(data_lpmatrix) & !is.data.frame(data_lpmatrix)) {
    ctrl <- lapply(1:length(data_lpmatrix), function(x) {
      tmp <- data_lpmatrix[[x]]
      ind.coef <- colnames(tmp)[colnames(tmp) %in% names(coefficients)]
      data_lpmatrix[[x]][, ind.coef] <<- sweep(data_lpmatrix[[x]][, ind.coef, drop=FALSE],
                                               2, coefficients[ind.coef], FUN="*")
    })
  } else {
    ind.coef <- colnames(data_lpmatrix)[colnames(data_lpmatrix) %in% names(coefficients)]
    data_lpmatrix[, ind.coef] <- sweep(data_lpmatrix[, ind.coef], 2,
                                       coefficients[ind.coef], FUN="*")
  }
  data_lpmatrix
}

#' @noRd
order_effects <- function(data, se.fit = FALSE, type = "terms") {
  effets <- data$type.effets
  data.effets <- data$data.effets
  info.terms <- data$info.terms

  effets <- effets[!effets$label %in% "(Intercept)", ]
  if (nrow(effets) > 0) {
    result <- lapply(1:nrow(effets), function(x) {
      if (type == "lpmatrix") {
        se.fit = FALSE
        transform.name <- colnames(data.effets)
        if (effets[x, "type"] != "factor.linear") {
          transform.name <- gsub("[.][[:digit:]]*$", "", transform.name)
          ind.data <- which(
            colnames(data.effets) %in%
              c(unlist(strsplit(effets[x, "terms"], ",")),
                colnames(data.effets)[transform.name %in%
                                        paste0("effect.fit.",
                                               effets[x, "label"])]))
        } else {
          ind.data <- which(
            colnames(data.effets) %in%
              c(unlist(strsplit(effets[x, "terms"], ",")),
                colnames(data.effets)[grep(paste0("effect.fit.",
                                                  effets[x, "label"]),
                                           colnames(data.effets))]))
        }
      } else {
        if (!se.fit) {
          ind.data <- which(colnames(data.effets) %in%
                            c(unlist(strsplit(effets[x, "terms"], ",")),
                              paste0("effect.fit.", effets[x, "label"])))
        } else {
          ind.data <- which(colnames(data.effets) %in%
                            c(unlist(strsplit(effets[x, "terms"], ",")),
                              paste0("effect.fit.", effets[x, "label"]),
                              paste0("effect.se.fit.", effets[x, "label"])))
        }
      }
      if (!is.na(effets[x, "by"]) && !is.na(effets[x, "by.level"])) {
        ind.keep <- which(
          data.effets[, effets[x, "by"]] == effets[x, "by.level"])
        don <- unique(data.effets[ind.keep, ind.data])
      } else {
        don <- unique(data.effets[, ind.data])
      }
      column_for_order <- colnames(don)[1:length(
        unlist(strsplit(effets[x, "terms"], ",")))]
      don[order(don[, column_for_order]), ]
    })
    names(result) <- effets$label
  } else {
    result <- NULL
  }
  result
}

#' Extract effects from gam model
#'
#' Extract effects from gam model.
#'
#' @param model : a mgcv gam model
#'
#' @param se.fit : when this is TRUE (not default) standard error
#'   estimates are returned for each prediction.
#'
#' @noRd
get_effects_info <- function(model, type = "terms", se.fit = FALSE) {
  suppressWarnings(suppressMessages(require(mgcv)))

  # jeu de donnees des effets
  tmp <- predict.gam(model, type=type, se.fit=se.fit)

  # response et link a gerer
  if (!is.list(tmp)) {
    if (ncol(tmp) == 1 & !se.fit) {
      colnames(tmp) <- paste("effect.fit", colnames(tmp), sep=".")
    }
    data.effets <-  data.frame(model$model, effect.fit=tmp, check.names=FALSE)
  } else if (type != "lpmatrix") {
    tmpname <- unlist(lapply(names(tmp), function(x) {
      paste(x, colnames(tmp[[x]]), sep=".")
    }))
    tmp <- data.frame(tmp)
    colnames(tmp) <- tmpname

    data.effets <-  data.frame(model$model, effect=tmp, check.names=FALSE)
  }
  info <- get_effect_types(model)

  res <- list(data.effets=data.effets, type.effets=info$type.effets,
              info.terms=info$info.terms)
  return(res)
}

#' @export
get_effect_types <- function(model) {
  suppressWarnings(suppressMessages(require(mgcv)  ))

  # informations sur les types de variables
  #name.terms <- attr(model$terms, "term.labels")
  #class.terms <- attr(model$terms, "dataClasses")[name.terms]
  #info.terms <- data.frame(name=name.terms, class=class.terms)
  # <proposition virgile>
  name.terms <- attr(model$terms, "term.labels")
  class.terms <- attr(model$terms, "dataClasses")[name.terms]
  # petit hack
  names(class.terms) <- name.terms
  class.terms[which(is.na(class.terms))] <- "factor"
  info.terms <- data.frame(name=name.terms, class=class.terms)
  #</proposition virgile>

  # info sur les effets (spline + lineaire)
  info.effects <- do.call("rbind", lapply(model$smooth, function(x) {
    data.frame(nb.terms=length(x$term), terms=paste(x$term, collapse=","),
               by=gsub("^NA$", NA, x$by),
               by.level=ifelse("by.level" %in% names(x), x$by.level, NA),
               label=x$label, type=attr(x, "class")[1], stringsAsFactors=FALSE)
  }))

  if (!is.null(info.effects)) {
    info.effects$ind.gam.smooth <- 1:nrow(info.effects)

    # on fait un smooth.spline ?
    info.effects$smooth.spline <- TRUE
    ind.no.smooth <- which((!info.effects$type %in%
                            c("cr.smooth", "cs.smooth", "cyclic.smooth",
                              "duchon.spline", "tprs.smooth", "ts.smooth",
                              "pspline.smooth", "cpspline.smooth",
                              "random.effect"))
                           | (!is.na(info.effects$by)
                              & !info.terms[info.effects$by, "class"]
                              %in% c("factor","character"))
                           | (info.effects$nb.terms > 1))
    info.effects$smooth.spline[ind.no.smooth] <- FALSE

    info.effects <- info.effects[, -c(1)]
  }

  #lineaire
  all.names.effects <- gsub("^([[:space:]])*|([[:space:]]*)$", "",
                            unlist(strsplit(as.character(formula(model))[3], "[+]")))
  all.names.effects <- all.names.effects[!all.names.effects %in% c("1", "", "-1")]
  # corriger les eventuels "-1" en trop.
  all.names.effects <- unlist(lapply(all.names.effects, function(x) {gsub("([[:space:]]*)-([[:space:]]*)1$", "", x)}))
  linear.names.effects <- all.names.effects[!grepl("^s[(]|^te[(]|^ti[(]|^t2[(]", all.names.effects)]

  if (length(linear.names.effects) > 0) {
    name.terms <- linear.names.effects
    class.terms2 <- class.terms[linear.names.effects]
    linear.effects <- data.frame(terms=linear.names.effects, by=NA,
                                 by.level=NA, label=linear.names.effects,
                                 type=paste(class.terms2, "linear", sep="."),
                                 ind.gam.smooth=NA, smooth.spline=FALSE,
                                 stringsAsFactors=FALSE)
    info.effects <- rbind(linear.effects, info.effects)
  }

  if ("(Intercept)"%in%names(model$coefficients)) {
    intercept.effects <- data.frame(terms="(Intercept)", by=NA, by.level=NA,
                                    label="(Intercept)",
                                    type=paste("numeric", "linear", sep="."),
                                    ind.gam.smooth=NA, smooth.spline=FALSE,
                                    stringsAsFactors=FALSE)
    info.effects <- rbind(intercept.effects, info.effects)
  }

  return(list(type.effets=info.effects, info.terms=info.terms))
}


#' Extract factor coefficient
#'
#' Extract factor coefficient.
#'
#' @param model : a mgcv gam model
#'
#' @param effet : effect information
#'
#' @noRd
get_factor_coefficients <- function(model, effet) {
  coefficients <- model$coefficients
  terms <- effet[, "terms"]

  # a cause des as.factor()...
  terms.grep <- gsub("[(]", "[(]", terms)
  terms.grep <- gsub("[)]", "[)]", terms.grep)

  ind.coef <- grep(paste0("^", terms.grep), names(coefficients))
  coef <- coefficients[ind.coef]
  attributs <- gsub(paste0("^", terms.grep), "", names(coef))

  all.levels <- model$xlevels[[terms]]
  data.coef <- data.frame(coefficients=rep(0, length(all.levels)))
  rownames(data.coef) <- all.levels
  data.coef[attributs, "coefficients"] <- coef
  return(data.coef)
}


#' Extract linear numeric coefficient
#'
#' Extract linear numeric coefficient.
#'
#' @param model : a mgcv gam model
#'
#' @param effet : effect information
#'
#' @noRd
extractNumericCoefficients <- function(model, effet) {
  coefficients <- model$coefficients
  terms <- effet[, "terms"]

  ind.coef <- which(names(coefficients) %in% terms)
  data.coef <- coefficients[ind.coef]
  return(data.coef)
}


#' Compute smooth.spline
#'
#' Compute smooth.spline.
#'
#' @param effet : effect information
#'
#' @param data.effets :  Output from \link{get_effects_info}
#'
#' @param control.knots : knots control. Optionnel.
#'\itemize{
#' \item{"nknots"}{ : if we want to fix number of knots}
#' \item{"mape.max"}{ : Maximum MAPE. if nknots = NA}
#' \item{"reduce.knots"}{ : Reduce knots ?. if nknots = NA}
#' \item{"max.knots"}{ : Maximum number of knots. if nknots = NA}
#'}
#'
#'@noRd
compute_smooth_spline <- function(effet, data.effets,
                                control.knots = list(nknots=300, max.knots=300,
                                  mape.max=0.0001, reduce.knots=TRUE)) {

  terms <- effet[, "terms"]
  by <- effet[, "by"]
  by.level <- effet[, "by.level"]
  label <- paste0("effect.fit.", effet[, "label"])

  nknots <- ifelse("nknots" %in% names(control.knots),
                   control.knots$nknots, 300)
  max.knots <- ifelse("max.knots" %in% names(control.knots),
                      control.knots$max.knots, 300)
  mape.max <- ifelse("mape.max" %in% names(control.knots),
                     control.knots$mape.max, 0.0001)
  reduce.knots <- ifelse("reduce.knots" %in% names(control.knots),
                         control.knots$reduce.knots, TRUE)

  x <- data.effets[, grep(paste0("^", terms, "$"), colnames(data.effets))]
  y <- data.effets[, label]

  if (!is.na(by)) {
    ind.mod.keep <- which(data.effets[, grep(paste0("^", by, "$"), colnames(data.effets))] == by.level)
    x <- x[ind.mod.keep]
    y <- y[ind.mod.keep]
  }

  ind.dup <- which(duplicated(x))
  if (any(ind.dup)) {
    x <- x[-ind.dup]
    y <- y[-ind.dup]
  }

  if (is.na(nknots)) {
    init.smooth <- smooth.spline(x, y, keep.data=FALSE)
    ctrl.mape <- mean(abs((predict(init.smooth, x)$y - y) / y)) * 100

    nx <- length(unique(x))
    # si mauvais MAPE, on augmente progressivement le nombre de noeuds
    # si on ne trouve pas ctrl.mape < mape.max, on prend le noeuds qui minimisent
    if (ctrl.mape > mape.max) {
      seq.knots <- trunc(seq(init.smooth$fit$nk, min(nx, max.knots),
                             length.out=11)[-1])
      i <- 1
      min.knots  <- init.smooth$fit$nk
      min.ctrl.mape <- ctrl.mape
      while (ctrl.mape > mape.max & i <= 10) {
        current.smooth <- smooth.spline(x, y, keep.data=FALSE,
                                        nknots=seq.knots[i])
        ctrl.mape <- mean(abs((predict(current.smooth, x)$y - y) / y)) * 100
        if (ctrl.mape < min.ctrl.mape) {
          min.knots <- seq.knots[i]
          min.ctrl.mape <- ctrl.mape
        }
        i <- i + 1
      }
      data.coef <- smooth.spline(x, y, keep.data=FALSE,
                                 nknots=min.knots)$fit
    } else if (ctrl.mape < mape.max & reduce.knots) { # si bon MAPE, on reduit...
      seq.knots <- trunc(seq(init.smooth$fit$nk, 5, length.out=11)[-1])
      i <- 1
      while (ctrl.mape < mape.max & i <= 10) {
        current.smooth <- try(smooth.spline(x, y, keep.data=FALSE,
                                            nknots=seq.knots[i]), silent=TRUE)
        if (class(current.smooth) == "try-error") {
          ctrl.mape <- control.knots$mape.max
          i <- i + 1
        } else {
          ctrl.mape <- mean(abs((predict(current.smooth, x)$y - y) / y)) * 100
          i <- i + 1
        }
      }

      i <- ifelse(i > 3, i - 2, 1)
      data.coef <- smooth.spline(x, y, keep.data=FALSE,
                                 nknots=seq.knots[i])$fit
    } else {
      data.coef <- init.smooth$fit
    }
  } else {
    smooth.spline(x, y, keep.data=FALSE,
                  nknots=min(length(unique(round(x, 8))), nknots))$fit
  }
}


#' Extract gam effect information
#'
#' Extract gam effect information.
#'
#' @param model : a mgcv gam model
#'
#' @param effet : effect information
#'
#' @noRd
get_smooth_infos <- function(model, effet) {
  smooth <- model$smooth[[effet[, "ind.gam.smooth"]]]
  coefficients <- model$coefficients
  label <- effet[, "label"]

  if (attr(smooth, "class")[1] %in% c("tensor.smooth", "t2.smooth")) {
    ctrl <- lapply(1:length(smooth$margin), function(x) {
      smooth$margin[[x]]$X <<- NULL
    })
  }

  label <- gsub("[(]", "[(]", label)
  label <- gsub("[)]", "[)]", label)
  label <- gsub("[:]", "[:]", label)
  coefficients <- coefficients[grep(paste0("^", label), names(coefficients))]
  list(smooth=smooth, coefficients=coefficients)
}


#' Predict factor effect
#'
#' Predict factor effect.
#'
#' @param coefficients : Output from \link{get_factor_coefficients}
#'
#' @param data : data
#'
#' @return predictions of the effect
#'
#' @noRd
predict_factor_coefficients <- function(coefficients, data) {
  coefficients[as.character(data), "coefficients"]
}


#' Predict numeric linear effect
#'
#' Predict numeric linear effect.
#'
#' @param coefficients : Output from \link{extractNumericCoefficients}
#'
#' @param data : data
#'
#' @return predictions of the effect
#'
#' @noRd
predict_numeric_coefficients <- function(coefficient, data) {
  data * coefficient
}


#' Predict smooth.spline effect
#'
#' Predict smooth.spline effect.
#'
#' @param model : Output from \link{compute_smooth_spline}
#'
#' @param data : data
#'
#' @return predictions of the effect
#'
#' @noRd
predict_smooth_spline <- function(model, data, info) {
  if (is.na(info$by)) {
    predict(model, data)$y
  } else {
    fitted <- predict(model, data[, -ncol(data)])$y
    fitted[data[, info$by] != info$by.level] <- 0
    fitted
  }
}


#' Predict gam effect
#'
#' Predict gam effect.
#'
#' @param model : Output from \link{get_smooth_infos}
#'
#' @param data : data
#'
#' @return predictions of the effect
#'
#' @noRd
predict_gam_effect <- function(model, data) {
  (mgcv:::PredictMat(model$smooth, data) %*% model$coefficients)[, 1]
}



