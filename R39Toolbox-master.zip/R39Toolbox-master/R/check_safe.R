#' @export
check_dates <- function(data) {
  # check `data` has a 'date' column (required in R39Toolbox)
  stopifnot("date" %in% colnames(data))

  # check dates are in POSIXct format
  if ("Date" %in% class(data$date)) {
    data$date <- as.POSIXct(as.character(data$date))
  }
  if (!any(c("CET24", "POSIXct") %in% class(data$date))) {
    stop("Date must be in POSIXct format, Date format, or CET24.")
  }

  # get timezone associated to date column
  tz <- attr(data$date, 'tzone')
  if (is.null(tz)) {
    if (any(class(data$date) %in% c('CET24'))) {
      tz <- 'CET24'
    } else {
      stop("Unknown timezone for input data")
    }
  }

  # get timestep for the input dataset
  # XXX: in a first, temporary version, we check that the timestep is
  # uniform accross the first timestamps of the dataset. If it is the case,
  # then we consider that we have found the initial timestep. Otherwise,
  # we suggest that the user resample his data before going further.
  # TODO: There might still be an issue if the dataset starts close to a
  # daylight saving switch instant because the timestep will be thought to be
  # non-uniform although it actually is.
  # TODO: There is another problem when the time precision leads to different
  # timestep only for a matter of a second or less. (see issue #11)
  if (nrow(data) < 10) {
    ts <- "unknown"
  } else {
    timestep_bunch <- sapply(
      2:min(10, dim(data)[[1]]),
      function(x) {
        difftime(data$date[[x]], data$date[[x - 1]], units = "sec")
      })
    unique_timesteps_in_bunch <- unique(timestep_bunch)
    if (length(unique_timesteps_in_bunch) <= 2) {  # 2 in case of winter switch
      if (length(timestep_bunch) > 2) {
        ts <- unique_timesteps_in_bunch[[
          which.max(sapply(unique_timesteps_in_bunch,
                           function(x) {
                             length(which(timestep_bunch == x))
                           }))]]
      } else {
        ts <- unique_timesteps_in_bunch[[1]]
      }
    } else {  # non-uniform timestep
      if (min(unique_timesteps_in_bunch) < 0) {  # because of daylight saving
        representative_timestep <- 0
        n_representative_timestep   <- 0
        for (i in unique_timesteps_in_bunch) {
          count_timestep <- length(which(timestep_bunch == i))
          if (count_timestep > n_representative_timestep) {
            n_representative_timestep <- count_timestep
            representative_timestep   <- i
          }
        }
        ts <- representative_timestep
      } else {
        ts <- "non-uniform"
      }
    }
  }

  list(tz = tz, ts = ts)
}

#' @export
format_character_date <- function(character_date, verbose = TRUE) {
  if ("character" %in% class(character_date)) {
    character_date_split <- unlist(strsplit(character_date, ' '))
    if (length(character_date_split) == 1) {
      if (verbose) {
        warning(paste0("No hour found in 'character_date' specification. ",
                       "00:00 will be assumed"))
      }
      character_date <- paste0(character_date, " 00:00")
    }
  }

  character_date
}

#' @export
format_character_date <- function(character_date, verbose = TRUE) {
  if ("character" %in% class(character_date)) {
    character_date_split <- unlist(strsplit(character_date, ' '))
    if (length(character_date_split) == 1) {
      if (verbose) {
        warning(paste0("No hour found in 'character_date' specification. ",
                       "00:00 will be assumed"))
      }
      character_date <- paste0(character_date, " 00:00")
    }
  }

  character_date
}


#' Check input data validity
#'
#' @param data Data to be checked
#' @param expected_variables Variables that are expected in the dataset
#' @param allow_na Are NA values allowed?
#'
#' @export
check_data <- function(data, expected_variables, allow_na = TRUE) {
  # Sequentially check the required columns
  out <- lapply(
    expected_variables,
    function(x) {
      # check the the column does exist
      if (!x %in% colnames(data)) {
        stop(paste0("The '", x, "' column is required in the dataset."))
      }
      # check for NA values (is needed)
      if (!allow_na && any(is.na(data[[x]]))) {
        stop(paste0("The '", x, "' column should not have NA values."))
      }
    })
}
