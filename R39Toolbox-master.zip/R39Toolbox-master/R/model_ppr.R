#' @title ProjectionPursuitModel
#' @param target_variable the variable to predict
#' @param nterms nterms in ppr model
#' @param max_terms max.terms in ppr model
#' @param sm_method smooth method in ppr model
#' @param formula a formula (optional)
#' @param fit_default R39Toolbox model parameter
#' @param fit.default R39Toolbox model parameter (deprecated)
#' @param transformation_function R39Toolbox model parameter
#'
#' @export
ProjectionPursuitModel <- function(target_variable,
                                  nterms, max_terms,
                                  sm_method = 'spline',
                                  formula = NULL,
                                  fit_default = NULL,
                                  transformation_function = NULL) {
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)

  # object parameters
  this$target_variable <- target_variable

  # algorithm parameters
  this$max_terms <- max_terms
  this$nterms    <- nterms
  this$sm_method <- sm_method
  if (!is.null(formula)) {
    this$formula <- formula
  }

  class(this) <- append(class(this), "ProjectionPursuitModel")
  return(this)
}


#' Estimation of a ProjectionPursuitModel
#'
#' @importFrom stats model.matrix
#' @rdname fit
#' @export
fit.ProjectionPursuitModel <- function(mid_term_model, data_train,
                                      bypass_transform = FALSE,
                                      leading_period = NULL,
                                      weights = NULL, by = NULL) {
  mask_train <- which(weights == 1)

  # TODO: check data_train columns are ok
  if (!is.null(mid_term_model$formula)) {
    # fit by formula
    mid_term_model$model_ <- ppr(as.formula(mid_term_model$formula),
      data = data_train[mask_train, ],
      nterms = mid_term_model$nterms,
      max.terms = mid_term_model$max_terms,
      sm.method = mid_term_model$sm_method)

  } else {
    # check data_train is numeric
    var_types <- sapply(data_train, class)
    if (!all(var_types == "numeric")) {
      stop("If no forumula is provided, the data_train need to be numeric")
    }

    # get the target index
    ind_target <- which(names(data_train) ==
        mid_term_model$target_variable)

    # fit with all columns other than target variable
    mid_term_model$model_ <- ppr(x = as.matrix(
      data_train[mask_train, - ind_target]),
      y = as.matrix(data_train[mask_train,
        ind_target]),
      nterms = mid_term_model$nterms,
      max.terms = mid_term_model$max_terms,
      sm.method = mid_term_model$sm_method)

    # then record the explanatory_variables
    # for later prediction use
    # necessary to record to garantie the
    # right order of variables in matrix
    mid_term_model$explanatory_variables <-
      names(data_train)[-ind_target]
  }
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @importFrom stats model.matrix
#' @rdname predict
#' @method predict ProjectionPursuitModel
#' @export
predict.ProjectionPursuitModel <- function(model, data_prediction,
                                          bypass_transform = FALSE,
                                          leading_period = NULL) {

  if (is.null(model$formula)) {
    prediction <- predict(
      model$model_, data_prediction[, model$explanatory_variables])
  } else {
    prediction <- predict(model$model_, data_prediction)
  }

  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }

  return(prediction)
}
