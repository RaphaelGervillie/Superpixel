#' LightGBM implementation 
#' 
#' @param target_variable 
#'
#' @param max_depth 
#' @param max_delta_step 
#' @param nrounds 
#' @param nthread 
#' @param fit_default 
#' @param fit.default 
#' @param transformation_function 
#' @param learning_rate 
#' @param num_leaves 
#' @param min_data_in_leaf 
#' @param lambda_l1 
#' @param lambda_l2 
#' @param bagging_fraction 
#' @param feature_fraction 
#' @param early_stopping_rounds 
#' @param seed 
#' @param max_bin 
#'
#' @export
LightGBMModel <- function(target_variable, max_depth = -1, 
                          learning_rate = .1,
                          num_leaves = 31,
                          min_data_in_leaf = 20,
                          max_delta_step = 0,
                          lambda_l1 = 0, 
                          lambda_l2 = 0,
                          bagging_fraction = 1,
                          feature_fraction = 1,
                          early_stopping_rounds = 0,
                          seed = 1,
                          nrounds = 100,
                          nthread = 1L,
                          max_bin = 255,
                          fit_default = list(),
                          fit.default = NULL,
                          transformation_function = NULL) {
  
  this <- MidTermForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  
  # object parameters
  this$target_variable       <- target_variable
  
  # algorithm parameters
  this$max_depth             <- max_depth
  this$max_bin               <- max_bin
  this$learning_rate         <- learning_rate
  this$num_leaves            <- num_leaves
  this$min_data_in_leaf      <- min_data_in_leaf
  this$max_delta_step        <- max_delta_step
  this$lambda_l1             <- lambda_l1
  this$lambda_l2             <- lambda_l2
  this$nrounds               <- nrounds
  this$nthread               <- nthread
  this$bagging_fraction      <- bagging_fraction
  this$feature_fraction      <- feature_fraction
  this$early_stopping_rounds <- early_stopping_rounds
  this$seed                  <- seed
  
  if (!is.null(formula)) {
    this$formula <- formula
  } else {
    this$formula <- paste0(target_variable, " ~ .")
  }
  
  this$save_path <- NULL
  
  class(this) <- append(class(this), "LightGBMModel")
  return(this)
}


#' Estimation of a LightGBMModel
#'
#' @rdname fit
#' @export
fit.LightGBMModel <- function(mid_term_model, data_train,
                              data_valid = NULL,
                              save_path = NULL, model_name = "lgb",
                              bypass_transform = FALSE,
                              leading_period = NULL,
                              weights = NULL, by = NULL) {
  
  mask_train <- which(weights == 1)
  
  library(lightgbm)
  # check data_train factors are integers
  var_types <- sapply(data_train, class)
  if (any(var_types == "factor")) {
    data_train <- data_train %>% 
      dplyr::mutate_if(is.factor, as.integer)
  }
  
  # get the target index
  target_ind <- which(names(data_train) == mid_term_model$target_variable)
  
  # transform data_train into a lgb.Dataset object
  dtrain <- lgb.Dataset(as.matrix(data_train[, - target_ind]), 
                        label = data_train[[mid_term_model$target_variable]])
  params <- list(objective = "regression", metric = "l2")
  
  # get categorical features names
  # we assume all integer type features are factor-transformed
  mid_term_model$categorical_variables <- 
    names(which(do.call(c, purrr::map(data_train, class)) == "integer"))
  
  # check data_valid is present
  mid_term_model$model_ <- if (!is.null(data_valid)) {
    
    # get the target index
    val_ind <- which(names(data_valid) == mid_term_model$target_variable)
    
    # transform data_train into a lgb.Dataset object
    dval <- lgb.Dataset(as.matrix(data_valid[, - val_ind]), 
                        label = data_valid[[mid_term_model$target_variable]])
    
    # fit with all columns other than target variable
    lightgbm::lgb.train(
      params = params, data = dtrain, valids = list(test = dval),
      max_depth             = mid_term_model$max_depth,
      max_bin               = mid_term_model$max_bin,
      learning_rate         = mid_term_model$learning_rate,
      num_leaves            = mid_term_model$num_leaves,
      min_data_in_leaf      = mid_term_model$min_data_in_leaf,
      max_delta_step        = mid_term_model$max_delta_step,
      lambda_l1             = mid_term_model$lambda_l1,
      lambda_l2             = mid_term_model$lambda_l2,
      nrounds               = mid_term_model$nrounds,
      num_threads           = mid_term_model$nthread,
      bagging_fraction      = mid_term_model$bagging_fraction,
      feature_fraction      = mid_term_model$feature_fraction,
      early_stopping_rounds = mid_term_model$early_stopping_rounds,
      categorical_feature   = mid_term_model$categorical_var,
      seed                  = mid_term_model$seed,
      verbose = - 1)
    
  } else {
    
    # fit without validation set, and early stopping
    lightgbm::lgb.train(
      params = params, data = dtrain,
      max_depth             = mid_term_model$max_depth,
      max_bin               = mid_term_model$max_bin,
      learning_rate         = mid_term_model$learning_rate,
      num_leaves            = mid_term_model$num_leaves,
      min_data_in_leaf      = mid_term_model$min_data_in_leaf,
      max_delta_step        = mid_term_model$max_delta_step,
      lambda_l1             = mid_term_model$lambda_l1,
      lambda_l2             = mid_term_model$lambda_l2,
      nrounds               = mid_term_model$nrounds,
      num_threads           = mid_term_model$nthread,
      bagging_fraction      = mid_term_model$bagging_fraction,
      feature_fraction      = mid_term_model$feature_fraction,
      categorical_feature   = mid_term_model$categorical_var,
      seed                  = mid_term_model$seed,
      verbose = 0)
    
  }
  
  # then record the explanatory_variables
  # for later prediction use
  # necessary to record to garantie the
  # right order of variables in matrix
  mid_term_model$explanatory_variables <-
    names(data_train)[- target_ind]
  
  if (!is.null(save_path)) {
    time_stamp <- stringr::str_replace_all(
      as.character(Sys.time()),
      " ", "_")
    time_stamp <- stringr::str_replace_all(
      time_stamp,
      ":", "_")
    mid_term_model$save_path <- paste0(save_path, "/", 
                                       model_name, "_", 
                                       time_stamp, ".rds")
    saveRDS.lgb.Booster(mid_term_model$model_, 
                        mid_term_model$save_path)
  }
  
  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' @rdname predict
#' @export
predict.LightGBMModel <- function(model, data_prediction,
                                  bypass_transform = FALSE,
                                  leading_period = NULL) {
  if (!is.null(model$save_path)) {
    message("prediction from saved lgb model")
    model$model_ <- readRDS.lgb.Booster(model$save_path)
  }
  
  prediction <- predict(
    model$model_, as.matrix(data_prediction[, model$explanatory_variables]))
  
  if (!is.null(leading_period)) {
    prediction <- prediction[leading_period == 0]
  }
  
  return(as.numeric(prediction))
}
