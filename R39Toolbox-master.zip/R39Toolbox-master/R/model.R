# Implementation of various models for mid-term load forecasting.
#
# All models are inherited from the same basic class : ForecastModel, and
# also from the MidTermForecastModel or ShortTermForeastModel class

### Initialisation of a model ----------------------------

#' Generic class for a forecast model (whatever it forecasts)
#'
#' In our design, the user fixes the names of the variables he will
#' work with at the model creation. This is true for every model, so
#' any model can be applied on a given, same dataset.
#' A ForecastModel can actually correspond to several models,
#' each fit on a different level of a qualitative variable: use
#' "by = <variable.name>" in the 'fit' function. The models do have
#' the same parameters (e.g. formula). To overcome this issue, one can
#' use the AggregationModel class.
#'
#' @param fit_default A set of arguments that can alterate the
#'   behavior of the object's 'fit' method
#' @param transformation_function An R function that is called before
#'   any other data processing. It is used to attach a specific
#'   data transformation to a model.
#'
#' @return ForecastModel instance
#'
#' @export
ForecastModel <- function(fit_default = list(),
                          transformation_function = NULL) {
  this <- list()
  # model not fit "per factor" by default
  if (is.null(fit_default$by) && is.null(this$fit_default$by)) {
    fit_default$by <- FALSE
  }
  # no history is saved by default
  if (is.null(fit_default$hist) && is.null(this$fit_default$hist)) {
    fit_default$hist <- FALSE
  }
  this$fit_default <- fit_default
  this$transformation_function <- transformation_function
  this$history <- list()
  class(this) <- "ForecastModel"

  return(this)
}


#' Mid-term forecast models
#'
#' @export
MidTermForecastModel <- function(fit_default = list(),
                                 transformation_function = NULL) {
  this <- ForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  this$fit_default <- append(this$fit_default, fit_default)
  #caveat: ajout de fit_default 2 fois ? (une fois dans le
  #constructeur de ForecastModel et une fois ici ?)
  class(this) <- append(class(this), "MidTermForecastModel")

  return(this)
}


#' Short-term forecast models
#'
#' A short-term forecast model is different from a mid-term model
#' because it relies on a signal to readjust its predictions
#' (typically, we have an underlying model that perform a first
#' prediction on which a supplementary algorithm is run to achieve the
#' short-term prediction).
#'
#' @param target_variable Column name for the target variable.
#'     (useful at prediction time)
#'
#' @export
ShortTermForecastModel <- function(target_variable, fit_default = list(),
                                   predict_default = list(),
                                   transformation_function = NULL) {
  this <- ForecastModel(
    fit_default = fit_default,
    transformation_function = transformation_function)
  this$predict_default <- append(this$predict_default, predict_default)
  this$target_variable <- target_variable
  class(this) <- append(class(this), "ShortTermForecastModel")

  return(this)
}


#' Split a dataset according to a factor
#'
#' This function is generally used by 'by' models.
#'
#' @param data The dataset to be split
#' @param by Name of the splitting variable
#' @param expected_n_levels Is not NULL, a supplementary check is
#'   performed about the number of modalities the 'by' variable
#'   actually has.
#'
#' @return A list of indices that correspond to the splits
split_data_by_factor <- function(data, by, expected_n_levels = NULL) {
  # check data_train has a 'by' column
  if (!by %in% names(data)) {
    stop(paste0(by, " column not found in data."))
  }
  # check the 'by' column is a factor
  # (we chose not to perform an implicit conversion)
  if (!"factor" %in% class(data[[by]])) {
    stop(paste0(by , " column must be a factor."))
  }

  if (!is.null(expected_n_levels)) {
    # check number of modalities
    n_by_levels <- length(unique(data[[by]]))
    if (n_by_levels > expected_n_levels) {
      stop(paste0("Data have more ",
                  by, " variable levels than the ",
                  "data the model has been trained with."))
    } else if (n_by_levels < expected_n_levels) {
      warning(paste0("Data have less ",
                     by, " variable levels than the ",
                     "data the model has been trained with."))
    }
  }

  split(1:nrow(data), data[[by]], drop = TRUE)
}


### Estimation of a model ----------------------------

check_leading_period <- function(leading_period, data) {
  if (is.null(leading_period)) {
    leading_period <- rep(0, nrow(data))
  }
  if ("character" %in% class(leading_period)) {
    if (!leading_period %in% colnames(data)) {
      stop(paste0("No column '", leading_period, "' found to be used ",
                  "as leading_period."))
    } else {
      leading_period <- data[[leading_period]]
    }
  }

  leading_period
}

#' Function to estimate/learn/train a forecast model
#'
#' Weights can be provided because some models require a smoothing
#' period *before* the period actually used for the estimation. Weights
#' can also be used to ignore an observation when estimating a model.
#'
#' @param model : MidTermForecastModel to be fit
#' @param data_train : Training data + an optional leading period
#'   (defined with the 'weights' argument)
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already
#'   transformed)
#' @param weights : Vector with elements in {0, 1} of length equal to
#'   the number of observation in `data_train`. Weights can be
#'   provided because some models require a smoothing period before
#'   the period actually used for the estimation. Weights can also be
#'   used to ignore an observation when estimating a model.
#'
#' @return The 'model', when fit on 'data_train'
#'
#' @export
fit <- function(model, data_train, bypass_transform = FALSE, ...) {
  UseMethod("fit", model)
}
#' @export
fit.ForecastModel <- function(model, data_train, bypass_transform = FALSE,
                              leading_period = NULL, weights = NULL,
                              ...) {
  if (nrow(data_train) == 0) {
    warning("Empty data: no model will be fit")
    return(model)
  }
  
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_train <- model$transformation_function(data_train)
  }
  if ("character" %in% class(weights)) {
    if (!weights %in% colnames(data_train)) {
      stop(paste0("No column '", weights, "' found to be used ",
                  "as weights."))
    } else {
      weights <- data_train[[weights]]
    }
  }
  if (is.null(weights)) {
    weights <- rep(1, nrow(data_train))
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_train)
  NextMethod("fit", model,
             bypass_transform = bypass_transform,
             weights = weights, leading_period = leading_period)
}


#' Estimation of a MidTermForecastModel
#'
#' One can fit a model per level of a given quantitative variable
#' using the 'by' argument. Yet, the parameters of the models will
#' be the same (e.g. formula).
#'
#' Every parameter that has an influence on the underlying algorithm, but
#' that is not related to the structure of the model can be tuned in the call
#' to this function. The default value must yet be set to NULL so that we
#' can test whether or not the user has set its value in the call. If it is
#' the case, we use the user-defined value, otherwise we use the default value
#' that is defined in the 'fit_default' attribute of the model object
#' (at its instanciation time).
#' This complex design has been introduced so that a simple call to 'fit'
#' can be done for several models of various kind, while controling for the
#' exact parameters of the fit (e.g. calling fit by instant for all models,
#' but not for an Eventail model, with the exact same call yet).
#'
#' @param model : MidTermForecastModel instance, the
#'   parameters of which should be estimated from the input data
#' @param data_train : Training data from which the parameters of the
#'   model will be learnt.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already
#'   transformed)
#' @param weights : Vector of elements in {0, 1} to be applied to the
#'   observations before fitting.
#' @param by : A categorical variable that must be a factor.  One
#'   model will be fit for each level of the factor.
#'
#' @return : The model, when fit. Estimated parameters and information
#'           about the estimation procedure are stored as attributes of
#'           the object, with an underscore ("_") at the end of their name.
#'
#' @rdname fit
#' @export
fit.MidTermForecastModel <- function(model, data_train,
                                     bypass_transform = FALSE,
                                     leading_period = NULL, weights = NULL,
                                     by = NULL, ...) {
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {
    by <- model$fit_default[["by"]]  # NULL if not defined
  }

  if (!is.null(by) && (by != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(data_train, by)

    # remove by column
    ind_by <- which(colnames(data_train) == by)
    data_train <- data_train[, - ind_by]

    model$model_ <- lapply(
      names(ind_split),
      function(x) {
        R39Toolbox::fit(model, data_train[ind_split[[x]], ],
                        bypass_transform = TRUE,
                        by = FALSE,  # very important to avoid infinite loop
                        leading_period = leading_period[ind_split[[x]]],
                        weights = weights[ind_split[[x]]])
      })

    model$by_     <- by
    model$levels_ <- names(ind_split)

    return(model)
  } else {
    data_train     <- data_train[leading_period == 0, ]
    weights        <- weights[leading_period == 0]
    leading_period <- leading_period[leading_period == 0]
    NextMethod("fit", model,
               bypass_transform = bypass_transform,
               weights = weights, leading_period = leading_period,
               by = by)
  }
}


### Prediction with a model ----------------------------

#' Function to perform a prediction from observations
#'
#' A leading period can be defined because some models require one
#' before the period the user actually wants to predict on.
#'
#' @param model : ForecastModel that will be used for the simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already
#'   transformed)
#' @param leading_period : Vector that indicates which is the period of
#'   interest for the user that runs a prediction. This is mainly
#'   useful for models that require past observations for
#'   initialisation (e.g. autoregressive-models, or models that
#'   perform smoothing at runtime). "0"s correspond the leading
#'   period, and "1"s to the target period. Default is NULL, which is
#'   equivalent to only "1"s.
#'
#' @return the prediction as a numeric argument
#'
#' @method predict ForecastModel
#' @export
predict.ForecastModel <- function(model, data_prediction,
                                  bypass_transform = FALSE,
                                  leading_period = NULL, ...) {
  NextMethod("predict", model,
             bypass_transform = bypass_transform,
             leading_period = leading_period)
}

#' Prediction of the target variable from observations with
#' a MidTermForecastModel
#'
#' @param model : MidTermForecastModel that will be used for the
#'   simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param forecast_model : MidTermForecastModel that will be used for
#'   the simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already transformed)
#'
#' @return the prediction as a numeric argument
#'
#' @rdname predict
#' @method predict MidTermForecastModel
#' @export
predict.MidTermForecastModel <- function(model, data_prediction,
                                         bypass_transform = FALSE,
                                         leading_period = NULL,
                                         ...) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # Check the model has been fit
  if (("MidTermForecastModel" %in% class(model))
      & (is.null(model[["model_"]]))) {
    stop("Please fit the model before it can perform a prediction.")
  }

  # Recursive call if the model is a 'by' model
  if (!is.null(model$by_) && (model$by_ != FALSE)) {
    # split dataset according to 'by'
    ind_split <- R39Toolbox:::split_data_by_factor(
      data_prediction, model$by_, expected_n_levels = length(model[["model_"]]))

    # remove by column
    ind_by <- which(colnames(data_prediction) == model$by_)
    data_prediction <- data_prediction[, - ind_by]

    # perform several predictions
    prediction <- rep(NA, nrow(data_prediction))

    check <- lapply(
      names(ind_split),
      function(x) {
        level_pos <- which(model$levels_ == x)[[1]]
        if (is.null(level_pos)) {
          stop("Could not find level ", level, " in the levels the ",
               "model has been trained with.")
        }
        if (length(which(leading_period[ind_split[[x]]] == 0)) > 0) {
          prediction[ind_split[[x]]][leading_period[ind_split[[x]]] == 0] <<- predict(
            model[["model_"]][[level_pos]], data_prediction[ind_split[[x]], ],
            bypass_transform = TRUE,
            leading_period = leading_period[ind_split[[x]]])
        }
      })
    return(as.numeric(prediction[leading_period == 0]))
  } else {
    NextMethod("predict", model,
               bypass_transform = bypass_transform,
               leading_period = leading_period)
  }
}


#' @method predict ShortTermForecastModel
#' @export 
predict.ShortTermForecastModel <- function(model, data_prediction,
                                           bypass_transform = FALSE,
                                           leading_period = NULL,
                                           ...) {
  NextMethod("predict", model,
             bypass_transform = bypass_transform,
             leading_period = leading_period)
}

#' @export
predict_details <- function(model, data_prediction, bypass_transform = FALSE,
                            leading_period = NULL, ...) {
  UseMethod("predict_details", model)
}

#' Prediction of the target variable from observations with
#' a MidTermForecastModel
#'
#' @param model : MidTermForecastModel that will be used for the
#'   simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param forecast_model : MidTermForecastModel that will be used for
#'   the simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already transformed)
#'
#' @return the prediction as a numeric argument
#'
#' @rdname predict_details
#' @export
predict_details.MidTermForecastModel <- function(model, data_prediction,
                                                 bypass_transform = FALSE,
                                                 leading_period = NULL, ...) {
  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  if (("MidTermForecastModel" %in% class(model))
      & (is.null(model[["model_"]]))) {
    stop("Please fit the model before it can perform a prediction.")
  }
  if (!is.null(model$by_) && (model$by_ != FALSE)) {
    # split dataset according to 'by'
    ind_split <- split_data_by_factor(
      data_prediction, model$by_, expected_n_levels = length(model[["model_"]]))
    # get and set output size
    level     <- names(ind_split)[[1]]
    level_pos <- which(model$levels_ == level)[[1]]
    prediction_tmp <- predict_details(
      model[["model_"]][[1]], bypass_transform = TRUE,
      data_prediction[ind_split[[1]], , drop = FALSE])
    prediction <- as.data.frame(matrix(
      nrow = nrow(data_prediction), ncol = ncol(prediction_tmp)))
    colnames(prediction) <- colnames(prediction_tmp)
    check <- lapply(
      names(ind_split),
      function(x) {
        level_pos <- which(model$levels_ == x)[[1]]
        # check levels consistency between predict and train datasets
        if (is.null(level_pos)) {
          stop("Could not find level ", level, " in the levels the ",
               "model has been trained with.")
        }
        prediction_tmp <- predict_details(
          model[["model_"]][[level_pos]],
          bypass_transform = TRUE,
          data_prediction[ind_split[[x]], ])
        prediction[ind_split[[x]], colnames(prediction_tmp)] <<- prediction_tmp
      })
    return(as.data.frame(prediction))
  } else {
    NextMethod("predict_details", model,
               bypass_transform = bypass_transform,
               leading_period = leading_period)
  }
}


### Simulation with a model ----------------------------

#' Function to perform a prediction from observations
#'
#' A target period can be defined because some models require a
#' leading period before the period actually the user actually wants
#' to predict on.
#'
#' @param model : ForecastModel that will be used for the simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already
#'   transformed)
#' @param leading_period : Vector that indicates which is the period of
#'   interest for the user that runs a prediction. This is mainly
#'   useful for models that require past observations for
#'   initialisation (e.g. autoregressive-models, or models that
#'   perform smoothing at runtime). "0"s correspond the leading
#'   period, and "1"s to the actual prediction period. Default is NULL, which is
#'   equivalent to only "1"s.
#'
#' @return the prediction as a numeric argument
#'
#' @export
simulate <- function(model, data_simulation, bypass_transform = FALSE,
                     leading_period = NULL, update_frequency = NULL,
                     ...) {
  UseMethod("simulate", model)
}
#' @export
simulate.ForecastModel <- function(model, data_simulation,
                                   bypass_transform = FALSE,
                                   leading_period = NULL,
                                   ...) {
  NextMethod("simulate", model,
             bypass_transform = bypass_transform,
             leading_period = leading_period)
}

#' @export
simulate.default <- function(model, data_simulation,
                             bypass_transform = FALSE,
                             leading_period = NULL,
                             ...) {
  predict(model, data_simulation,
          bypass_transform = bypass_transform,
          leading_period = leading_period)
}

#' Prediction of the target variable from observations with
#' a MidTermForecastMOdel
#'
#' @param model : MidTermForecastModel that will be used for the
#'   simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param forecast_model : MidTermForecastModel that will be used for
#'   the simulation
#' @param data_prediction : Dataset containing at least the
#'   explanatory variables of the model, so it can be used to perform
#'   a prediction from this variables.
#' @param bypass_transform : Whether or not to skip the transformation
#'   function (should be equal to TRUE if the data are already transformed)
#'
#' @return the prediction as a numeric argument
#'
#' @rdname predict
#' @export
simulate.MidTermForecastModel <- function(model, data_simulation,
                                          bypass_transform = FALSE,
                                          leading_period = NULL,
                                          ...) {
  predict(model, data_simulation,
          bypass_transform = bypass_transform,
          leading_period = leading_period)
}


check_frequency <- function(frequency, data, leading_period) {
  # by default, frequency is 1
  if (is.null(frequency)) {
    frequency <- 1
  }

  if ('list' %in% class(frequency)
      || any(c('Date', 'character', 'POSIXct') %in% class(frequency))) {
    if ("Date" %in% class(frequency[[1]])) {
      if (!all("Date" == sapply(frequency, class))) {
        stop("Not all the elements of 'frequency' have the same class.")
      }
      frequency <- lapply(
        frequency, as.POSIXct, format = "%Y-%m-%d")
    } else if ("character" %in% class(frequency[[1]])) {
      if (!all("character" == sapply(frequency, class))) {
        stop("Not all the elements of 'frequency' have the same class.")
      }
      #TODO: gerer davantage de cas pour le format des chaines de caracteres
      frequency <- sapply(
        frequency, as.POSIXct, format = "%Y-%m-%d %H:%M")
    } else if (!"POSIXct" %in% class(frequency[[1]])) {
      stop("Format incorrect pour 'frequency'.")
    }
    ind <- intersect(
      which(data$date %in% frequency),
      which(leading_period == 0))
  } else {
    ind <- intersect(
      seq(which(leading_period == 0)[[1]], nrow(data), frequency),
      which(leading_period == 0))
  }

  ind
}

#' @export
simulate.ShortTermForecastModel <- function(model, data_simulation,
                                            bypass_transform = FALSE,
                                            leading_period = NULL,
                                            update_frequency = NULL,
                                            launch_frequency = NULL,
                                            delay = 1, horizon = 0,
                                            verbose = FALSE,
                                            output_model = FALSE,
                                            save_history = FALSE,
                                            use_history = FALSE,
                                            ...) {

  update_model <- function(model, from, to, data_simulation,
                           delay, bypass_transform, save_history = FALSE,
                           verbose = FALSE) {
    fit_block_start <- from - delay
    fit_block_end   <- to - delay
    if ((fit_block_end > 0) && (fit_block_start <= fit_block_end)) {
      mask_fit <- 1:fit_block_end
      leading_period_tmp  <- rep(0, fit_block_end)
      if (fit_block_start > 0) {
        leading_period_tmp[1:fit_block_start] <- 1
      }
      weights <- rep(1, fit_block_end)
      if (verbose) {
        message(
          paste0(
            "Fitting model from ",
            head(data_simulation$date[mask_fit][leading_period_tmp == 0], 1),
            " to ",
            data_simulation$date[fit_block_end], "."))
      }
      if (save_history) {
        hist <- data_simulation$date[[fit_block_end]]
      } else {
        hist <- NULL
      }
      model <- R39Toolbox::fit(
        model, data_simulation[mask_fit, , drop = FALSE],
        leading_period = leading_period_tmp, weights = weights,
        bypass_transform = bypass_transform, hist = hist)
    }

    model
  }

  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_simulation)

  launch_ind <- R39Toolbox:::check_frequency(
    launch_frequency, data_simulation, leading_period)
  if (!is.null(update_frequency) && update_frequency == 0) {
    update_ind <- 0
  } else {
    update_ind <- R39Toolbox:::check_frequency(
      update_frequency, data_simulation, leading_period)
  }

  simulation <- rep(NA, nrow(data_simulation))
  start_simulation <- which(leading_period == 0)[[1]]
  s1 <- unique(c(start_simulation, launch_ind, nrow(data_simulation) + 1))
  s1_map <- Map(c, s1[-length(s1)], s1[-1])
  last_update_pos <- 1  # keep track of the last model update date
  for (i in s1_map) {
    # Update the model if the launch date corresponds to an update date
    # (exception though: do not perform an update on the first launch date)
    if ((i[[1]] %in% update_ind) && (i[[1]] != s1[[1]])) {
      model <- update_model(
        model, last_update_pos, i[[1]], data_simulation,
        delay, bypass_transform, save_history = save_history,
        verbose = verbose)
      last_update_pos <- i[[1]]
    }

    # Prediction
    # use all the data available before the current time
    predict_block_end <- min(i[[2]] - 1 + horizon, nrow(data_simulation))
    mask_prediction <- 1:predict_block_end
    # leading period corresponds to the period on which we have observations
    leading_period_tmp   <- rep(0, predict_block_end)
    if ((i[[1]] - delay) >= 1) {
      leading_period_tmp[1:(i[[1]] - delay)] <- 1
    }
    # target perdiod corresponds to the moments we want to forecast
    target_period   <- rep(0, predict_block_end)
    if ((i[[1]] + horizon) <= predict_block_end) {
      target_period[(i[[1]] + horizon):predict_block_end] <- 1
    }
    # split data
    data_simulation_tmp <- data_simulation[mask_prediction, , drop = FALSE]
    # perform prediction
    if (length(which(leading_period_tmp == 0)) > 0) {
      data_simulation_tmp[[model$target_variable]][
        leading_period_tmp == 0] <- NA
    }
    if (length(which(target_period == 1)) > 0) {
      if (verbose) {
        message(
          paste0(
            "Prediction on ",
            head(data_simulation_tmp[, c('date')][leading_period_tmp == 0], 1)))
      }
      if (use_history) {
        predict_as_date <- head(
          data_simulation_tmp[, c('date')][leading_period_tmp == 0], 1)
      } else {
        predict_as_date <- NULL
      }
      simulation[(i[[1]] + horizon):predict_block_end] <- predict(
        model, data_simulation_tmp, leading_period = leading_period_tmp,
        bypass_transform = bypass_transform,
        predict_as_date = predict_as_date)[
          target_period[leading_period_tmp == 0] == 1]
    }
    #XXX: mettre bypass_transform a FALSE?

    # Estimation
    # if and only if an update date falls inside the prediction block
    update_candidate <- which((update_ind > i[[1]]) & (update_ind < i[[2]]))
    if (length(update_candidate) > 0) {
      model <- update_model(
        model, last_update_pos, tail(update_candidate, 1),
        data_simulation, delay, bypass_transform,
        save_history = save_history, verbose = verbose)
      last_update_pos <- tail(update_candidate, 1)
    }
  }

  res <- simulation[leading_period == 0]
  if (output_model) {
    list(simulation = res, model = model,
         update_dates = data_simulation$date[update_ind])
  } else {
    res
  }
}


### Score associated with a model ----------------------------

#' Score associated to a prediction on given data
#'
#' The prediction is actually made inside this function because the
#' purpose is to test the performance of a model, not the quality
#' of a prediction independently from the model that generated it.
#' The metric for the computation of the score can be chosen by
#' the user via the 'type' argument.
#'
#' @param mid_term_model MidTermForecastModel with which the prediction
#'   should be made
#' @param data_prediction Data from which the prediction should be
#'   made
#' @param truth True value of the target variable
#' @param leading_period Can be used to distinguish an initialisation
#'   period for the model (leading period) from the actual target
#'   period for the prediction.
#' @param type Function used to compute the score. It must take as
#'   argument the true values and the predicted values. Weights can
#'   optionnaly be provided, as well as an argument to control the way
#'   NAs are dealt with.
#' @param weights Weights associated to the observations
#' @param na.rm How to handle NAs.
#' @param by Shall the score values be computed using a specific column in the
#'    data
#'
#' @return the score associated with the prediction performed from the provided
#'         model and data.
#'
#' @examples
#' data       <- R39Toolbox::R39ExData
#' model      <- R39Toolbox::GeneralizedAdditiveModel(
#'                 "conso ~ s(Temperature) + s(Posan)")
#' model      <- R39Toolbox::fit(model, data)
#' prediction <- R39Toolbox::predict(model, data)
#' # RMSE
#' rmse.model <- R39Toolbox::score(model, data, data$conso)
#' # MAPE
#' mape.model <- R39Toolbox::score(model, data, data$conso,
#'                                 type = R39Toolbox::mape)
#'
#' @export
score <- function(forecast_model, data_prediction, truth,
                  type = R39Toolbox::rmse, leading_period = NULL,
                  weights = NULL, na.rm = TRUE, by = NULL) {
  prediction <- predict(forecast_model, data_prediction,
                        leading_period = leading_period)
  #created after the prediction in order to use lexical scoping
  #only prediction and truth will be modified
  score_it <- function(prediction, truth) {
    if (is.null(leading_period)
        || (length(prediction) == length(leading_period))) {
      prediction_score <- type(
        truth, prediction, weights = weights, na.rm = na.rm)
    } else {
      prediction_score <- type(
        truth[leading_period == 0], prediction,
        weights = weights[leading_period == 0], na.rm = na.rm)
    }
    return(prediction_score)
  }

  if (is.null(by)) {
    prediction_score <- score_it(prediction, truth)
  } else {
    if (!by %in% names(data_prediction)) {
      stop(paste0(by, " column not found in 'data_prediction'."))
    }
    if (!"factor" %in% class(data_prediction[[by]])) {
      stop(paste0(by , " column must be a factor."))
    }
    splitted_truth <- split(truth, data_prediction[[by]])
    splitted_prediction <- split(prediction, data_prediction[[by]])
    res <- sapply(1:length(splitted_truth), function(i) {
      score_it(splitted_prediction[[i]], splitted_truth[[i]])
    })
    # return a dataframe
    prediction_score <- as.data.frame(levels(data_prediction[[by]]))
    names(prediction_score) <- "levels"
    prediction_score$score  <- res

  }
  return(prediction_score)
}


### Miscellaneous functions

#' Estimate the neutral temperature of a prediction model
#'
#' The neutral temperature of the model is defined as the temperature
#' serie that minimizes the total amount of consumption over a given period.
#'
#' The current algorithm approximates it as the offset that must be
#' applied to the (daily averaged) shape of the standard temperature
#' to reach a minimal amount of total consumption over the period
#' covered by the training data.
#'
#' The neutral temperature is defined empirically and can therefore
#' vary according to the data it is computed from.
#'
#' @param forecast_model Model for which to compute the neutral temperature
#' @param data_train Training data to estimate the neutral temperature
#' @param col_temperature Name of the temperature variable in the data
#' @param t_min Lower bound for the neutral temperature
#' @param t_max Upper bound for the neutral temperature
#' @param t_step Precision of the estimation
#'
#' @return estimated neutral temperature of the model. The computed
#'   value is stored in the input model as its new estimated neutral
#'   temperature.
#'
#' @export
compute_neutral_temperature <- function(forecast_model, data_train,
                                        leading_period = NULL,
                                        col_temperature = 'Temperature',
                                        t_min = 14, t_max = 20,
                                        t_step = 0.1) {
  daily_std_temp_shape <- (
    R39Toolbox:::compute_daily_standard_temperature_shape(data_train))
  temperature_range <- seq(t_min, t_max, t_step)
  candidates <- sapply(temperature_range,
         function(t) {
           data_temp <- data_train
           data_temp[[col_temperature]] <- daily_std_temp_shape + t
           sum(predict(
             forecast_model, data_temp, leading_period = leading_period),
             na.rm = TRUE)
         })

  temperature_range[which.min(candidates)]
}


#' Set the neutral temperature of a model
#'
#' This function is only an accessor to set the attribute of a
#' ForecastModel object.
#'
#' @param forecast_model Model for which to set the neutral temperature
#' @param neutral_temperature Neutral temperature of the model
#'
#' @export
set_neutral_temperature <- function(forecast_model, neutral_temperature) {
  forecast_model$neutral_temperature_ <- neutral_temperature
  forecast_model
}


#' Compute the climatic part of a prediction
#'
#' This function requires that the ForecastModel object has been
#' given a neutral temperature (see `compute_neutral_temperature` function).
#' The temperature column of the input dataset is replaced with the neutral
#' temperature and a new prediction is made. This prediction is the
#' weather independent part. It is subtracted from the standard prediction
#' to obtain the climatic part.
#'
#' @param forecast_model ForecastModel that is used for the prediction
#' @param data_prediction Input dataset to perform the predictions
#' @param leading_period To be transfered to "predict" function
#' @param col_temperature Name of the temperature variable in the input dataset
#' @param details Whether or not to return the details of the
#'   computation (as a data frame with WeatherDependentLoad,
#'   WeatherIndependentLoad, HeatingLoad and CoolingLoad columns)
#' @return The climatic part of the prediction
#'
#' @export
compute_climatic_part <- function(forecast_model, data_prediction,
                                  leading_period = NULL,
                                  col_temperature = 'Temperature',
                                  details = FALSE) {
  # perform base prediction
  prediction <- predict(forecast_model, data_prediction,
                        leading_period = leading_period)

  if (is.null(forecast_model$neutral_temperature_)) {
    stop(paste0("The model has no neutral temperature. ",
                "Please use train data to estimate it before the ",
                "climatic part can be computed."))
  }
  # replace temperature variable by neutral temperature variable
  data_prediction_neutral <- data_prediction
  data_prediction_neutral[[col_temperature]] <- (
    R39Toolbox:::compute_daily_standard_temperature_shape(
      data_prediction) + forecast_model$neutral_temperature_)

  # perform prediction with neutral temperature
  prediction_neutral <- predict(
    forecast_model, data_prediction_neutral,
    leading_period = leading_period)

  if (!details) {
    parts <- prediction - prediction_neutral
  } else {
    # check leading_period argument
    leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)
    weather_dependent_part <- prediction - prediction_neutral
    # heating part is the weather dependent part for low temperatures
    heating_load <- weather_dependent_part
    temp <- data_prediction[[col_temperature]][leading_period == 0]
    heating_load[temp >= forecast_model$neutral_temperature_] <- 0
    # cooling part is the weather dependent part for high temperatures
    cooling_load <- weather_dependent_part
    cooling_load[temp < forecast_model$neutral_temperature_] <- 0
    # gather parts
    parts <- data.frame(
      WeatherDependentLoad = weather_dependent_part,
      WeatherIndependentLoad = prediction_neutral,
      HeatingLoad = heating_load,
      CoolingLoad = cooling_load)
  }

  parts
}
