### /!\ DEPRECATED FUNCTIONS /!\ ###

#' Deprecated function in the R39Toolbox package
#' Origin : calendar_generator.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
calendarGenerator <- function(date.begin, date.end, ts = 10 * 60, tz = "UTC",
                              choiceHolidays = "FR",
                              Variables = c("date", "Annee", "Mois", "Jour",
                                            "Heure", "Minute", "Instant",
                                            "Posan", "Tendance", "JourSemaine",
                                            "JourFerie", "Ponts", "isoSemaine",
                                            "isoAnnee"),
                              keep.last = TRUE, convention = NULL) {
  .Deprecated("generate_calendar", package = "R39Toolbox")
  ## # proposal for more generic names (unused yet):
  ## new_variables <- list(
  ##   date = "date",
  ##   Annee = "Year", Mois = "Month", Jour = "Day",
  ##   Heure = "Hour", Minute = "Minute", Instant = "Instant",
  ##   Posan = "Posan", Tendance = "Trend", JourSemaine = "WeekDay",
  ##   JourFerie = "DayOff", Ponts = "Bridge",
  ##   isoSemaine = "IsoWeekDay", isoAnnee = "IsoYear")
  generate_calendar(
    date_begin = date.begin, date_end = date.end, ts = ts, tz = tz,
    holidays = choiceHolidays, variables = Variables,
    keep_last = keep.last, convention = convention)
}


#' Deprecated function in the R39Toolbox package
#' Origin : check_safe.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
checkDateSequence <- function(data) {
  .Deprecated("check_dates", package = "R39Toolbox")
  check_dates(data)
}

#' Deprecated function in the R39Toolbox package
#' Origin : data_effects.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
dataEffects <- function (model, ...) {
  .Deprecated("get_model_effects", package = "R39Toolbox")
  get_model_effects(model, ...)
}

#' Deprecated function in the R39Toolbox package
#' Origin : data_effects.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
multiplyByCoefficients <- function (model, ...) {
  .Deprecated("scale_effects", package = "R39Toolbox")
  scale_effects(model, ...)
}

#' Deprecated function in the R39Toolbox package
#' Origin : data_effects.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
extractEffectsType <- function(model) {
  .Deprecated("get_effect_types", package = "R39Toolbox")
  get_effect_types(model, ...)
}


#' Deprecated function in the R39Toolbox package
#' Origin : DOAAR.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
setDateConvention <- function(data, convention) {
  .Deprecated("set_date_convention", package = "R39Toolbox")
  set_date_convention(data, convention)
}

#' Deprecated function in the R39Toolbox package
#' Origin : DOAAR.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
createDayType.DOAAT.CT <- function(data) {
  .Deprecated("generate_daytype_DOAAT_CT", package = "R39Toolbox")
  generate_daytype_DOAAT_CT(data)
}

#' Deprecated function in the R39Toolbox package
#' Origin : DOAAR.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
createOffset.DOAAT <- function(data) {
  .Deprecated("generate_offset_DOAAT", package = "R39Toolbox")
  generate_offset_DOAAT(data)
}

#' Deprecated function in the R39Toolbox package
#' Origin : DOAAR.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
createBreak.DOAAT <- function(data, horizon = "CT") {
  .Deprecated("generate_break_DOAAT", package = "R39Toolbox")
  generate_break_DOAAT(data, horizon = horizon)
}



# The following 10 functions are specific to ERDF's needs.
# Ideally, they should be moved to another package to would gather all
# ERDF-specific processings.


#' Create day type variable specific to ERDF needs
#' Origin : ERDF.R
#'
#' Distinction regular day ("Regular") / day off (name provided)
#'
#' @param data : data.frame, with at least one column 'date', in
#'   POSIXct with tz attribute, or CET24 character
#' @param holidays : Character string vector of days off we have
#'   to consider. See listHolidays(pattern =
#'   ".*) from package 'timeDate' for details
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
generate_daytype_ERDF <- function(data,
                                  holidays = c(
                                    timeDate::listHolidays(pattern = "*FR"),
                                    "NewYearsDay", "Easter", "EasterMonday",
                                    "LaborDay", "Pentecost", "PentecostMonday",
                                    "ChristmasDay")) {
  # Deprecation warning
  # Use "generate_daytypes(data, c(30, 10)) instead"
  # Pentecost and Easter are not considered as days off in the new version.
  .Deprecated("generate_daytypes", package = "R39Toolbox")

  date_control <- R39Toolbox::check_dates(data)
  if (date_control$tz == "CET24") {
    working_tz <- 'UTC'
  } else {
    working_tz <- date_control$tz
  }
  date_range <- as.POSIXlt(as.character(data$date), tz = working_tz)
  if ("Annee" %in% colnames(data)) {
    unique_years <- unique(data$Annee)
  } else {
    unique_years <- unique(date_range$year + 1900L)
  }

  daytype.ERDF <- rep("Regular", nrow(data))
  day.off <- sapply(holidays, do.call, list(year = unique_years))

  data.date <- as.Date(date_range)

  ctrl <- sapply(names(day.off), function(k) {
    ind_holidays <- which(data.date %in% as.Date(day.off[[k]]@Data))
    if (length(ind_holidays) > 0) {
      daytype.ERDF[ind_holidays] <<- k
    }
  })

  daytype.ERDF
}


#' Create day type variable specific to ERDF needs
#' Origin : ERDF.R
#'
#' Seven day type according to weekday, day-off and brigdes.
#' Tuesday, Wednesday and Thursday have the same type.
#'
#' @param data : data.frame, with at least one column 'date', in
#'   POSIXct with tz attribute, or CET24 character
#' @param holidays : Character string vector of days off we have
#'   to consider. See listHolidays(pattern =
#'   ".*) from package 'timeDate' for details
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
generate_daytype_ERDF_7 <- function(data,
                                    holidays = c(
                                      timeDate::listHolidays(pattern = "*FR"),
                                      "NewYearsDay", "Easter", "EasterMonday",
                                      "LaborDay", "Pentecost", "PentecostMonday",
                                      "ChristmasDay")) {
  # Deprecation warning
  # Use "generate_daytypes(data, c(1, 14, 5, 6, 0, 30, 33)) instead"
  # Pentecost and Easter are not considered as days off in the new version.
  .Deprecated("generate_daytypes", package = "R39Toolbox")

  date_control <- R39Toolbox::check_dates(data)
  if (date_control$tz == "CET24") {
    working_tz <- 'UTC'
  } else {
    working_tz <- date_control$tz
  }
  date_range <- as.POSIXlt(as.character(data$date), tz = working_tz)
  if ("Annee" %in% colnames(data)) {
    unique_years <- unique(data$Annee)
  } else {
    unique_years <- unique(date_range$year + 1900L)
  }

  if (!"ERDF_TypeJour" %in% colnames(data)) {
    data$ERDF_TypeJour <- R39Toolbox::generate_daytype_ERDF(data, holidays)
    # TODO: optimisation of the potential multiple calls to R39Toolbox::check_dates
  }

  #TODO: avoid code duplication betwwen calendar_generator and createDayType* functions
  if (!"JourSemaine" %in% colnames(data)) {
    data$JourSemaine <- date_range$wday
  }
  if (!"JourFerie" %in% colnames(data)) {
    data$JourFerie <- 0
    jf <- sapply(holidays, do.call, list(year = unique_years))

    sapply(names(jf), function(k) {
      ind_holidays <- which(as.Date(date_range, tz = working_tz)
                            %in% as.Date(jf[[k]]@Data))
      if (length(ind_holidays) > 0) {
        data$JourFerie[ind_holidays] <<- 1
      }
    })
  }

  if (!"Ponts" %in% colnames(data)) {
    date_range <- as.POSIXlt(as.character(data$date))
    data$Annee <- date_range$year + 1900L
    data$Mois  <- date_range$mon + 1L
    data$Jour  <- date_range$mday
    data$day <- as.Date(date_range, tz = working_tz)
    if (length(which(duplicated(data$day))) > 0) {
      data_tmp <- (
        data[-which(duplicated(data$day)),
             c("Annee", "Mois", "Jour", "JourSemaine", "JourFerie")])
    } else {
      data_tmp <- data[, c("Annee", "Mois", "Jour", "JourSemaine", "JourFerie")]
    }
    rownames(data_tmp) <- NULL

    mask_day_off  <- data_tmp[, "JourFerie"] == 1
    # thursday off => next friday is a bridging day
    mask_thursday <- data_tmp[, "JourSemaine"] == 4
    friday_bridge <- data_tmp[which(mask_day_off & mask_thursday) + 1, ]
    # tuesday off => previous monday is a bridging day
    mask_tuesday  <- data_tmp[, "JourSemaine"] == 2
    monday_bridge <- data_tmp[which(mask_day_off & mask_tuesday) - 1, ]

    bridging_days <- rbind(monday_bridge, friday_bridge)
    key_bridging_days <- paste(bridging_days$Annee, bridging_days$Mois,
                               bridging_days$Jour, sep = "-")
    key_dates <- paste(data$Annee, data$Mois, data$Jour, sep = "-")
    data$Ponts <- 0
    data$Ponts[key_dates %in% key_bridging_days] <- 1
  }

  daytype.ERDF7 <- ifelse(
    data$ERDF_TypeJour != "Regular", 7,
    ifelse(data$Ponts == 1, 8,
           ifelse(data$JourSemaine > 1 & data$JourSemaine < 5,
                  2, data$JourSemaine)))

  daytype.ERDF7
}


#' Create day type variable specific to ERDF needs
#' Origin : ERDF.R
#'
#' Nine day type according to weekday, day-off and brigdes.
#'
#' @param data : data.frame, with at least one column 'date', in
#'   POSIXct with tz attribute, or CET24 character
#' @param holidays : Character string vector of days off we have
#'   to consider. See listHolidays(pattern =
#'   ".*) from package 'timeDate' for details
#'
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
generate_daytype_ERDF_9 <- function(data,
                                    holidays = c(
                                      timeDate::listHolidays(pattern = "*FR"),
                                      "NewYearsDay", "Easter", "EasterMonday",
                                      "LaborDay", "Pentecost", "PentecostMonday",
                                      "ChristmasDay")) {
  # Deprecation warning
  # Use "generate_daytypes(data, c(1, 2, 3, 4, 5, 6, 0, 30, 33)) instead"
  .Deprecated("generate_daytypes", package = "R39Toolbox")

  date_control <- R39Toolbox::check_dates(data)
  if (date_control$tz == "CET24") {
    working_tz <- 'UTC'
  } else {
    working_tz <- date_control$tz
  }
  date_range <- as.POSIXlt(as.character(data$date), tz = working_tz)

  if (!"ERDF_TypeJour" %in% colnames(data)) {
    data$ERDF_TypeJour <- R39Toolbox::generate_daytype_ERDF(data, holidays)
    # TODO: optimisation of the potential multiple calls to R39Toolbox::check_dates
  }

  #TODO: avoid code duplication betwwen calendar_generator and createDayType* functions
  if (!"JourSemaine" %in% colnames(data)) {
    data$JourSemaine <- date_range$wday
  }
  if (!"JourFerie" %in% colnames(data)) {
    if ("Annee" %in% colnames(data)) {
      unique_years <- unique(data$Annee)
    } else {
      unique_years <- unique(date_range$year + 1900L)
    }
    data$JourFerie <- 0
    jf <- sapply(holidays, do.call, list(year = unique_years))

    sapply(names(jf), function(k) {
      ind_holidays <- which(as.Date(date_range, tz = working_tz)
                            %in% as.Date(jf[[k]]@Data))
      if (length(ind_holidays) > 0) {
        data$JourFerie[ind_holidays] <<- 1
      }
    })
  }

  if (!"Ponts" %in% colnames(data)) {
    date_range <- as.POSIXlt(as.character(data$date))
    data$Annee <- date_range$year + 1900L
    data$Mois  <- date_range$mon + 1L
    data$Jour  <- date_range$mday
    data$day <- as.Date(date_range, tz = working_tz)
    if (length(which(duplicated(data$day))) > 0) {
      data_tmp <- (
        data[-which(duplicated(data$day)),
             c("Annee", "Mois", "Jour", "JourSemaine", "JourFerie")])
    } else {
      data_tmp <- data[, c("Annee", "Mois", "Jour", "JourSemaine", "JourFerie")]
    }
    rownames(data_tmp) <- NULL

    mask_day_off  <- data_tmp[, "JourFerie"] == 1
    # thursday off => next friday is a bridging day
    mask_thursday <- data_tmp[, "JourSemaine"] == 4
    friday_bridge <- data_tmp[which(mask_day_off & mask_thursday) + 1, ]
    # tuesday off => previous monday is a bridging day
    mask_tuesday  <- data_tmp[, "JourSemaine"] == 2
    monday_bridge <- data_tmp[which(mask_day_off & mask_tuesday) - 1, ]

    bridging_days <- rbind(monday_bridge, friday_bridge)
    key_bridging_days <- paste(bridging_days$Annee, bridging_days$Mois,
                               bridging_days$Jour, sep = "-")
    key_dates <- paste(data$Annee, data$Mois, data$Jour, sep = "-")
    data$Ponts <- 0
    data$Ponts[key_dates %in% key_bridging_days] <- 1
  }

  daytype_ERDF9 <- ifelse(data$ERDF_TypeJour != "Regular", 7,
                          ifelse(data$Ponts == 1, 8, data$JourSemaine))

  daytype_ERDF9
}


#' Create break variable specific to ERDF needs
#' Origin : ERDF.R
#'
#' Distinction between summer and winter
#'
#' @param data : data.frame, with at least one column 'date', in
#'   POSIXct with tz attribute, or CET24 character
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
generate_break_ERDF_2 <- function(data) {
  # Deprecation warning
  # Use "generate_offsets(data, c(1, 2))" instead
  .Deprecated("generate_offsets", package = "R39Toolbox")

  date_control <- R39Toolbox::check_dates(data)
  if (date_control$tz == "CET24") {
    working_tz <- 'UTC'
  } else {
    working_tz <- date_control$tz
  }
  if ("Annee" %in% colnames(data)) {
    unique_years <- unique(data$Annee)
  } else {
    date_range <- as.POSIXlt(as.character(data$date), tz = working_tz)
    unique_years <- unique(date_range$year + 1900L)
  }

  break.ERDF2 <- rep(0, nrow(data))
  pos_summer_time <- do.call("c", lapply(unique_years, function(x) {
    h <- R39Toolbox:::hour_change_year(x)
    which(as.character(data$date) >= as.POSIXct(h[[2]], tz = working_tz)
        & as.character(data$date)  < as.POSIXct(h[[1]], tz = working_tz))
  }))
  break.ERDF2[pos_summer_time] <- 1

  break.ERDF2
}


#' Create break variable specific to ERDF needs
#' Origin : ERDF.R
#'
#' ?
#'
#' @param data : data.frame, with at least one column 'date', in
#'   POSIXct with tz attribute, or CET24 character
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
generate_break_ERDF_11 <- function(data) {
  # Deprecation warning
  # Use "generate_offsets(data, c(1, 2, 11:15, 21:23))" instead
  .Deprecated("generate_offsets", package = "R39Toolbox")

  date_control <- R39Toolbox::check_dates(data)
  if (date_control$tz == "CET24") {
    working_tz <- 'UTC'
  } else {
    working_tz <- date_control$tz
  }
  date_range <- as.POSIXlt(as.character(data$date), tz = working_tz)
  if ("Annee" %in% colnames(data)) {
    unique_years <- unique(data$Annee)
  } else {
    unique_years <- unique(date_range$year + 1900L)
  }

  # check that ERDF_Rupture2 variable is available (create it otherwise)
  if (!"ERDF_Rupture2" %in% colnames(data)) {
    data$ERDF_Rupture2 <- R39Toolbox::generate_break_ERDF_2(data)
  }

  data$ERDF_Rupture11 <- data$ERDF_Rupture2
  if(!"Annee" %in% colnames(data)) {
    data$Annee <- date_range$year + 1900L
  }
  if(!"Mois" %in% colnames(data)) {
    data$Mois <- date_range$mon + 1L
  }
  if(!"isoSemaine" %in% colnames(data)) {
    isoInfo <- R39Toolbox:::iso_week_year(
      as.POSIXlt(as.Date(date_range, tz = working_tz)), data$Annee)
    data$isoSemaine <- isoInfo$ISOWeek
  }

  # 5 semaine aout
  ctrl <- sapply(unique_years, function(x) {
    # convert August weeks to ISO week format
    date_posix <- as.POSIXlt(
      seq(from = as.POSIXct(paste0(x, "-08-01"), tz = working_tz),
          to   = as.POSIXct(paste0(x, "-08-31"), tz = working_tz),
          by   = 24 * 60 * 60L))
    Y <- as.numeric(format(date_posix, "%Y"))
    calendar_iso <- R39Toolbox:::iso_week_year(date_posix, Y)
    august_week <- table(calendar_iso$ISOWeek)
    # set breaks
    ind <- sort(as.numeric(names(sort(august_week, decreasing = TRUE))[1:5]),
                decreasing = FALSE)
    data$ERDF_Rupture11[(data$Annee == x) & (data$Mois %in% 7:8)
                        & (data$isoSemaine == ind[1])] <<- 5
    data$ERDF_Rupture11[(data$Annee == x) & (data$Mois == 8)
                        & (data$isoSemaine == ind[2])] <<- 6
    data$ERDF_Rupture11[(data$Annee == x) & (data$Mois == 8)
                        & (data$isoSemaine == ind[3])] <<- 7
    data$ERDF_Rupture11[(data$Annee == x) & (data$Mois == 8)
                        & (data$isoSemaine == ind[4])] <<- 8
    data$ERDF_Rupture11[(data$Annee == x) & (data$Mois %in% 8:9)
                        & (data$isoSemaine == ind[5])] <<- 9
  })

  # semaine de noel : du vendredi avant noel au premier lundi de janvier
  # 3 du 24 au 30 decembre
  # 4 du 31 au premier dimanche de janvier
  # 2 avant la vielle de noel, pour faire 17 jours
  christmas_holidays <- data.frame(Jour_Semain_noel = 0:6,
                                   NB_2 = c(8, 2:7), NB_4 = c(2, 8:3))
  year <- (min(unique_years) - 1):(max(unique_years) + 1)
  jf <- sapply(
    "ChristmasDay", do.call,
    list(year=(min(unique_years) - 1):(max(unique_years) + 1)))
  ref_christmas_day <- data.frame(
    year, wday = as.POSIXlt(as.character(jf[[1]]@Data))$wday)
  data$day <- as.Date(as.character(data$date), tz = working_tz)
  ctrl <- apply(ref_christmas_day, 1, function(x) {
    data$ERDF_Rupture11[data$day %in% as.Date(
      paste0(x[1], c("-12-24", "-12-25", "-12-26", "-12-27", "-12-28",
                     "-12-29", "-12-30")))] <<- 3
    data$ERDF_Rupture11[data$day %in% seq.Date(
      from = as.Date(paste0(x[1], "-12-31")),
      by   = 1,
      length.out = christmas_holidays[
        christmas_holidays$Jour_Semain_noel == x[2], "NB_4"])] <<- 4
    data$ERDF_Rupture11[data$day %in% seq.Date(
      from = as.Date(
        paste(x[1], "-12-",
              24 - christmas_holidays[
                christmas_holidays$Jour_Semain_noel == x[2], "NB_2"],
              sep = "")),
      by   = 1,
      length.out = christmas_holidays[
        christmas_holidays$Jour_Semain_noel == x[2], "NB_2"])] <<- 2
  })

  data$ERDF_Rupture11[(data$Mois >= 8) & (data$ERDF_Rupture11 < 2)
                      & (data$ERDF_Rupture2 == 1)] <- 10

  data$ERDF_Rupture11
}


#' Deprecated function in the R39Toolbox package
#' Origin : ERDF.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
createDayType.ERDF <- function(data,
                               choiceHolidays = c(
                                 timeDate::listHolidays(pattern = "*FR"),
                                 "NewYearsDay", "Easter", "EasterMonday",
                                 "LaborDay", "Pentecost", "PentecostMonday",
                                 "ChristmasDay")) {
  .Deprecated("generate_daytype_ERDF", package = "R39Toolbox")
  generate_daytype_ERDF(data, holidays = choiceHolidays)
}

#' Deprecated function in the R39Toolbox package
#' Origin : ERDF.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
createDayType.ERDF7 <- function(data,
                                choiceHolidays = c(
                                  timeDate::listHolidays(pattern = "*FR"),
                                  "NewYearsDay", "Easter", "EasterMonday",
                                  "LaborDay", "Pentecost", "PentecostMonday",
                                  "ChristmasDay")) {
  .Deprecated("generate_daytype_ERDF_7", package = "R39Toolbox")
  generate_daytype_ERDF_7(data, holidays = choiceHolidays)
}

#' Deprecated function in the R39Toolbox package
#' Origin : ERDF.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
createDayType.ERDF9 <- function(data,
                                choiceHolidays = c(
                                  timeDate::listHolidays(pattern = "*FR"),
                                  "NewYearsDay", "Easter", "EasterMonday",
                                  "LaborDay", "Pentecost", "PentecostMonday",
                                  "ChristmasDay")) {
  .Deprecated("generate_daytype_ERDF_9", package = "R39Toolbox")
  generate_daytype_ERDF_9(data, holidays = choiceHolidays)
}

#' Deprecated function in the R39Toolbox package
#' Origin : ERDF.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
createBreak.ERDF2 <- function(data,
                              choiceHolidays = c(
                                timeDate::listHolidays(pattern = "*FR"),
                                "NewYearsDay", "Easter", "EasterMonday",
                                "LaborDay", "Pentecost", "PentecostMonday",
                                "ChristmasDay")) {
  .Deprecated("generate_break_ERDF_2", package = "R39Toolbox")
  generate_break_ERDF_2(data)
}

#' Deprecated function in the R39Toolbox package
#' Origin : ERDF.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @import timeDate
#' @rdname R39Toolbox-deprecated
#' @export
createBreak.ERDF11 <- function(data,
                               choiceHolidays = c(
                                 timeDate::listHolidays(pattern = "*FR"),
                                 "NewYearsDay", "Easter", "EasterMonday",
                                 "LaborDay", "Pentecost", "PentecostMonday",
                                 "ChristmasDay")) {
  .Deprecated("generate_break_ERDF_11", package = "R39Toolbox")
  generate_break_ERDF_11(data)
}

#' Deprecated function in the R39Toolbox package
#' Origin : preprocessings.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
switchTimeZone <- function(data, target.timezone) {
  .Deprecated("switch_time_zone", package = "R39Toolbox")
  switch_time_zone(data, target.timezone)
}

#' Deprecated function in the R39Toolbox package
#' Origin : transform_ejp.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
createTarifVariable <- function(data, type = c('EJP', 'Tempo'),
                                start.hour = "07:00:00", end.hour = "06:30:00") {
  .Deprecated("generate_tarif", package = "R39Toolbox")
  generate_tarif(data = data, type = type,
                 hour_begin = start.hour, hour_end = end.hour)
}

#' Deprecated function in the R39Toolbox package
#' Origin : utils.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
convertToLocalHour24 <- function(data, ind.date) {
  .Deprecated("to_cet24", package = "R39Toolbox")
  to_cet24(data, ind.date)
}

#' Deprecated function in the R39Toolbox package
#' Origin : utils.R
#'
#' This function is provided for compatibility with older version of the
#' R39Toolbox package. It may eventually be completely removed.
#' @rdname R39Toolbox-deprecated
#' @export
hourChangeYear <- function(year) {
  .Deprecated("hour_change_year", package = "R39Toolbox")
  hour_change_year(year)
}


###########################################################################
### Deprecation of the AggregationModel class

#' Deprecated function in the R39Toolbox package
#' Origin : model_aggregation.R
#'
#' Models that are combination of several others
#'
#' Aggregation models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#' Different models may be applied according to a "selection factor" that
#' tells which model should be applied on which part of the data.
#'
#' @param model_list Ordered list of models in the aggregation
#' @param selection_factor_name Name of the variable that is used to
#'   know which model should be applied on which data chunk
#' @param selection_factor_levels List of the selection factor values.
#'   The values in this list and their order are used to determine which
#'   model should be applied on which observations
#'
#' @rdname R39Toolbox-deprecated
#' @export
AggregationModel <- function(model_list,
                             selection_factor_name, selection_factor_levels,
                             transformation_function = NULL,
                             fit_default = NULL) {
  # Deprecation warning
  # Use "CompositeModel" instead
  .Deprecated("CompositeModel", package = "R39Toolbox")

  this <- ForecastModel(fit_default = fit_default,
                        transformation_function = transformation_function)

  this$model_list <- model_list
  this$selection_factor_name   <- selection_factor_name
  this$selection_factor_levels <- selection_factor_levels

  class(this) <- append(class(this), "AggregationModel")
  return(this)
}


#' Deprecated function in the R39Toolbox package
#' Origin : model_aggregation.R
#'
#' Estimation of the models in an AggregationModel
#'
#' This method only dispatches the call the individual models'
#' 'fit' methods. Some checks are run beforehand.
#' It is only a convenient way to fit the models all-at-once (on the same
#' dataset) if one does not want to do it manually.
#'
#' @rdname R39Toolbox-deprecated
#' @export
fit.AggregationModel <- function(model, data_train, leading_period = NULL,
                                 bypass_transform = FALSE, weights = NULL,
                                 by = NULL) {
  # Deprecation warning
  # Use "CompositeModel" instead
  .Deprecated("CompositeModel", package = "R39Toolbox")

  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_train)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_train'"))
  }
  if (length(levels(data_train[[model$selection_factor_name]]))
      != length(model$selection_factor_levels)) {
    stop(paste0("The number of levels in '", model$selection_factor_name,
                "' is different from the number of models in the ",
                "aggregation model"))
  }

  selection_factor <- levels(data_train[[model$selection_factor_name]])[
    data_train[[model$selection_factor_name]]]
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           leading_period_chunk <- leading_period[mask_chunk]
           # remove column used to dispatch data as it might be
           # incompatible with some models the structure of which is
           # determined from the available clumns in the dataset
           ind_select_fact <- which(names(data_train) %in%
               model$selection_factor_name)
           data_train_chunk <- data_train[mask_chunk, - ind_select_fact]
           if (!is.null(weights)) {
             weights_chunk <- weights[mask_chunk]
           } else {
             weights_chunk <- NULL
           }
           # perform fit
           model$model_list[[x]] <<- R39Toolbox::fit(
             model$model_list[[x]], data_train_chunk,
             bypass_transform = TRUE,
             leading_period = leading_period_chunk,
             weights = weights_chunk, by = by)
         })

  return(model)
}


#' Deprecated function in the R39Toolbox package
#' Origin : model_aggregation.R
#'
#' Complex prediction from several models
#'
#' The models may have been fine-tuned or built from different datasets.
#' They can also be of different kind (e.g. GAM, Linear, RandomForest, ...)
#' Aggregation models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#'
#' @rdname R39Toolbox-deprecated
#' @method predict AggregationModel
#' @export
predict.AggregationModel <- function(model, data_prediction,
                                     bypass_transform = FALSE,
                                     leading_period = NULL) {
  # Deprecation warning
  # Use "CompositeModel" instead
  .Deprecated("CompositeModel", package = "R39Toolbox")

  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_prediction)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_prediction'"))
  }
  unique_prediction_levels <- unique(
    data_prediction[[model$selection_factor_name]])
  if (length(unique_prediction_levels)
      > length(model$selection_factor_levels)) {
    stop(paste0("There are more levels in '", model$selection_factor_name,
                "' than there are models in the aggregation model."))
  }
  if (!all(unique_prediction_levels %in% model$selection_factor_levels)) {
    stop(paste0("There are levels in '", model$selection_factor_name,
                "' than do not correspond to a model ",
                "in the aggregation model."))
  }

  selection_factor <- levels(data_prediction[[model$selection_factor_name]])[
    data_prediction[[model$selection_factor_name]]]
  prediction <- vector(length = nrow(data_prediction))
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           if (length(which(mask_chunk)) > 0) {
             leading_period_chunk <- leading_period[mask_chunk]
             # remove column used to dispatch data as it might be
             # incompatible with some models the structure of which is
             # determined from the available clumns in the dataset
             ind_select_fact <- which(names(data_prediction) %in%
                                        model$selection_factor_name)
             data_prediction_chunk <- data_prediction[
               mask_chunk, - ind_select_fact]
             # perfom prediction
             prediction[mask_chunk] <<- predict(
               model$model_list[[x]], data_prediction_chunk,
               bypass_transform = TRUE, leading_period = leading_period_chunk)
           }
         })

  return(as.numeric(prediction))
}


#' Deprecated function in the R39Toolbox package
#' Origin : model_aggregation.R
#'
#' Complex prediction from several models
#'
#' The models may have been fine-tuned or built from different datasets.
#' They can also be of different kind (e.g. GAM, Linear, RandomForest, ...)
#' Aggregation models offer a convenient way to manipulate them together to
#' perform a global prediction using several, combined approaches.
#'
#' @rdname R39Toolbox-deprecated
#' @export
predict_details.AggregationModel <- function(model, data_prediction,
                                             bypass_transform = FALSE,
                                             leading_period = NULL) {
  # Deprecation warning
  # Use "CompositeModel" instead
  .Deprecated("CompositeModel", package = "R39Toolbox")

  # Transform data if needed
  if (!is.null(model$transformation_function) && !bypass_transform) {
    data_prediction <- model$transformation_function(data_prediction)
  }
  # check leading_period argument
  leading_period <- R39Toolbox:::check_leading_period(
    leading_period, data_prediction)

  # check the selection factor exists in prediction data
  if (!model$selection_factor_name %in% colnames(data_prediction)) {
    stop(paste0("Cannot find '", model$selection_factor_name,
                "' variable in 'data_prediction'"))
  }
  if (length(levels(data_prediction[[model$selection_factor_name]]))
      > length(model$selection_factor_levels)) {
    stop(paste0("There are more levels in '", model$selection_factor_name,
                "' than there are models in the aggregation model"))
  }

  selection_factor <- levels(data_prediction[[model$selection_factor_name]])[
      data_prediction[[model$selection_factor_name]]]
  all_effect_names <- NULL
  # Get the names of the effects for all the aggregated models
  for (i in 1:length(model$selection_factor_levels)) {
    mask_chunk <- (
      selection_factor == model$selection_factor_levels[[i]])
    data_prediction_chunk <- data_prediction[mask_chunk, ][1, , drop = FALSE]
    prediction_chunk <- predict_details(
      model$model_list[[i]], data_prediction_chunk,
      bypass_transform = TRUE, leading_period = NULL)
    all_effect_names <- c(all_effect_names, colnames(prediction_chunk))
  }
  all_effect_names <- unique(all_effect_names)
  prediction <- as.data.frame(
    matrix(nrow = nrow(data_prediction),
           ncol = length(all_effect_names)))
  colnames(prediction) <- all_effect_names
  # Do the actual prediction
  sapply(1:length(model$selection_factor_levels),
         function(x) {
           mask_chunk <- (
             selection_factor == model$selection_factor_levels[[x]])
           leading_period_chunk <- leading_period[mask_chunk]
           data_prediction_chunk <- data_prediction[mask_chunk, ]
           prediction_chunk <- predict_details(
             model$model_list[[x]], data_prediction_chunk,
             bypass_transform = TRUE, leading_period = leading_period_chunk)
           prediction[mask_chunk, colnames(prediction_chunk)] <<- prediction_chunk
         })

  return(prediction)
}
