

# Check and transform data so that it is compatible with REventail I/O
# This is made according to the mapping defined via the attributes
# of an eventail model.
checkEventailData <- function(eventail_model, data, weights = NULL) {
  # Date column
  if (!eventail_model$col_date %in% names(data)) {
    stop(paste0("Missing '", eventail_model$col_date,
                "' column in the dataset."))
  } else {
    data$Date <- data[[eventail_model$col_date]]
  }

  #Instant column
  if (!'Instant' %in% names(data)) {
    stop("Missing 'Instant' column in the dataset.")
  } else {
    if (class(data$Instant) == 'factor') {
      data$Instant <- as.integer(as.character((data$Instant)))
    } else {
      data$Instant <- as.integer(data$Instant)
    }
  }

  # Load column
  if (eventail_model$col_load %in% names(data)) {
    data$Load <- data[[eventail_model$col_load]]
  } else {
    warning(paste0("No column '", eventail_model$col_load, "' found in the ",
                   "dataset. A null column will be used."))
    data$Load <- 0
  }

  # Temperature column
  # TODO: add support for multiple stations
  if (eventail_model$col_temperature %in% names(data)) {
    data$Temperature1 <- as.numeric(
      data[[eventail_model$col_temperature]])
  } else {
    stop(paste0("No column '", eventail_model$col_temperature,
                "' found in the dataset"))
  }

  # Nebulosity column
  # TODO: add support for multiple stations
  if (eventail_model$col_nebulosity %in% names(data)) {
    data$Nebulosity1 <- as.numeric(
      data[[eventail_model$col_nebulosity]])
  } else {
    if (!is.null(eventail_model$col_nebulosity)) {
      warning(paste0("No column '", eventail_model$col_nebulosity,
                     "' found in the dataset"))
    }
  }

  # DayValidity column
  if (!is.null(weights)) {
    # binarize weights because Eventail can only handle 0/1 values
    weights[weights == 0] <- 0
    weights[weights != 0] <- 1
    data$DayValidity <- as.numeric(weights)
  } else {
    data$DayValidity <- as.numeric(1)
  }

  # Offset column
  if (!eventail_model$col_offset %in% names(data)) {
    warning(paste0("Missing '", eventail_model$col_offset,
                   "' column in the dataset. ",
                   "'0' will be used as a constant offset."))
    data$Offset <- as.integer(0)
  } else {
    data$Offset <- data[[eventail_model$col_offset]]
  }

  # DayType column
  if (!eventail_model$col_daytype %in% names(data)) {
    warning(paste0("Missing '", eventail_model$col_daytype,
                   "' column in the dataset. ",
                   "'0' will be used as a constant day type."))
    data$DayType <- as.integer(0)
  } else {
    if (class(data$DayType) == 'factor') {
      data$DayType <- as.integer(
        as.character((data[[eventail_model$col_daytype]])))
    } else {
      data$DayType <- data[[eventail_model$col_daytype]]
    }
  }

  # STFDayType column
  if (!eventail_model$col_daytype_st %in% names(data)) {
    warning(paste0("Missing '", eventail_model$col_daytype_st,
                   "' column in the dataset. ",
                   "'0' will be used as a constant day type."))
    data$STFDayType <- as.integer(0)
  } else {
    if (class(data$DayType) == 'factor') {
      data$STFDayType <- as.integer(
        as.character((data[[eventail_model$col_daytype]])))
    } else {
      data$STFDayType <- data[[eventail_model$col_daytype]]
    }
  }

  # order columns
  column.order <- c('Date', 'Instant', 'DayValidity', 'Load',
                    'Offset', 'DayType', 'STFDayType', 'Temperature1')
  if ('Nebulosity1' %in% names(data)) {
    column.order <- c(column.order, c('Nebulosity1'))
  }
  data <- data[, column.order]

  data
}


### Eventail (mid-term) -----------------------------

#' Eventail model (mid-term)
#'
#' This class is an interface to the REventail package, that is itself
#' an interface to the Eventail C library. Thus, and because Eventail is
#' a parametric model, we map every Eventail parameter to an attribute of
#' the corresponding EventailModel R object.
#' Eventail also relies on specific types of variables that must match
#' specific column names in the dataset. We set up the correspondance
#' between these and the R dataset variable names with the help of more
#' attributes that can be set by the user.
#'
#' @param col_XXX : Name of the XXX variable in the input dataset.
#'                  Such a mapping is necessary because Eventail works
#'                  with variable that are fixed in advance and that should
#'                  have a specific name.
#' @param <eventail.parameter> : User-defined value for the parameter. If not
#'                               given, the parameter will be optimised freely.
#' @param XXX.trend : Data-frame with 'Date' and 'Value' columns to indicate
#'                    which trend must be considered at which date. This
#'                    has the side-effect of imposing that the dates that are
#'                    provided in the trends must be later  included in the
#'                    train dataset.
#'
#' @export
EventailModel <- function(
  col_date = 'date', col_load = 'Load', col_temperature = 'Temperature',
  col_nebulosity = 'Nebulosity', col_dayvalidity = 'DayValidity',
  col_offset = 'Offset', col_daytype = 'DayType',
  col_daytype_st = 'STFDayType',
  fourier_n = 4, fourier_m = 4,
  dispersion_summer = NULL, dispersion_winter = NULL,
  alpha_winter_level = NULL, alpha_winter_shape = NULL,
  alpha_summer_level = NULL, alpha_summer_shape = NULL,
  beta_winter_level = NULL, beta_winter_shape = NULL,
  teta_winter_level = NULL, teta_winter_shape = NULL,
  teta2_winter_level = NULL, teta2_winter_shape = NULL,
  teta_summer_level = NULL, teta_summer_shape = NULL,
  threshold_winter_level = NULL, threshold_winter_shape = NULL,
  threshold_summer_level = NULL, threshold_summer_shape = NULL,
  extra_threshold_winter_level = NULL, extra_threshold_winter_shape = NULL,
  gradient_winter_level = NULL, gradient_winter_shape = NULL,
  gradient_summer_level = NULL, gradient_summer_shape = NULL,
  extra_gradient_winter_level = NULL, extra_gradient_winter_shape = NULL,
  mu = NULL, nu_level = NULL, nu_shape = NULL,
  wil_trends = NULL, heating_trends = NULL, cooling_trends = NULL,
  fit_default = list(), transformation_function = NULL) {

  if (is.null(fit_default$n_iter)) {
    fit_default$n_iter <- 1000
  }
  this <- MidTermForecastModel(fit_default = fit_default)

  this$col_date        <- col_date
  this$col_load        <- col_load
  this$col_temperature <- col_temperature
  this$col_nebulosity  <- col_nebulosity
  this$col_dayvalidity <- col_dayvalidity
  this$col_offset      <- col_offset
  this$col_daytype     <- col_daytype
  this$col_daytype_st  <- col_daytype_st
  this$fourier_n       <- fourier_n
  this$fourier_m       <- fourier_m
  this$dispersion_summer            <- dispersion_summer
  this$dispersion_winter            <- dispersion_winter
  this$alpha_winter_level           <- alpha_winter_level
  this$alpha_winter_shape           <- alpha_winter_shape
  this$alpha_summer_level           <- alpha_summer_level
  this$alpha_summer_shape           <- alpha_summer_shape
  this$beta_winter_level            <- beta_winter_level
  this$beta_winter_shape            <- beta_winter_shape
  this$teta_winter_level            <- teta_winter_level
  this$teta_winter_shape            <- teta_winter_shape
  this$teta2_winter_level           <- teta2_winter_level
  this$teta2_winter_shape           <- teta2_winter_shape
  this$teta_summer_level            <- teta_summer_level
  this$teta_summer_shape            <- teta_summer_shape
  this$threshold_winter_level       <- threshold_winter_level
  this$threshold_winter_shape       <- threshold_winter_shape
  this$threshold_summer_level       <- threshold_summer_level
  this$threshold_summer_shape       <- threshold_summer_shape
  this$extra_threshold_winter_level <- extra_threshold_winter_level
  this$extra_threshold_winter_shape <- extra_threshold_winter_shape
  this$gradient_winter_level        <- gradient_winter_level
  this$gradient_winter_shape        <- gradient_winter_shape
  this$gradient_summer_level        <- gradient_summer_level
  this$gradient_summer_shape        <- gradient_summer_shape
  this$extra_gradient_winter_level  <- extra_gradient_winter_level
  this$extra_gradient_winter_shape  <- extra_gradient_winter_shape
  this$mu       <- mu
  this$nu_level <- nu_level
  this$nu_shape <- nu_shape
  this$wil_trends     <- wil_trends
  this$heating_trends <- heating_trends
  this$cooling_trends <- cooling_trends

  class(this) <- append(class(this), "EventailModel")
  return(this)
}


#' Estimation of an EventailModel
#'
#' Eventail needs a leading period to have an accurate smoothing of the
#' temperature on the estimation period. One should use the 'weights' argument
#' accordingly.
#'
#' @rdname fit
#' @export
fit.EventailModel <- function(mid_term_model, data_train, bypass_transform = FALSE,
                              weights = NULL, by = NULL, n_iter = NULL) {

  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(by)) {  # default is NULL
    by <- mid_term_model$fit_default[["by"]]
  }
  if (is.null(n_iter)) {  # default is 1000
    n_iter <- mid_term_model$fit_default[["n_iter"]]
  }

  # Check and transform data so that it is compatible with REventail I/O
  data_train <- checkEventailData(mid_term_model, data_train, weights)
  if (!"Load" %in% names(data_train)) {
    stop("No column '", mid_term_model$col_load, "' found in 'data_train'")
  }

  require(REventail)
  parameters <- REventail::eventailInit(
    data_train,
    mid_term_model$fourier_n, mid_term_model$fourier_m)
  parameters <- REventail::eventailFixe(
    parameters,
    cEte = mid_term_model$dispersion_summer,
    cHiver = mid_term_model$dispersion_winter,
    alphaHiver0 = mid_term_model$alpha_winter_shape,
    alphaHiver1 = mid_term_model$alpha_winter_level,
    alphaEte0 = mid_term_model$alpha_summer_shape,
    alphaEte1 = mid_term_model$alpha_summer_level,
    betaHiver0 = mid_term_model$beta_winter_shape,
    betaHiver1 = mid_term_model$beta_winter_level,
    teta1Hiver0 = mid_term_model$teta_winter_shape,
    teta1Hiver1 = mid_term_model$teta_winter_level,
    teta2Hiver0 = mid_term_model$teta2_winter_shape,
    teta2Hiver1 = mid_term_model$teta2_winter_level,
    tetaEte0 = mid_term_model$teta_summer_shape,
    tetaEte1 = mid_term_model$teta_summer_level,
    seuilHiver0 = mid_term_model$threshold_winter_shape,
    seuilHiver1 = mid_term_model$threshold_winter_level,
    seuilEte0 = mid_term_model$threshold_summer_shape,
    seuilEte1 = mid_term_model$threshold_summer_level,
    surseuilHiver0 = mid_term_model$extra_threshold_winter_shape,
    surseuilHiver1 = mid_term_model$extra_threshold_winter_level,
    gradHiver0 = mid_term_model$gradient_winter_shape,
    gradHiver1 = mid_term_model$gradient_winter_level,
    gradEte0 = mid_term_model$gradient_summer_shape,
    gradEte1 = mid_term_model$gradient_summer_level)
  # TODO: deal with ExogenousVariableX trends
  if (!is.null(c(mid_term_model$wil_trends, mid_term_model$heating_trends,
                 mid_term_model$cooling_trends))) {
    parameters <- REventail::eventailFixeTendance(
       parameters,
       WeatherIndependentLoad = mid_term_model$wil_trends,
       HeatingLoad            = mid_term_model$heating_trends,
       CoolingLoad            = mid_term_model$cooling_trends,
       ExogenousVariableLoad1 = NULL)
  }
  # object parameters
  mid_term_model$parameters_init_ <- parameters
  mid_term_model$parameters_opt_  <- REventail::eventailOptimise(
    data_train, mid_term_model$parameters_init_, n_iter)
  mid_term_model$n_iter_ <- n_iter
  mid_term_model$model_ <- "fit->ok"

  return(mid_term_model)
}


#' Prediction of the target variable from observations
#'
#' Eventail needs a leading period to have an accurate smoothing of
#' the temperature on the prediction period. 'target_period' should be
#' used accordingly.
#'
#' @rdname predict
#' @method predict EventailModel
#' @export
predict.EventailModel <- function(model, data_prediction,
                                  bypass_transform = FALSE,
                                  target_period = NULL) {
  data_prediction <- checkEventailData(model, data_prediction,
                                       weights = target_period)
  data_prediction$DayValidity <- as.numeric(1)

  require(REventail)
  prediction <- REventail::eventailSimule(
    data_prediction, model$parameters_opt_)
  return(prediction$EstimatedLoad)
}


### Eventail (short-term) -----------------------------

#' ShortTermForecast model (Eventail)
#'
#' @param model.list :
#'
#' @export EventailShortTermModel
EventailShortTermModel <- function(mid_term_model, target_variable,
                                   by_day_type = 1, fit_default = list(),
                                   predict_default = list(),
                                   transformation_function = NULL) {
  if (is.null(predict_default$mode)) {
    predict_default$mode <- 'online'  # 'fixed', 'online' or 'update'
  }
  this <- ShortTermForecastModel(
    target_variable, fit_default = fit_default,
    predict_default = predict_default,
    transformation_function = transformation_function)

  # are all models Forecast objects?
  if (!"MidTermForecastModel" %in% class(mid_term_model)) {
    stop(paste0("Only 'MidTermForecastModel' objects can be considered ",
                "in an 'EventailShortTermModel'."))
  }

  # TODO : add LM options such as "na.action", "weights", ...
  this$mid_term_model <- mid_term_model
  this$by_day_type    <- by_day_type

  class(this) <- append(class(this), "EventailShortTermModel")
  return(this)
}

#' Estimation of an EventailShortTermModel
#'
#' @param short_term_model :
#' @param data_train :
#'
#' @return ?
#'
#' @rdname fit
#' @export
fit.EventailShortTermModel <- function(short_term_model, data_train,
                                       bypass_transform = FALSE,
                                       weights = NULL) {
  mid_term_model <- short_term_model$mid_term_model

  # is the mid-term model fit already?
  mid_term_model_fit <- !is.null(mid_term_model$model_)
  # if the mid term model is not fit already, of if refit is forced,
  # we use 'data_train' to train it.
  if (!mid_term_model_fit) {
    # model-specific arguments to 'fit' can be controlled
    # at the model creation time
    short_term_model$mid_term_model <- R39Toolbox::fit(
      mid_term_model, data_train, bypass_transform = TRUE, weights = weights)
    mid_term_model <- short_term_model$mid_term_model
  }

  # Check and transform data so that it is compatible with REventail I/O
  data_train <- checkEventailData(mid_term_model, data_train,
                                  weights = weights)
  if (!"Load" %in% names(data_train)) {
    stop("No column '", mid_term_model$col_load, "' found in 'data_train'")
  }

  # train the short-term model using 'data_train' (again)
  # TODO: expose the horizon argument (0/1) to the user
  parameters <- REventail::eventailCreationPCTDefaut(data_train, 1)
  prediction_mid_term <- REventail::eventailSimule(
    data_train, mid_term_model$parameters_opt_)
  short_term_model$parameters_opt_ <- REventail::eventailOptimisationPCT(
    data_train, prediction_mid_term, parameters,
    byDayType = short_term_model$by_day_type)
  short_term_model$model_ <- "fit->ok"

  return(short_term_model)
}


#' Prediction with an EventailShortTermModel
#'
#'
#' @rdname predict
#' @method predict EventailShortTermModel
#' @export
predict.EventailShortTermModel <- function(model,
                                           data_prediction, mode = NULL,
                                           bypass_transform = FALSE,
                                           target_period = NULL) {
  # check the model has been fit
  if (is.null(model$model_)) {
    stop(paste0("Please fit the model before it can be used to ",
                "make a prediction."))
  }
  # Use default fit options if not provided as argument (i.e. NULL)
  if (is.null(mode)) {  # default is 'update' (can be 'fixed' or 'online' too)
    mode <- model$predict_default[["mode"]]
  }

  mid_term_model <- model$mid_term_model
  data_prediction <- checkEventailData(mid_term_model, data_prediction,
                                       weights = target_period)
  data_prediction$DayValidity <- as.numeric(1)

  n_obs <- dim(data_prediction)[[1]]
  mid_term_prediction <- REventail::eventailSimule(
    data_prediction, model$mid_term_model$parameters_opt_)

  lag_max <- max(model$parameters_opt_$Lags)

  # if no data is provided for online prediction, we perform a mid-term
  # forecast with the short-term model (i.e. not only we use fixed parameters
  # that have been learnt with a prior call to the 'fit' function, but also we
  # do not weight the prediction by day-to-day errors).
  if (!"Load" %in% names(data_prediction)) {
    stop(paste0("The Eventail short-term model relies on errors up to ",
                    lag_max, " time points before the begining of the actual ",
                    "prediction. The column for the target variable values ",
                    "is missing in the dataset."))
  }
  load_orig <- data_prediction$Load

  # check that enough past information is available
  if (is.null(target_period)) {  # infer min number of past errors
    warning(paste0("No leading period is defined in the ",
                   "short-term prediction dataset. However, the Eventail ",
                   "short-term model relies on errors up to ", lag_max,
                   " time points before the begining of the actual ",
                   "prediction. Thus, the ", lag_max, " first observations ",
                   "of the input dataset will be use as a leading period ",
                   "to setup the prediction."))
    data_prediction$DayValidity <- as.numeric(0)
    data_prediction$DayValidity[1:lag_max] <- 1
  } else {
    if (length(unique(target_period[1:lag_max])) != 1
        | target_period[[1]] != 0) {
      # not enough information --> stop because not sure what the user wants
      stop(paste0("The Eventail short-term model relies on errors up to ",
                  lag_max, " time points before the begining of the actual ",
                  "prediction. Not enough time points are definied in ",
                  "the 'target_period' argument."))
    }
    data_prediction$DayValidity[target_period == 0] <- 1
    data_prediction$DayValidity[target_period != 0] <- 0
    data_prediction$DayValidity <- as.numeric(data_prediction$DayValidity)
  }

  # actual prediction
  if (mode == "fixed") {
    mid_term_prediction$DayValidity <- data_prediction$DayValidity
    data_prediction$Load     <- load_orig
    mid_term_prediction$Load <- load_orig
    data_prediction$Load[data_prediction$DayValidity == 0] <- 0
    mid_term_prediction$Load[data_prediction$DayValidity == 0] <- 0
    prediction <- REventail::eventailPrevision(
      data_prediction, mid_term_prediction,
      model$parameters_opt_,
      byDayType = model$by_day_type)$ShortTermForecast
    prediction[data_prediction$DayValidity == 1] <- NA
  } else if (mode %in% c("online", "update")) {
    prediction <- rep(0, nrow(data_prediction))
    prediction[data_prediction$DayValidity == 1] <- NA
    short_term_prediction_start <- which(data_prediction$DayValidity == 0)[[1]]
    short_term_prediction_end   <- length(data_prediction$DayValidity)
    for (i in short_term_prediction_start:short_term_prediction_end) {
      mid_term_prediction$DayValidity <- 0
      mid_term_prediction$DayValidity[1:(i - 1)] <- 1
      data_prediction$DayValidity <- mid_term_prediction$DayValidity
      data_prediction$Load     <- load_orig
      mid_term_prediction$Load <- load_orig
      data_prediction$Load[data_prediction$DayValidity == 0] <- 0
      mid_term_prediction$Load[data_prediction$DayValidity == 0] <- 0
      prediction_aux <- REventail::eventailPrevision(
        data_prediction, mid_term_prediction,
        model$parameters_opt_,
        byDayType = model$by_day_type)
      prediction[i] <- prediction_aux$ShortTermForecast[i]
      if (mode == 'update') {
        # caveat: may be bad if the past error information is small
        # (the user should provide a long dataset, with a lot of null weights
        #  so that the model can be trained on a period that is long enough)
        # caveat2: the model is not updated outside from this function. Maybe
        # it is better if it is updated.
        weights_update    <- mid_term_prediction$DayValidity
        weights_update[i] <- 1
        mask_update       <- which(weights_update == 1)
        model$parameters_opt_ <- REventail::eventailOptimisationPCT(
          data_prediction[mask_update, ], prediction_mid_term[mask_update, ],
          model$parameters_opt_,
          byDayType = model$by_day_type)
      }
    }
  } else {
    stop("Undefined 'mode' for short-term prediction")
  }

  return(prediction)
}

############# Specific functions re-written in pure R from Eventail's
############# original code

#' Prevision Eventail court-terme, eventuellement par type de jour
#'
#' @param data Le jeu de donnees initial
#' @param resultats Les resultats de la prevision
#' @param STFparameters Les parametres du modele
#' @param type_recalage "infra" ou "hebdo"
#' @param byDayType Flag qui permet de choisir un calcul par types de
#'   jours ou non
#'
#' @return un dataframe
#' @export
eventailPrevisionCourtTerme <- function(data, resultats, STFparameters, 
                                        type_recalage, byDayType = FALSE) {
  
  if (!type_recalage %in% c("hebdo", "infra")) {
    stop(
      "'type_recalage' ne peut prendre que deux valeurs : 'infra' ou 'hebdo'.")
  }
  
  n_lags <- 1:length(STFparameters$Lags)
  
  if (byDayType) {
    current_DT <- data$DayType
  } else {
    current_DT <- rep(1, times = nrow(data))
  }
  
  # Pour toutes les lignes de data et toutes les valeurs de
  # STFparameters$Lags on calcule une matrice des indices de "lag"
  # correspondants
  lags <- 1:nrow(data) - matrix(rep(STFparameters$Lags, each = nrow(data)), 
                                nrow = nrow(data))
  
  # les valeurs negatives ou nulles sont remplacees par NA
  lags[lags < 1] <- NA_integer_
  
  # on met sous forme de matrice les coeffs recuperes de STFparameters  
  STFparameters_coeffs <- t(sapply(current_DT, 
                                   function (daytype) {
                                     STFparameters$Coeffs[daytype, ]
                                   }))
  
  # on remplit les matrices de donnees auxquelles sont appliques les "lags"
  data_DayValidity_lags <- sapply(n_lags, 
                                  function (column) {
                                    data$DayValidity[lags[, column]]
                                  })
  
  data_Load_lags <- sapply(n_lags, 
                           function (column) {
                             data$Load[lags[, column]]
                           })
  
  # Suivant le type de recalage demande, la colonne de resultats a considerer 
  # est EstimatedLoad ou ShortTermForecast
  if (type_recalage == "hebdo") {
    resultats_load <- resultats$EstimatedLoad
  } else {
    resultats_load <- resultats$ShortTermForecast
  }
  
  resultats_lags <- sapply(n_lags, 
                           function (column) {
                             resultats_load[lags[, column]]
                           })
  
  # on calcule correctionPCT pour toutes les donnees
  corr_temp <- STFparameters_coeffs * (data_Load_lags - resultats_lags)
  
  # si DayValidity est nul, la correction est remise a zero Elle est
  # calculee ulterieurement avec plusieurs iterations de resultatsPCT
  corr_temp[data_DayValidity_lags == 0] <- 0
  
  # premiere iteration de correctionPCT (uniquement sur DayValidity == 1 ou NA)
  correctionPCT <- rowSums(corr_temp, na.rm = TRUE)
  
  # tant que correctionPCT n'est pas stationnaire, on recalcule resultatsPCT
  diff <- 1
  iteration <- 0
  while (!(diff == 0) & iteration < nrow(data)) {
    iteration <- iteration + 1

    # Prevision corrigee
    resultatsPCT <- resultats_load + correctionPCT
    
    # Application de la matrice lags a la prevision corrigee
    resultatsPCT_lags <- sapply(n_lags, 
                                function (column) {
                                  resultatsPCT[lags[, column]]
                                })
    
    # Pour les cas ou DayValidity est nul, la correction est calculee
    # avec resultatsPCT_lags (au lieu de data_Load_lags)
    corr_temp2 <- STFparameters_coeffs * (resultatsPCT_lags - resultats_lags)
    
    # on calcule la difference entre deux versions successives de correctionPCT
    diff <- sum(
      corr_temp[data_DayValidity_lags == 0 & !is.na(corr_temp)] - 
        corr_temp2[data_DayValidity_lags == 0 & !is.na(corr_temp2)])
    
    # on remplace les precedentes valeurs de correctionPCT ou DayValidity == 0
    corr_temp[data_DayValidity_lags == 0 & !is.na(corr_temp)] <- (
      corr_temp2[data_DayValidity_lags == 0 & !is.na(corr_temp2)])
    
    correctionPCT <- rowSums(corr_temp, na.rm = TRUE)
  }
  
  data$ShortTermForecast <- resultatsPCT
  
  data
}


#' Fonction pour calculer le recalage infra (apres avoir effectuer une
#' prevision court terme).
#'
#' @param donnees Fichier de donnees source
#' @param resultats Fichier de resultats court-terme source
#' @param start Indice indiquant le debut du recalage
#' @param CoeffDeRecopie coefficient pour le recalage
#'
#' @return le jeu de donnees avec la colonne ShortTermForecast modifiee
#' @examples
#' #' ## Not run:
#'  param.stf.infra <- creerParametrePCT( coefs.infra )
#'  prev_short_term <- eventailPrevisionCourtTerme_tmp(data = simu,
#'                                                     resultats = recal,
#'                                                     STFparameters = param.stf.infra,
#'                                                     byDayType = 0,
#'                                                     type_recalage = "infra")
#'  recal_from_me <- remplitPCTapres(donnees = prev_short_term,
#'                                    resultats = recal,
#'                                    start = start,
#'                                    CoeffDeRecopie = report.infra)
#' ## End(Not run)
#' @export
remplitPCTapres <- function(donnees, resultats, start, CoeffDeRecopie) {
  n_instants   <- length(unique(donnees$Instant))
  fitting_band <- numeric(n_instants)
  for (i in 1:n_instants) {
    fitting_band[i] <- (
      donnees$ShortTermForecast[(start - 1) + i] -
      resultats$ShortTermForecast[(start - 1) + i])
  }
  data_length   <- nrow(donnees)
  current_coeff <- 1.0
  for (i in start:data_length) {
    #in order to not change the coeff immediatly
    if (i != start) {
      if (((i - start + n_instants) %% n_instants) == 0) {
        current_coeff <- current_coeff * CoeffDeRecopie
      }
    }
    donnees$ShortTermForecast[i] <- (
      resultats$ShortTermForecast[i] +
      fitting_band[(i - start + n_instants) %% n_instants + 1] *
      current_coeff)
  }
  
  donnees
}

#' Fonction pour creer les parametres PCT pour le recalage infra
#'
#' @param lag_coeffs un vecteur contenant les coefficients a utiliser
#'
#' @return une liste
creerParametrePCT <- function(lag_coeffs) {
  list(
    Horizon    = as.integer(999), 
    LaunchHour = as.integer(0), 
    Lags       = 1:length(lag_coeffs), 
    Coeffs     = as.matrix(lag_coeffs)
  )
}


#' Read short term parameters from a file
#'
#' @param filename Path to the file
#' 
#' @return A structure containing the short term parameters
#' @examples
#' param.pct <- readParametersPCT(file.path(system.file("nonregdata", 
#'                                                      "output",
#'                                                      package="REventail"),
#'                                          "1-stf_ini.txt"))
readParametersPCT <- function(filename) {
  tryCatch({
    params <- list()
    lecture_coeff <- FALSE
    
    contenu <- lapply(strsplit(readLines(filename), "\t"), as.character)
    
    for (num_ligne in 1:length(contenu)) {
      taille <- length(contenu[[num_ligne]])
      
      if (contenu[[num_ligne]][1] == 'Lags') {
        params$Lags <- as.integer(contenu[[num_ligne]][2:taille])
      }
      else if (contenu[[num_ligne]][1] == 'Coeffs') {
        lecture_coeff <- TRUE 
      }
      
      if (lecture_coeff) {
        if (taille == length(params$Lags) + 1) {
          params$Coeffs <- rbind(
            params$Coeffs, as.double(contenu[[num_ligne]][2:taille]))
        }
      }
    }
    params
  }, error = function(e) {
    stop('Erreur de lecture du fichier de poids de recalage hebdo ', filename)
  })
}
