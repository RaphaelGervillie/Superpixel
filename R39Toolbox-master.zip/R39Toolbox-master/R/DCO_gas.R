#' Create daytypes for DCO gas process
#'
#' In the DCO gas process, the operator interventions (including
#' consumption forecast) only occur on working days.
#'
#' Betwwen 1908 and 2050, there is only one day where launch_daytype
#' == "J+4" and none with a higher launch_daytype value. Therefore, we set
#' the levels of the output factor as '"J":"J+4"'.
#'
#' @param data The input dataset for which one wants to generate daytypes
#'
#' @return The column vector (as a factor) that correspond to the daytypes
#'
#' @export
generate_daytypes_dco_gas_process <- function(data) {
  # get dataset time properties (timezone, time sampling rate)
  date_control <- R39Toolbox::check_dates(data)

  ### Select unique days to compute the dco gas process daytype
  data_orig <- data
  data <- data[
    !duplicated(
      strftime(data$date, format = "%F", tz = date_control$tz)), ,
    drop = FALSE]

  ### Compute the dco gas daytypes
  weekdays <- R39Toolbox::generate_daytypes(data, c(0:6))
  aux_daytype <- R39Toolbox::generate_daytypes(data, c(12, 30, 6, 0))
  aux_daytype <- as.numeric(levels(aux_daytype)[aux_daytype])
  launch_daytypes_labels <- c("J", "J+1", "J+2", "J+3", "J+4")
  launch_daytype <- rep("?", length(aux_daytype))
  # type for the first day
  if (aux_daytype[[1]] == 6) {
    launch_daytype[[1]] <- launch_daytypes_labels[[2]]
  } else if (aux_daytype[[1]] == 0) {
    launch_daytype[[1]] <- launch_daytypes_labels[[3]]
  } else if (aux_daytype[[1]] == 30) {
    if (weekdays[[1]] == 1) {
      launch_daytype[[1]] <- launch_daytypes_labels[[4]]
    } else {
      launch_daytype[[1]] <- launch_daytypes_labels[[2]]
    }
  } else {
    launch_daytype[[1]] <- launch_daytypes_labels[[1]]
  }
  # type for all the other days
  launch_daytype[aux_daytype == 12] <- launch_daytypes_labels[[1]]

  for (i in 2:5) {
    test_days <- which(launch_daytype == launch_daytypes_labels[[i - 1]]) + 1
    test_days <- test_days[test_days <= length(launch_daytype)]
    days_i <- test_days[
      launch_daytype[test_days] != launch_daytypes_labels[[1]]]
    if (length(days_i) > 0) {
      launch_daytype[days_i] <- launch_daytypes_labels[[i]]
    }
  }

  launch_daytypes <- factor(
    launch_daytype,
    levels = launch_daytypes_labels, labels = launch_daytypes_labels)

  ### Put back the launch_daytypes into original data
  data_orig$tmp <- strftime(data_orig$date, format = "%F", tz = date_control$tz)
  data$tmp      <- strftime(data$date, format = "%F", tz = date_control$tz)
  data$launch_daytypes <- launch_daytypes
  data <- merge(data_orig[, c('tmp', 'date')], data[, c('tmp', 'launch_daytypes')],
                by = c('tmp'))
  data <- data[order(data$date), ]

  data$launch_daytypes
}

###############################################################################
### Gas process simulation

#' Forecast with a given model according to dco gas operational rules
#'
#' Forecasts are made only on working days
#'
#' @param model Forecast model to be used for the forecast
#' @param data data defining the period on which to run the
#'   simulation. Note that a prediction will be made for evey instant
#'   in the dataset.
#'
#' @return The prediction as a numeric argument
#'
#' @rdname simulate_dco_gas_process
#' @export
simulate_dco_gas_process <- function(model, data, leading_period = NULL) {
  UseMethod("simulate_dco_gas_process", model)
}

#' @rdname simulate_dco_gas_process
#' @export
simulate_dco_gas_process.default <- function(model, data, leading_period = NULL) {
  data$launch_daytype <- generate_daytypes_dco_gas_process(data)
  launch_dates <- data$date[data$launch_daytype == "J"]
  R39Toolbox::simulate(
    model, data, delay = 1,
    update_frequency = launch_dates, launch_frequency = launch_dates,
    leading_period = leading_period)
}

#' @rdname simulate_dco_gas_process
#' @export
simulate_dco_gas_process.ReadjustedModel <- function(model, data,
                                                     leading_period = NULL) {
  data$launch_daytype <- R39Toolbox::generate_daytypes_dco_gas_process(data)
  launch_dates <- data$date[data$launch_daytype == "J"]
  R39Toolbox::simulate(
    model, data, delay = 1,
    update_frequency = 0, launch_frequency = launch_dates,
    leading_period = leading_period)
}


###############################################################################
### Gas I/O

###############################################################################
### Gas I/O

#' Load DCo gas csv file into an R39Toolbox-compatible dataframe
#'
#' @param file Path to the file to be read
#' @param required_columns Columns that must be in the dataset
#' @param tz timezone to consider
#' @param ts timestamp to consider
#'
#' @return Dataset ready to be used with R39Toolbox
#'
#' @export
read_dco_gas_data <- function(file, required_columns = NULL) {
  col_date_name <- "TDATE"
  data <- read.table(file, sep = ';', header = TRUE, dec = ',')
  # date conversion)
  data$date <- as.POSIXct(
    strftime(
      as.POSIXct(data[[col_date_name]], format = "%d/%m/%Y %H:%M", tz = 'CET'),
      format = "%d/%m/20%y %H:%M", tz = 'CET'),
    format = "%d/%m/%Y %H:%M", tz = 'CET')

  # check for required columns
  R39Toolbox::check_data(data, required_columns)
  data <- unique(data)
  data <- data[!is.na(data$date), ]

  data[, c('date', colnames(data)[2:(ncol(data) - 1)])]
}

#' Write a DCO gas R39Toolbox-compatible dataframe into a csv file
#'
#' @param data Data to be written to a csv file
#' @param file Path to the file to be written
#' @param tz timezone to consider
#'
#' @export
write_dco_gas_data <- function(data, file) {
  # format and rename column containing dates
  data$date <- strftime(data$date, format = "%d/%m/%Y 00:00", tz = 'CET')
  names_tmp <- colnames(data)
  names_tmp[names_tmp == 'date'] <- 'TDATE'
  colnames(data) <- names_tmp

  # write file
  write.table(data, file = file, sep = ';', dec = ',',
              quote = FALSE, row.names = FALSE, col.names = TRUE)
}
