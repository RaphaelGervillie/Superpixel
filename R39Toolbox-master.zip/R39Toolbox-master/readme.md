# R39Toolbox : Boite à outils pour la prévision de consommation

## Présentation du package

### Description

_R39Toolbox_ est un package R qui
regroupe un ensemble de fonctions utiles pour la prévision de
consommation, en particulier dans le respect des usages identifiés au
sein du groupe R39. Les fonctions en questions sont essentiellement
des fonctions de manipulations de données ou des fonctions
d'entrées/sorties. Les algorithmes statistiques utilisés pour
l'estimation de modèles font en général l'objet de packages
spécifiques.

### Installation

Copier l'archive "R39Toolbox_xxx.zip" sur le disque local (version
"xxx" du package) et taper la commande suivante dans RStudio :

```r
install.packages("C:\\repertoire_contenant_larchive\\R39Toolbox_xxx.zip", repos = NULL)
```
### Documentation

On peut accéder à la documentation
d'une fonction en particulier en faisant précéder le nom de la
fonction en question d'un point d'interrogation ("?"). Pour une
utilisation des fonctions "en contexte", on se réfèrera aux vignettes
consultables dans la documentation en ligne du package.


## Vie du package

### Motivations et objectifs

L'équipe de développeurs s'efforce de
limiter les fonctionnalités exposées afin de garantir que l'expert ne
trouvera dans le package que les fonctions qui recouvrent exactement
ses besoins. L'objectif est que les calages de modèles réalisés par le
groupe R39 puissent être réduits chacun à un seul script comportant un
petit nombre de lignes, lequelles seraient intégralement des appels
aux fonctions de R39Toolbox. Les études pourraient aussi beaucoup
reposer sur le package, mais seraient par nature complétées par des
traitements innovants... qui seraient à terme intégrés dans un des
packages du groupe.

### Contribuer

Le code source de R39Toolbox est hébergé sur un serveur _Git_. Ainsi,
en plus de bénéficier d'une historisation de toutes ses évolutions, le
code peut être consulté, commenté et comparé via une interface
spécifique appelée _Gitlab_. Tout utilisateur peut facilement suggérer
des modifications, voire les implémenter directement.

Le système d'_issues_ permet de reporter des problèmes rencontrés à
l'utilisation du code et d'appeler à une solution qui sera étudiée par
un développeur du projet.

Le système de _merge request_ permet de soumettre des modifications du
code à la relecture pour approbation par l'équipe de développeurs.

Raphaël et Virgile sont à votre
disposition pour tout renseignement à propos du Gitlab et de son
utilisation.
