suppressWarnings(suppressMessages(library(testthat)))
suppressWarnings(suppressMessages(library(R39Toolbox)))
suppressWarnings(suppressMessages(library(mgcv)))
suppressWarnings(suppressMessages(library(timeDate)))

test_check("R39Toolbox")
