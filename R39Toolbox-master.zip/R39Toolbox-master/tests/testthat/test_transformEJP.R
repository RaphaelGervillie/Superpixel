context("transform_EJP tests")

date <- seq(as.Date("2010-10-10"), as.Date("2010-12-31"), "days")
data <- data.frame(date = date, 
                   NORD = round(runif(length(date))), 
                   round(runif(length(date))), 
                   NORD_NON_BINAIRE = c(1:83))


test_that("transform_EJP tz & ts", {
  tz <- c("UTC", "CET", "GMT")
  ts <- c(10 * 60, 60 * 60)
  test <- expand.grid(tz, ts)

  ctrl <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]
    res <- transform_EJP(data = data, tz = tz, ts = ts)
    expect_equal(seq.POSIXt(from = as.POSIXct("2010-10-10 00:00:00", tz = tz),
                            to   = as.POSIXct("2010-12-31 23:50:00", tz = tz),
                            by   = ts), res$date)

    if (tz == "CET") {
      cet24 <- transform_EJP(data = data, tz = "CET24", ts = ts)
      data_cet_24 <- to_cet24(res, 1)
      expect_equivalent(cet24, data_cet_24)
    }
  })
})

test_that("transform_EJP NORD values", {
  tz   <- c("UTC", "CET", "GMT")
  ts   <- c(10 * 60, 60 * 60)
  test <- expand.grid(tz, ts)
  
  ctrl <- sapply(1:nrow(test), function(x) {
    tzone  <- as.character( test[x, 1] )
    tstamp <- test[x, 2]
    res    <- transform_EJP(data = data, tz = tzone, ts = tstamp)
    
    ### TEST
    #  extraire les points 6h
    #  double tests : un pour les valeurs binaires (0 et 1), 
    #                 un pour les valeurs non binaires 
    #  valeur a inserer
    values_bool<- as.integer(data$NORD)  
    values_int <- as.integer(data$NORD_NON_BINAIRE)
    
    vector_bool    <- vector_int <- rep(0, nrow(res))  # vecteur resulat
    
    time_6h <- strftime(res$date, format = "%H:%M", tz = tzone)
    values_6h <- which(time_6h == "06:00")
    #eviter la disjonction de cas
    values_6h[length(values_6h) + 1] <- length(vector_bool)
    
    for( i in 1:length(values_bool) ) {
      vector_bool[values_6h[i]:values_6h[i + 1]] <- values_bool[i]
      vector_int[values_6h[i]:values_6h[i + 1]]  <- values_int[i]
    }
    
    expect_equal(vector_bool, res$NORD)
    expect_equal(vector_int, res$NORD_NON_BINAIRE)
  })
})



test_that("generate_tarif", {
  tz <- c("UTC", "CET", "GMT", "CET24")
  ts <- c(10 * 60, 60 * 60, 120 * 60, 180 * 60)
  test <- expand.grid(tz, ts)
  ctrl <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]

    calendar <- R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", tz = tz, ts = ts)
    if (tz != 'CET24') {
      day_ref <- which(
        calendar$date == as.POSIXct("2010-01-27 06:00:00",
                                    format = "%Y-%m-%d %H:%M:%S", tz = tz))
    } else {
      day_ref <- which(calendar$date == "2010-01-27 06:00:00")
    }
    calendar <- cbind(
      calendar, R39Toolbox::generate_tarif(calendar, type = c('EJP')))
    expect_equal(calendar$EJPNord[[day_ref]], 0)  # EJP starts at 7am
    expect_equal(calendar$EJPNord[[day_ref + 6]], 1)  # "+6" to be sure that the tarif has started

    if (tz != 'CET24') {
      day_ref <- which(
        calendar$date == as.POSIXct("2010-01-26 06:00:00",
                                    format = "%Y-%m-%d %H:%M:%S", tz = tz))
    } else {
      day_ref <- which(calendar$date == "2010-01-26 06:00:00")
    }
    calendar <- cbind(
      calendar, R39Toolbox::generate_tarif(
        calendar, type = c('Tempo'),
        hour_begin = '06:00:00', hour_end = '05:30:00'))
    expect_equal(calendar$TempoRouge[[day_ref]], 1)  # Tempo starts at 6am
    expect_equal(calendar$TempoRouge[[day_ref - 1]], 0)  # Tempo should not start before 6am
  })

  # In case of a daily dataset, no hour is shown because the POSIXct library
  # hides it when it corresponds to the midnight point.
  # We adopt the convention tha the special tarif variables corresponds to
  # the midnight point, eventhough the latter is not explicitely shown.
  # An alternative would have been to consider that for a daily dataset,
  # the special tarif information indicates whether a given day is globally
  # a special tarif day, although the actual tarif does not start at midnight.
  tz <- c("UTC", "CET", "GMT", "CET24")
  ts <- 24 * 60 * 60
  test <- expand.grid(tz)
  ctrl <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])

    calendar <- R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", tz = tz, ts = ts)
    if (tz != 'CET24') {
      day_ref <- which(
        calendar$date == as.POSIXct("2010-01-27",
                                    format = "%Y-%m-%d", tz = tz))
    } else {
      day_ref <- which(calendar$date == "2010-01-27 00:00:00")
    }
    calendar <- cbind(
      calendar, R39Toolbox::generate_tarif(calendar, type = c('EJP')))
    expect_equal(calendar$EJPNord[[day_ref]], 0)  # no tarif at midnight
    expect_equal(calendar$EJPNord[[day_ref + 1]], 1)  # tarif ativated on the 28th at midnight

    if (tz != 'CET24') {
      day_ref <- which(
        calendar$date == as.POSIXct("2010-01-26",
                                format = "%Y-%m-%d", tz = tz))
    } else {
      day_ref <- which(calendar$date == "2010-01-26 00:00:00")
    }
    calendar <- cbind(
      calendar, R39Toolbox::generate_tarif(
        calendar, type = c('Tempo'),
        hour_begin = '06:00:00', hour_end = '05:30:00'))
    expect_equal(calendar$TempoRouge[[day_ref]], 0)  # no tarif at midnight
    expect_equal(calendar$TempoRouge[[day_ref + 1]], 1)  # tarif ativated on the 27th at midnight
  })
})


# Deprecation tests
test_that("createTarifVariable is still OK", {
  calendar <- R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", tz = 'UTC', ts = 10 * 60)
  expect_warning(R39Toolbox::createTarifVariable(calendar, , type = c('EJP')))
})
