##########################
# Mixture models
##########################
context("Mixture models tests")

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]
data_cut2 <- data_cut[1:(nrow(data_cut) - 60), ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL

# Init/fit/predict model
test_that("Mixture models", {
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_aux <- model_mid_term1
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)

  # Mixture
  model_mix <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso')
  expect_true("MixtureModel" %in% class(model_mix))

  # fit
  suppressWarnings(
    model1 <- R39Toolbox::fit(model_mix, data))
  expect_true("MixtureModel" %in% class(model1))
  expect_true(!is.null(model1$model_list[[1]]$model_))
  model_aux <- R39Toolbox::fit(model_aux, data)
  expect_true(!is.null(model1$model_))
  expect_equal(model1$model_list[[1]]$model_$coefficients,
               model_aux$model_$coefficients)

  # Forecast
  # Fixed-weights (predict)
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  simulation1 <- R39Toolbox::simulate(
    model1, data, update_frequency = 0, launch_frequency = 10000000)
  expect_equal(simulation1, prediction1)

  # rmse
  score1 <- R39Toolbox::score(model1, data, data$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})


# fit and predict a mixture model with weights
test_that("Mixture models with weights", {
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_aux <- model_mid_term1
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data_cut)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data_cut)
  model1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso')
  expect_true("MixtureModel" %in% class(model1))

  # fit
  suppressWarnings(
    model1_cut <- R39Toolbox::fit(model1, data_cut))
  suppressWarnings(
    model1_weights <- R39Toolbox::fit(model1, data, weights = weights))
  expect_true("MixtureModel" %in% class(model1_cut))
  expect_true(!is.null(model1_cut$model_list[[1]]$model_))
  expect_true("MixtureModel" %in% class(model1_weights))
  expect_true(!is.null(model1_weights$model_list[[1]]$model_))
  expect_equal(model1_cut$weights_, model1_weights$weights_,
               tolerance = 1e-5)
  model1 <- model1_cut

  suppressWarnings(
    model_aux <- R39Toolbox::fit(model_aux, data_cut))
  expect_true(!is.null(model1$model_))
  expect_equal(model1$model_list[[1]]$model_$coefficients,
               model_aux$model_$coefficients)

  # forecast
  prediction1_cut     <- predict(model1, data_cut)
  prediction1_weights <- predict(model1, data, leading_period = 1 - weights)
  expect_equal(length(prediction1_cut), length(data_cut$conso))
  expect_equal(class(prediction1_cut), "numeric")
  # expect_equal(?, ?)  # check weights
})


# Mixture model "by factor"
test_that("Mixture models by Instant", {
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso',
    fit_default = list(by = 'Instant'))
  expect_true("MixtureModel" %in% class(model1))

  # fit
  suppressWarnings(
    model1 <- R39Toolbox::fit(model1, data))
  expect_true("MixtureModel" %in% class(model1))
  expect_true(!is.null(model1$model_list[[1]]$model_))
  expect_true(!is.null(model1$model_))

  # forecast
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
})


# Mixture model with transform
test_that("Mixture model with transform", {
  # init
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_aux <- model_mid_term1
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso',
    transformation_function = transformation_function)
  expect_true("MixtureModel" %in% class(model1))

  # fit
  suppressWarnings(
    model1 <- R39Toolbox::fit(model1, data_cut_alt))
  expect_true("MixtureModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  # predict
  prediction1 <- predict(model1, data_alt)
  expect_equal(length(prediction1), length(data_alt$conso))
  expect_equal(class(prediction1), "numeric")
})


# Test mixture with precomputed experts
test_that("Mixture models with precomputed experts", {
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_aux <- model_mid_term1
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)

  # Mixture
  model_mix <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso',
    fit_default = list(by = "Instant"))
  expect_true("MixtureModel" %in% class(model_mix))

  # fit
  suppressWarnings(
    model1 <- R39Toolbox::fit(model_mix, data))
  data_experts <- as.data.frame(sapply(
    model_mix$model_list, predict,
    data, bypass_transform = TRUE))
  suppressWarnings(
    model1_1 <- R39Toolbox::fit(
      model_mix, data,
      precomputed_experts = data_experts))

  # Forecast
  prediction1   <- predict(model1, data)
  prediction1_1 <- predict(model1_1, data, precomputed_experts = data_experts)
  expect_equal(prediction1, prediction1_1)
})


# Mixture model with history
test_that("Mixture model with history", {
  # init
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso')

  # fit
  suppressWarnings(model1 <- R39Toolbox::fit(model1, data_cut2, hist = TRUE))
  suppressWarnings(model1 <- R39Toolbox::fit(model1, data_cut, hist = TRUE))
  expect_true("MixtureModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  # predict
  prediction1 <- predict(model1, data)
  prediction_mid_term1 <- predict(model_mid_term1, data)
  prediction_mid_term2 <- predict(model_mid_term2, data)
  expect_equal(
    prediction1,
    model1$model_$coefficients[1] * prediction_mid_term1 +
      model1$model_$coefficients[2] * prediction_mid_term2)

  # predict as past date
  prediction2 <- predict(
    model1, data,
    predict_as_date = tail(data$date, 10)[[1]])
  expect_equal(
    prediction2,
    model1$history[[1]]$weights[1] * prediction_mid_term1 +
      model1$history[[1]]$weights[2] * prediction_mid_term2)

})

# Test mixture with shifted experts
test_that("Mixture models with shifted experts", {
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_aux <- model_mid_term1
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)

  # Mixture
  model_mix <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term1,
         model_mid_term2, model_mid_term2), 'conso',
    fit_default = list(by = "Instant"),
    expert_corrections = c(1, 2, 1, 2),
    expert_corrections_type = "multiplicative")
  model_mix_1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term1,
         model_mid_term2, model_mid_term2), 'conso',
    fit_default = list(by = "Instant"))
  expect_true("MixtureModel" %in% class(model_mix))

  # fit
  suppressWarnings(
    model1 <- R39Toolbox::fit(model_mix, data))
  data_experts <- as.data.frame(sapply(
    model_mix$model_list, predict,
    data, bypass_transform = TRUE))
  data_experts[, 2] <- data_experts[, 2] * 2
  data_experts[, 4] <- data_experts[, 4] * 2
  suppressWarnings(
    model1_1 <- R39Toolbox::fit(
      model_mix_1, data,
      precomputed_experts = data_experts,
      bypass_transform = TRUE))

  # Forecast
  prediction1   <- predict(model1, data)
  prediction1_1 <- predict(model1_1, data, precomputed_experts = data_experts)
  expect_equal(prediction1, prediction1_1)
})
