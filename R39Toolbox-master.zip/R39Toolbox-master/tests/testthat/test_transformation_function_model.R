context("Transformation function")

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL

#data which will be used to compare the results of the transformation function
dataVerif <- data_cut_alt
dataVerif$Temperature <- data_cut_alt$Temperature2
dataVerif$Temperature2 <- NULL

context("Linear model data transformation function tests")

test_that("Linear model with transform", {
  model1 <- R39Toolbox::LinearModel(
    formula = "conso ~ Temperature + Posan",
    transformation_function = transformation_function)
  #test if transformation functions is correctly attached
  expect_false(is.null(model1$transformation_function))
  #test if transformation function worked
  expect_identical(dataVerif, model1$transformation_function(data_cut_alt))
})

context("GAM model data transformation function tests")

test_that("GAM model with transform", {
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan",
    transformation_function = transformation_function)
  #test if transformation functions is correctly attached
  expect_false(is.null(model1$transformation_function))
  #test if transformation function worked
  expect_identical(dataVerif, model1$transformation_function(data_cut_alt))
})

context("GBM model data transformation function tests")

test_that("GBM models with transform", {
  model1 <- R39Toolbox::GradientBoostingModel(
    target_variable = 'conso',
    explanatory_variables = c('Temperature', 'Posan'), 
    transformation_function = transformation_function)
  #test if transformation functions is correctly attached
  expect_false(is.null(model1$transformation_function))
  #test if transformation function worked
  expect_identical(dataVerif, model1$transformation_function(data_cut_alt))
})

#argument transformation_function non utilisé
#context("RF model data transformation function tests")
#
#test_that("RF models with transform", {
#  model1 <- R39Toolbox::RandomForestModel(
#    formula = "conso ~ Temperature + Posan", 
#    transformation_function = transformation_function)
#  #test if transformation functions is correctly attached
#  expect_false(is.null(model1$transformation_function))
#  #test if transformation function worked
#  expect_identical(dataVerif, model1$transformation_function(data_cut_alt))
#  
#
#})

context("Autoregressive model data transformation function tests")

test_that("Autoregressive models with transform", {
  model1 <- R39Toolbox::AutoRegressiveModel(target_variable = 'conso',
                                            transformation_function = 
                                              transformation_function)
  #test if transformation functions is correctly attached
  expect_false(is.null(model1$transformation_function))
  #test if transformation function worked
  expect_identical(dataVerif, model1$transformation_function(data_cut_alt))
})

context("Composite model data transformation tests")

test_that("Composite models", {
  model1 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan",
                                    fit_default = list(by = 'Instant'))
  model2 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature",
                                    fit_default = list(by = 'Instant'))
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1), 
    transformation_function = transformation_function)
  #test if transformation functions is correctly attached
  expect_false(is.null(model$transformation_function))
  #test if transformation function worked
  expect_identical(dataVerif, model$transformation_function(data_cut_alt))
})
