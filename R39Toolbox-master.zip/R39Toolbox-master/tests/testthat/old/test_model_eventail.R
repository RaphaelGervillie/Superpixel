data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL


##########################
# Eventail Model (mid-term)
##########################
context("Eventail model tests")

# TODO : how to test the effect of the 'weights' argument in 'fit' ?
test_that("Eventail models", {
  model1 <- R39Toolbox::EventailModel(
    col_load = 'conso',
    col_temperature = 'Temperature')
  expect_true("EventailModel" %in% class(model1))

  expect_warning(model1 <- R39Toolbox::fit(model1, data))
  expect_true("EventailModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  expect_warning(prediction1 <- predict(model1, data))
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")

  # rmse
  expect_warning(score1 <- R39Toolbox::score(model1, data, data$conso))
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  # mape
  expect_warning(score2 <- R39Toolbox::score(model1, data, data$conso,
                                             type = R39Toolbox::mape))
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})

test_that("Eventail models and smoothing/weights", {
  # create data with dummy load on the smoothing period
  data_eventail <- data
  data_eventail$conso[weights == 0] <- 0

  # a model fit using weights should not be biased too much
  # whereas a model fit on the dummy data without weights should be
  model1 <- R39Toolbox::EventailModel(
    col_load = 'conso',
    col_temperature = 'Temperature')
  expect_warning(
    model1_1 <- R39Toolbox::fit(model1, data_eventail))
  expect_warning(
    model1 <- R39Toolbox::fit(model1, data_eventail, weights = weights))

  # rmse
  expect_warning(score1   <- R39Toolbox::score(model1, data, data$conso))
  expect_warning(score1_1 <- R39Toolbox::score(model1_1, data, data$conso))
  expect_lt(score1, score1_1 - 100)  # drop of more than 100MW
})

test_that("Eventail models by factor", {
  model1 <- R39Toolbox::EventailModel(
    col_load = 'conso',
    col_temperature = 'Temperature')
  expect_true("EventailModel" %in% class(model1))

  expect_warning(model1 <- R39Toolbox::fit(model1, data, by = 'Instant'))
  expect_true("EventailModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  expect_warning(prediction1 <- predict(model1, data))
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")

  # rmse
  expect_warning(score1 <- R39Toolbox::score(model1, data, data$conso))
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  # mape
  expect_warning(score2 <- R39Toolbox::score(model1, data, data$conso,
                                             type = R39Toolbox::mape))
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})

test_that("Eventail models algorithm n_iter parameter", {
  # change n_iter directly in the call to 'fit'
  model1 <- R39Toolbox::EventailModel(
    col_load = 'conso',
    col_temperature = 'Temperature')
  expect_warning(model1 <- R39Toolbox::fit(model1, data, n_iter = 10))
  expect_equal(model1$n_iter_, 10)

  # change n_iter using default values
  model2 <- R39Toolbox::EventailModel(
    col_load = 'conso',
    col_temperature = 'Temperature',
    fit_default = list(n_iter = 10))

  expect_warning(model2 <- R39Toolbox::fit(model2, data))
  expect_equal(model2$n_iter_, 10)
  # check precedence of fit arguments over defaults
  expect_warning(model2 <- R39Toolbox::fit(model2, data, n_iter = 12))
  expect_equal(model2$n_iter_, 12)
})

## ##########################
## # Eventail Model (short-term)
## ##########################
## context("Eventail (short-term) model tests")

## test_that("Eventail ST models", {
##   model_mid_term <- R39Toolbox::EventailModel(
##     col_load = 'conso', col_temperature = 'Temperature',
##     col_daytype = 'TypeJour7', col_daytype_st = 'TypeJour7')
##   model_aux <- R39Toolbox::fit(model_mid_term, data)
##   model1 <- R39Toolbox::EventailShortTermModel(model_mid_term, 'conso')
##   model2 <- R39Toolbox::EventailShortTermModel(
##     model_mid_term, 'conso', predict.default = list(mode = 'fixed'))
##   expect_true("EventailShortTermModel" %in% class(model1))

##   # fit
##   model1 <- R39Toolbox::fit(model1, data)
##   model2 <- R39Toolbox::fit(model2, data)
##   expect_true("EventailShortTermModel" %in% class(model1))
##   expect_true(!is.null(model1$mid.term.model$model_))
##   expect_equal(model_aux$parameters_opt_,
##                model1$mid.term.model$parameters_opt_)
##   expect_true(!is.null(model1$model_))
##   expect_equal(dim(model1$parameters_opt_$Coeffs)[[1]],
##                max(as.numeric(as.character(data$TypeJour7)))
##                - min(as.numeric(as.character(data$TypeJour7))) + 1)

##   # online (default) mode
##   prediction1 <- predict(model1, data)
##   expect_equal(length(prediction1), length(data$conso))
##   expect_equal(class(prediction1), "numeric")
##   # fixed mode
##   prediction21 <- predict(model1, data, mode = 'fixed')
##   prediction22 <- predict(model2, data)
##   expect_equal(length(prediction21), length(data$conso))
##   expect_equal(class(prediction21), "numeric")
##   expect_equal(length(prediction22), length(data$conso))
##   expect_equal(class(prediction22), "numeric")
##   expect_equal(prediction21, prediction22)

##   # rmse
##   score1 <- R39Toolbox::score(model1, data, data$conso)
##   expect_equal(class(score1), "numeric")
##   expect_equal(length(score1), 1)
##   score2 <- R39Toolbox::score(model2, data, data$conso)
##   expect_lt(score1, score2)  # online (model1) should be better
##   # mape
##   score2 <- R39Toolbox::score(model1, data, data$conso,
##                               type = R39Toolbox::mape)
##   expect_equal(class(score2), "numeric")
##   expect_equal(length(score2), 1)
## })

## test_that("Eventail ST models by.day.type parameter", {
##   model_mid_term <- R39Toolbox::EventailModel(
##     col_load = 'conso', col_temperature = 'Temperature',
##     col_daytype = 'TypeJour7', col_daytype_st = 'TypeJour7')
##   model_aux <- R39Toolbox::fit(model_mid_term, data)
##   model1 <- R39Toolbox::EventailShortTermModel(
##     model_mid_term, 'conso', by.day.type = 0)
##   expect_true("EventailShortTermModel" %in% class(model1))

##   # fit
##   model1 <- R39Toolbox::fit(model1, data)
##   expect_true("EventailShortTermModel" %in% class(model1))
##   expect_true(!is.null(model1$mid.term.model$model_))
##   expect_equal(model_aux$parameters_opt_,
##                model1$mid.term.model$parameters_opt_)
##   expect_true(!is.null(model1$model_))
##   expect_equal(dim(model1$parameters_opt_$Coeffs)[[1]], 1)

##   # prediction
##   prediction1 <- predict(model1, data)
##   expect_equal(length(prediction1), length(data$conso))
##   expect_equal(class(prediction1), "numeric")

## })
