##########################
# LightGBM Model
##########################
context("LightGBM Model tests")

skip_if_no_lightgbm <- function() {
  if (!require(lightgbm)) {
    skip("'lightgbm' package not available.")
  }
}

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
train_test_split <- floor(nrow(data) * 0.8)
train <- data[1:train_test_split, ]
test <- data[(1 + train_test_split):nrow(data), ]

test_that("LightGBM Model - without early stopping ", {
  skip_if_no_lightgbm()
  # test run initialization
  
  # init
  model <- R39Toolbox::LightGBMModel(
    target_variable = "conso",
    nrounds = 200)
  
  # fit
  train_lgb <- train[, -1]
  model <- R39Toolbox::fit(model, train_lgb)
  
  # predict
  test_lgb <- test[, -1]
  prediction <- predict(model, test_lgb)
  expect_equal(length(prediction), length(test$conso))
})

test_that("LightGBM Model - with save ", {
  skip_if_no_lightgbm()
  # test run initialization
  
  # init
  model <- R39Toolbox::LightGBMModel(
    target_variable = "conso",
    nrounds = 200)
  
  # fit
  train_lgb <- train[, -1]
  model <- R39Toolbox::fit(model, train_lgb, 
                           save_path = getwd())
  
  # predict
  test_lgb <- test[, -1]
  prediction <- predict(model, test_lgb)
  expect_equal(length(prediction), length(test$conso))
})

test_that("LightGBM Model - with early stopping ", {
  skip_if_no_lightgbm()  
  # init
  model <- R39Toolbox::LightGBMModel(
    target_variable = "conso",
    nrounds = 200, early_stopping_rounds = 5L)
  
  # fit
  train_lgb <- train[, -1]
  valid_lgb <- train_lgb[sample.int(nrow(train_lgb), 100), ]
  model <- R39Toolbox::fit(model, data_train = train_lgb, 
                           data_valid = valid_lgb)
  
  # predict
  test_lgb <- test[, -1]
  prediction <- predict(model, test_lgb)
  expect_equal(length(prediction), length(test$conso))
})

test_that("LightGBM Model by instant, initialized by data set", {
  skip_if_no_lightgbm()
  # init
  model1 <- R39Toolbox::LightGBMModel(
    target_variable = "conso",
    fit_default = list(by = 'Instant'))
  
  model2 <- R39Toolbox::LightGBMModel(
    target_variable = "conso",
    nrounds = 200,
    fit_default = list(by = 'Instant'))
  
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))
  
  # fit
  data_tmp <- train[, -c(1, 5)]
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(train$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  data_tmp$Instant <- train$Instant
  model <- R39Toolbox::fit(model, data_tmp)
  
  # fit sub-models separately
  train_lgb <- train[, -c(1, 5)]
  train_lgb$Instant <- train$Instant
  model1 <- R39Toolbox::fit(
    model1, train_lgb[as.numeric(train$Instant) >= 10, ])
  model2 <- R39Toolbox::fit(
    model2, train_lgb[as.numeric(train$Instant) < 10, ])
  
  # predict
  data_tmp <- test[, -c(1, 5)]
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(test$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  data_tmp$Instant <- test$Instant
  prediction <- predict(model, data_tmp)
  
  expect_equal(length(prediction), length(data_tmp$conso))
  
  # predict sub-models separately
  test_lgb <- test[, -c(1, 5)] 
  test_lgb$Instant <- test$Instant 
  expect_true(
    all(prediction[as.numeric(test$Instant) >= 10] ==
          predict(model1, test_lgb[as.numeric(test$Instant) >= 10, ])))
  expect_true(
    all(prediction[as.numeric(test$Instant) < 10] ==
          predict(model2, test_lgb[as.numeric(test$Instant) < 10, ])))
})
