context("DOAAT tests")

test_that("DayType DOAAT", {
  # Friday, January, 1st 2016
  date_begin <- "2016-01-01"
  date_end   <- "2016-01-02"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"))
  # error case: no date representation specified
  expect_error(R39Toolbox::generate_daytype_DOAAT_CT(data))
  # with convention == 'begin'
  data <- R39Toolbox::set_date_convention(data, convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 5x48, 6x48
  expect_equal(day_type, c(rep(5, 48), rep(6, 48)))
  # with "convention == 'end'"
  data <- R39Toolbox::set_date_convention(data, convention = 'end')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  expect_equal(day_type, c(rep(5, 48), rep(6, 48)))

  # Sunday, December, 27th 2015
  date <- "2015-12-27"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"),
    convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 8
  expect_equal(day_type, rep(8, 48))
  # with "convention == 'end'"
  data <- R39Toolbox::set_date_convention(data, convention = 'end')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  expect_equal(day_type, rep(8, 48))

  # Sunday, July, 19th 2015
  date <- "2015-07-19"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 7
  expect_equal(day_type, rep(7, 48))
  # with "convention == 'end'"
  data <- R39Toolbox::set_date_convention(data, convention = 'end')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  expect_equal(day_type, rep(7, 48))

  ### Date format compatibility ----------------------------
  # Friday, January, 1st 2016
  # UTC
  date <- "2016-01-01"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date"), convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 5/6
  expect_equal(day_type, c(rep(5, 46), rep(6, 2)))
  # CET
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date"), convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 5
  expect_equal(day_type, rep(5, 48))

  # Sunday, July, 19th 2015
  # UTC
  date <- "2015-07-19"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date"), convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 7
  expect_equal(day_type, c(rep(7, 44), rep(1, 4)))
  # CET
  date <- "2015-07-19"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date"), convention = 'begin')
  day_type <- R39Toolbox::generate_daytype_DOAAT_CT(data)
  # expected daytype: 7
  expect_equal(day_type, rep(7, 48))
})


test_that("Offset DOAAT", {
  ### test offset change (0 to 1) ---------------------------
  # Sunday, March, 29th 2015
  date <- "2015-03-29"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  offset <- R39Toolbox::generate_offset_DOAAT(data)
  # summer daylight saving time switch
  expect_equal(offset, c(rep(0, 6), rep(1, 42)))

  ### test offset change (1 to 2) ---------------------------
  # August 31st and September 1st
  date_debut <- "2015-08-31"
  date_fin   <- "2015-09-01"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"),
    convention = 'end')
  offset <- R39Toolbox::generate_offset_DOAAT(data)
  # change on September, 1st
  expect_equal(offset, c(rep(1, 48), rep(2, 48)))

  ### test offset change (2 to 0) ---------------------------
  # Sunday, October, 25th 2015
  date <- "2015-10-25"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'end')
  offset <- R39Toolbox::generate_offset_DOAAT(data)
  # winter daylight saving time switch
  expect_equal(offset, c(rep(2, 4), rep(0, 44)))

  ### Date format compatibility ----------------------------
  # We consider that the reference is CET24, that is DOAAT's date format.
  # If we pass a dataset with another date format, say, corresponding to
  # another country, we still get the offset *as DOAAT gets it* in the
  # meanwhile. At each time point, we have the value of the offset as seen by
  # DOAAT at the exact same universal time.
  # Sunday, March, 29th 2015
  # UTC
  date <- "2015-03-29"
  data_utc <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date"),
    convention = 'begin')
  offset_utc <- R39Toolbox::generate_offset_DOAAT(data_utc)
  # summer daylight saving time switch
  expect_equal(offset_utc, c(rep(0, 2), rep(1, 46)))
  # CET
  date <- "2015-03-29"
  data_cet <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date"), convention = 'begin')
  offset_cet <- R39Toolbox::generate_offset_DOAAT(data_cet)
  # summer daylight saving time switch
  expect_equal(offset_cet, c(rep(0, 4), rep(1, 42)))

  # Sunday, October, 25th 2015
  # UTC
  date <- "2015-10-25"
  data_utc <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date"), convention = 'end')
  offset_utc <- R39Toolbox::generate_offset_DOAAT(data_utc)
  # winter daylight saving time switch
  expect_equal(offset_utc, c(rep(2, 2), rep(0, 46)))
  # CET
  date_debut <- "2015-10-25"
  data_cet <- R39Toolbox::generate_calendar(
    date_begin = paste0(date, " 00:00:00"),
    date_end   = paste0(date, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date"), convention = 'end')
  offset_cet <- R39Toolbox::generate_offset_DOAAT(data_cet)
  # winter daylight saving time switch
  expect_equal(offset_cet, c(rep(2, 6), rep(0, 44)))
})


test_that("Break DOAAT", {
  ### check convention = 'begin' + CT on 2015 ---------------------------
  date_debut <- "2015-01-01"
  date_fin   <- "2015-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  data <- R39Toolbox::set_date_convention(data, convention = 'begin')
  break_doaat <- R39Toolbox::generate_break_DOAAT(
    data = data, horizon = "CT")

  expect_equal(
    break_doaat,
    c(rep(0, 48 * 4), rep(1, 27 * 48),  # January
      rep(1, 48 * 28),  # February
      rep(1, 48 * 28), rep(1, 5), rep(0, 4), rep(1, 39), rep(1, 48 * 2),  # March
      rep(1, 48 * 3), rep(0, 48 * 4), rep(1, 48 * 22), rep(0, 48),  # April
      rep(0, 48 * 2), rep(1, 48 * 4), rep(0, 48 * 3), rep(1, 48 * 3),
      rep(0, 48 * 3), rep(1, 48 * 7), rep(0, 48 * 4), rep(1, 48 * 5),  # May
      rep(1, 48 * 30),  # June
      rep(1, 48 * 12), rep(0, 48 * 3), rep(1, 48 * 12), rep(0, 48 * 4),  # July
      rep(0, 48 * 31),  # August
      rep(0, 48 * 5), rep(1, 48 * 25),  # September
      rep(1, 48 * 24), rep(1, 5), rep(0, 4), rep(1, 39), rep(1, 48 * 5),
      rep(0, 48),  # October
      rep(0, 48 * 2), rep(1, 48 * 7), rep(0, 48 * 3), rep(1, 48 * 18),  # November
      rep(1, 48 * 20), rep(0, 48 * 11)  # December
    )
  )

  ### check convention = 'end' +  MT on 2015 ---------------------------
  date_debut <- "2015-01-01"
  date_fin   <- "2015-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'end')
  break_doaat <- R39Toolbox::generate_break_DOAAT(data = data, horizon = "MT")

  expect_equal(
    break_doaat,
    c(rep(0, 48 * 4), rep(1, 27 * 48),  # January
      rep(1, 48 * 28),  # February
      rep(1, 48 * 28), rep(1, 4), rep(0, 4), rep(1, 40),
      rep(1, 48 * 2),  # March
      rep(1, 48 * 30),  # April
      rep(1, 48 * 31),  # May
      rep(1, 48 * 30),  # June
      rep(1, 48 * 27), rep(0, 48 * 4),  # July
      rep(0, 48 * 31),  # August
      rep(0, 48 * 5), rep(1, 48 * 25),  # September
      rep(1, 48 * 24), rep(1, 4), rep(0, 4), rep(1, 40),
      rep(1, 48 * 6),  # October
      rep(1, 48 * 30),  # November
      rep(1, 48 * 20), rep(0, 48 * 11)  # December
    )
  )
})

# Deprecation tests
test_that("setDateConvention is still OK", {
  date_debut <- "2015-01-01"
  date_fin   <- "2015-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  expect_warning(R39Toolbox::setDateConvention(data, convention = 'begin'))
})

test_that("create*.DOAAT is still OK", {
  date_debut <- "2015-01-01"
  date_fin   <- "2015-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  expect_warning(R39Toolbox::createDayType.DOAAT.CT(data))
  expect_warning(R39Toolbox::createOffset.DOAAT(data))
  expect_warning(R39Toolbox::createBreak.DOAAT(data))
})
