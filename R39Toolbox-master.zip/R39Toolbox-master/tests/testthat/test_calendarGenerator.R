context("generate_calendar tests")

test_that("generate_calendar ts & tz", {
  tz <- c("UTC", "CET", "CET24")
  ts <- c(10 * 60, 60 * 60)
  test <- expand.grid(tz, ts)
  ctrl <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]

    c1 <- R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", ts = ts, tz = tz)
    if (tz != "CET24") {
      date <- seq.POSIXt(as.POSIXct("2010-01-01 00:00", tz = tz),
                         as.POSIXct("2010-12-31 23:50", tz = tz), by = ts)
      expect_equal(c1$date, date)
    } else {
      date <- format.POSIXct(
        seq.POSIXt(as.POSIXct("2010-01-01 00:00", tz = "UTC"),
                   as.POSIXct("2010-12-31 23:50", tz = "UTC"), by = ts),
        "%Y-%m-%d %H:%M:%S")
      class(date) <- "CET24"
      expect_identical(c1$date, date)
    }
  })
})


test_that("generate_calendar variable", {
  tz <- c("UTC", "CET", "CET24")
  ts <- c(10 * 60, 60 * 60, 120 * 60, 180 * 60, 24 * 60 * 60)
  test <- expand.grid(tz, ts)
  ctrl <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]

    cfull <-  R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", tz = tz, ts = ts)
    # check 'Ponts' variable
    if (tz != 'CET24') {
      bridge.2010.11.12 <- which(
        cfull$date == as.POSIXct("2010-11-12", format = "%Y-%m-%d", tz = tz))
    } else {
      bridge.2010.11.12 <- which(cfull$date == "2010-11-12 00:00:00")
    }
    expect_equal(cfull$Ponts[bridge.2010.11.12], 1)

    # Variables
    ctrl <- sapply(eval(formals(generate_calendar)$variables),
                   function(var) {
                     cinter <-  R39Toolbox::generate_calendar(
                       "2010-01-01 00:00", "2010-12-31 23:50",
                       tz = tz, ts = ts, variables = var)
                     expect_equal(cinter, cfull[, var, drop = FALSE])
                   })
  })
})

# Test 'CET24' class persists after subsetting
# Fix issue #26
test_that("generate_calendar variable", {
  cal <- R39Toolbox::generate_calendar(
    '2010-01-01 00:00', '2010-01-02 00:00', tz = 'CET24', ts = 60 * 60,
    variables = c('date', 'Posan'))
  cal2 <- cal[1:10, ]
  cal3 <- subset(cal, cal$Posan < 0.2)
  expect_true('CET24' %in% class(cal$date))
  expect_true('CET24' %in% class(cal2$date))
  expect_true('CET24' %in% class(cal3$date))
})

# Test 'date.begin' and 'date.end' arguments format
# Fix issue #24 and #35
test_that("generate_calendar input dates", {
  # base case
  cal <- R39Toolbox::generate_calendar(
    '2010-01-01 00:00', '2010-01-02 00:00', tz = 'UTC', ts = 60 * 60,
    variables = c('date', 'Posan'))
  # dates without hour/minute specification
  expect_warning(
    R39Toolbox::generate_calendar(
      '2010-01-01', '2010-01-02', tz = 'UTC', ts = 60 * 60,
      variables = c('date', 'Posan')))
  expect_warning(
    cal2 <- R39Toolbox::generate_calendar(
      '2010-01-01', '2010-01-02', tz = 'UTC', ts = 60 * 60,
      variables = c('date', 'Posan')),
    regexp = "No hour found")
  expect_equal(cal$date, cal2$date)
  # dates with bad format
  expect_error(
    R39Toolbox::generate_calendar(
      '2010/01/01', '2010/01/02', tz = 'UTC', ts = 60 * 60,
      variables = c('date', 'Posan')),
    'using the following format')

  # POSIXct dates
  date.begin <- as.POSIXct("2010-01-01", tz = 'UTC')
  date.end   <- as.POSIXct("2010-01-03", tz = 'UTC')
  cal3 <- R39Toolbox::generate_calendar(
    date.begin, date.end, tz = 'UTC', ts = 60 * 60,
    variables = c('date', 'Posan'))
  # POSIXct dates with CET24 output format (issue #35)
  date.begin <- dmy_hm(010820160030, tz = "CET")
  date.end   <- dmy_hm(010920160000, tz = "CET")
  cal4 <- R39Toolbox::generate_calendar(
    date.begin, date.end, tz = 'CET24', ts = 30 * 60, variables = 'date')
  expect_equal(as.character(tail(cal4$date, 1)), "2016-09-01 00:00:00")

  # Date dates
  date.begin <- as.Date("2010-01-01")
  date.end   <- as.Date("2010-01-03")
  cal5 <- R39Toolbox::generate_calendar(
    date.begin, date.end, tz = 'UTC', ts = 60 * 60,
    variables = c('date', 'Posan'))
  expect_equal(as.character(tail(cal5$date, 1)), "2010-01-03")
})

# Fix issue #38 (Posan can go up to 2 instead of 1)
test_that("Posan is between 0 and 1", {
  date.begin <- "2016-05-02 00:00:00"
  date.end   <- "2017-05-31 00:00:00"
  ts <- 24 * 60 * 60
  tz <- 'CET'
  Variables <- c("date", "Posan")
  cal <- R39Toolbox::generate_calendar(
    date.begin, date.end, ts = ts, tz = tz, variables = Variables)

  expect_equal(max(cal$Posan), 1)
  expect_equal(min(cal$Posan), 0)
})

# Fix bug with date_begin/end provided in UTC and tz = 'UTC'
test_that("Posan is between 0 and 1", {
  date_begin <- as.POSIXct(
    "2017-01-01 00:00:00", format = "%Y-%m-%d %H:%M:%S", tz = "UTC")
  date_end   <- as.POSIXct(
    "2017-01-01 23:30:00", format = "%Y-%m-%d %H:%M:%S", tz = "UTC")
  cal <- R39Toolbox::generate_calendar(
    date_begin, date_end, ts = 30 * 60, tz = 'UTC', variables = c('Instant'))
  expect_equal(cal$Instant, 0:47)
})

### Standard temperature tests ----------------------------
context("get_standard_temperature tests")

test_that("get_standard_temperature and tz/ts", {
  tz <- c("UTC", "CET", "CET24")
  ts <- c(10 * 60, 60 * 60, 120 * 60, 180 * 60, 24 * 60 * 60)
  test <- expand.grid(tz, ts)
  sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]
    data_temp <- R39Toolbox::generate_calendar(
      "2010-01-01 00:00", "2010-12-31 23:50", tz = tz, ts = ts)
    std_temperature <- R39Toolbox::get_standard_temperature(data_temp)
    # check the output vector has the same length as the input data
    expect_equal(dim(data_temp)[[1]], length(std_temperature))
    # check we have no NAs
    expect_equal(length(which(is.na(std_temperature))), 0)
  })
})


test_that("get_standard_temperature with R39ExData", {
  # load some example data
  data <- R39Toolbox::R39ExData[1:1000, ]
  # create standard temperature variable for it
  std_temperature <- R39Toolbox::get_standard_temperature(data)
  # check the output vector has the same length as the input data
  expect_equal(dim(data)[[1]], length(std_temperature))
  # check we have no NAs
  expect_equal(length(which(is.na(std_temperature))), 0)
})


# Deprecation tests
test_that("calendarGenerator is still OK", {
  date_begin <- "2016-05-02 00:00:00"
  date_end   <- "2017-05-31 00:00:00"
  ts <- 24 * 60 * 60
  tz <- 'CET'
  variables <- c("date", "Posan")
  expect_warning(R39Toolbox::calendarGenerator(
    date_begin, date_end, ts = ts, tz = tz,
    choiceHolidays = "FR", Variables = variables, keep.last = TRUE))
})
