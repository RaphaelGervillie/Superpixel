context("Leading period")

# these tests check help checking the consistence of the model API
# focusing on the arguments that give control on fit/prediction
# periods/observations such as 'weights' and 'leading_period'.
#
# The tests are made for each kind of model.

data <- R39Toolbox::R39ExData[1:(49 + 24*7*3 - 1), ]
semaine1 <- rep(FALSE, nrow(data))
semaine2 <- rep(FALSE, nrow(data))
semaine3 <- rep(FALSE, nrow(data))
semaine1[49:(49 + 24*7 - 1)] <- TRUE
semaine2[(49 + 24*7):(49 + 24*7*2 - 1)] <- TRUE
semaine3[(49 + 24*7*2):(49 + 24*7*3 - 1)] <- TRUE
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:48] <- 0


test_that("leading_period consistency", {
  # Model initiatlisation
  # auxillary models
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  # check API robustness
  model_mid_term1 <- R39Toolbox::fit(
    model_mid_term1, data, weights = rep(1, nrow(data)))
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model_mid_term3 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7',
    fit_default = list(by = 'Instant'))
  model_mid_term3 <- R39Toolbox::fit(model_mid_term3, data)
  model_short_term1 <-  R39Toolbox::AutoRegressiveModel('conso', lags = c(1, 2))
  # final list
  all_models <- list(
    R39Toolbox::RawVariable('conso'),
    R39Toolbox::LinearModel(
      formula = "conso ~ Temperature + Posan"),
    R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan"),
    R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan",
      fit_default = list(by = 'Instant')),
    R39Toolbox::MixtureModel(
      list(model_mid_term1, model_mid_term2), 'conso'),
    R39Toolbox::MixtureModel(
      list(model_mid_term1, model_mid_term2), 'conso',
      fit_default = list(by = 'Instant')),
    R39Toolbox::AutoRegressiveModel(
      'conso', lags = c(1, 2)),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term1, model_short_term1,
      fit_default = list(by = 'Instant')),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term3, model_short_term1),
    R39Toolbox::GeneralizedAdditiveModelAdaptative(
      model_mid_term2,
      fixed_global_effect = 's(Temperature)', mu = 0.95),
    R39Toolbox::GeneralizedAdditiveModelAdaptative(
      model_mid_term2,
      fixed_global_effect = 's(Temperature)', mu = 0.95,
      fit_default = list(by = 'Instant')),
    R39Toolbox::GeneralizedAdditiveModelAdaptative(
      model_mid_term3,
      fixed_global_effect = 's(Temperature)', mu = 0.95))

  for (i in 1:length(all_models)) {
    model1 <- all_models[[i]]

    # fit
    # consistency between weights and leading_period
    silent <- capture_warning(
      model1_1 <- R39Toolbox::fit(model1, data, weights = weights))
    silent <- capture_warning(
      model1_2 <- R39Toolbox::fit(model1, data, leading_period = 1 - weights))
    silent <- capture_warning(
      model1_3 <- R39Toolbox::fit(
        model1, data, leading_period = 1 - weights, weights = weights))

    # predict
    prediction1_1_1 <- predict(model1_1, data, leading_period = as.numeric(1 - semaine3))
    prediction1_2_1 <- predict(model1_2, data, leading_period = as.numeric(1 - semaine3))
    prediction1_3_1 <- predict(model1_3, data, leading_period = as.numeric(1 - semaine3))
    if ("MidTermForecastModel" %in% class(model1_1)) {
      prediction1_1 <- predict(model1_1, data[semaine3, ])
      prediction1_2 <- predict(model1_2, data[semaine3, ])
      prediction1_3 <- predict(model1_3, data[semaine3, ])
      expect_equal(prediction1_1, prediction1_1_1)
      expect_equal(prediction1_2, prediction1_2_1)
      expect_equal(prediction1_3, prediction1_3_1)
    }

    # score
    # score1 computed directly
    # score1_1 computed using weights
    score1 <- R39Toolbox::score(
      model1_1, data[1:(49 + 24*7 - 1), ], data[1:(49 + 24*7 - 1), ]$conso,
      leading_period = (1 - weights)[1:(49 + 24*7 - 1)])
    score1_1 <- R39Toolbox::score(
      model1_1, data, data$conso,
      leading_period = 1 - weights,
      weights = as.numeric(semaine1))
    expect_equal(score1_1, score1)
  }
})
