context("DCO gas tests")

test_that("Gas process daytypes", {
  cal <- R39Toolbox::generate_calendar(
    "1908-01-01 00:00", "2020-01-01 00:00",
    ts = 24*60*60, variables = c('date'))
  cal$launch_daytype <- R39Toolbox::generate_daytypes_dco_gas_process(cal)
  expect_equal(length(unique(cal$launch_daytype)), 5)
  expect_equal(sort(as.character(unique(cal$launch_daytype))),
               c("J", "J+1", "J+2", "J+3", "J+4"))
})

test_that("Gas process daytypes for infra day data", {
  cal <- R39Toolbox::generate_calendar(
    "2019-01-01 00:00", "2019-12-31 12:00",
    ts = 12*60*60, variables = c('date'), tz = 'UTC')
  cal$launch_daytype <- R39Toolbox::generate_daytypes_dco_gas_process(cal)
  expect_equal(nrow(cal), 2 * 365)
  expect_equal(length(unique(cal$launch_daytype)), 4)
  expect_equal(sort(as.character(unique(cal$launch_daytype))),
               c("J", "J+1", "J+2", "J+3"))
})


test_that("Gas process simulation", {
  data <- R39Toolbox::generate_calendar(
    "2019-01-01 00:00:00", "2020-12-31 00:00:00",
    ts = 24 * 60 * 60, variables = c('date', 'Posan'))
  data$DayType <- R39Toolbox::generate_daytypes(data, 0:6)
  data$ConsoDummy <- 3 * as.numeric(levels(data$DayType)[data$DayType]) + 1

  data_train <- data[data$date < "2020-01-01", ]
  data_test  <- data[data$date >= "2019-12-31", ]
  leading_period <- c(1, rep(0, 366))
  data_test$ConsoDummy <- data_test$ConsoDummy + 10 * data_test$Posan

  # model mid-term
  model_gam <- R39Toolbox::GeneralizedAdditiveModel(
    "ConsoDummy ~ DayType")
  model_gam <- R39Toolbox::fit(model_gam, data_train)
  prediction_gam <- predict(model_gam, data_test, leading_period = leading_period)
  simulation_gam <- R39Toolbox::simulate_dco_gas_process(
    model_gam, data_test, leading_period = leading_period)
  expect_equal(prediction_gam, simulation_gam)
  diff_1 <- simulation_gam - data_test$ConsoDummy[2:nrow(data_test)]
  expect_equal(diff_1, - 10 * data_test$Posan[2:nrow(data_test)])

  # model readjusted
  model_ar <- R39Toolbox::AutoRegressiveModel("ConsoDummy", lags = c(1))
  model_ar$coefficients_ <- c(1)
  model_ar$model_ <- "fit->ok"
  model_readjusted <- R39Toolbox::ReadjustedModel(
    "ConsoDummy", model_gam, model_ar)
  simulation_readjusted <- simulate(
    model_readjusted, data_test, leading_period = leading_period,
    update_frequency = 0)
  diff_2 <- (simulation_readjusted[2:length(simulation_readjusted)]
    - data_test$ConsoDummy[3:nrow(data_test)])
  expect_equal(length(unique(round(diff_2, 5))), 1)
  # simulation gas process
  simulation_readjusted_gas <- simulate_dco_gas_process(
    model_readjusted, data_test, leading_period = leading_period)
  diff_3 <- (simulation_readjusted_gas[2:length(simulation_readjusted_gas)]
    - data_test$ConsoDummy[3:nrow(data_test)])
  expect_equal(length(unique(round(diff_3, 5))), 4)
})
