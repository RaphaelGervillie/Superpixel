context("Simulations (AR)")

data <- R39Toolbox::R39ExData
data$Var1 <- as.factor(as.numeric(data$Instant < 12))
data$Instant <- as.factor(data$Instant)

test_that("AR models (simulation)", {
  # Model initialisation
  # auxillary models
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model_short_term1 <-  R39Toolbox::AutoRegressiveModel(
    'conso', lags = 'auto')
  model_short_term2 <-  R39Toolbox::AutoRegressiveModel(
    'conso', lags = c(1, 2))
  all_models <- list(
    R39Toolbox::AutoRegressiveModel(
      'conso', lags = 'auto'),
    R39Toolbox::AutoRegressiveModel(
      'conso', lags = c(1, 2)),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term1, model_short_term1),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term1, model_short_term2))

  for (i in 1:length(all_models)) {
    model <- all_models[[i]]
    suppressWarnings(model1 <- R39Toolbox::fit(model, data))

    ### Fixed-weights (predict)
    suppressWarnings(
      prediction1 <- predict(
        model1, data,
        leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
    expect_equal(length(prediction1), length(data$conso) - 100)
    expect_equal(class(prediction1), "numeric")
    suppressWarnings(
      simulation1 <- R39Toolbox::simulate(
        model1, data, update_frequency = 0, launch_frequency = 10000000,
        leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
    expect_equal(simulation1, prediction1)

    ### Online mode (simulate)
    data_no_december2014 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
    data_december2014 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(
      simulation1_1 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    suppressWarnings(
      simulation1_2 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
        update_frequency = 24, launch_frequency = 24))
    #
    suppressWarnings(
      simulation1_2_2 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
        update_frequency = 24, launch_frequency = 24, horizon = 12))
    expect_true(all(is.na(simulation1_2_2[1:12])))
    expect_equal(simulation1_2_2[13:24], simulation1_2[13:24])
    expect_equal(simulation1_2_2[37:48], simulation1_2[37:48])
    #
    suppressWarnings(
      simulation1_3 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
        update_frequency = data_december2014$date[as.numeric(strftime(
          data_december2014$date, format = "%H", tz = 'UTC')) == 8],
        launch_frequency = data_december2014$date[as.numeric(strftime(
          data_december2014$date, format = "%H", tz = 'UTC')) == 8]))
    expect_equal(simulation1_2, simulation1_3)
    suppressWarnings(
      prediction1_1 <- predict(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    #
    data_no_december2014_2 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 09:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
    suppressWarnings(
      prediction1_2 <- predict(
        model1_2, data_december2014,
        leading_period = c(rep(1, 57), rep(0, nrow(data_december2014) - 57))))
    #
    data_no_december2014_3 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 10:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_3 <- R39Toolbox::fit(model, data_no_december2014_3))
    suppressWarnings(
      prediction1_3 <- predict(
        model1_3, data_december2014,
        leading_period = c(rep(1, 58), rep(0, nrow(data_december2014) - 58))))
    expect_equal(prediction1_1[[1]], simulation1_1[[1]])
    expect(prediction1_1[[2]] != simulation1_1[[2]], failure_message = "")
    expect_equal(prediction1_2[[1]], simulation1_1[[2]])
    expect_equal(prediction1_3[[1]], simulation1_1[[3]])
  }
})


test_that("AR model 'per factor'", {
  # Model initialisation
  # auxillary models
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7',
    fit_default = list(by = 'Var1'))
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model_short_term1 <-  R39Toolbox::AutoRegressiveModel(
    'conso', lags = 'auto')
  model_short_term2 <-  R39Toolbox::AutoRegressiveModel(
    'conso', lags = 'auto', fit_default = list(by = 'Var1'))
  all_models <- list(
    R39Toolbox::AutoRegressiveModel(
      'conso', lags = 'auto', fit_default = list(by = 'Var1')),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term1, model_short_term1,
      fit_default = list(by = 'Var1')),
    R39Toolbox::ReadjustedModel(
      'conso', model_mid_term1, model_short_term2))

  for (i in 1:length(all_models)) {
    model <- all_models[[i]]
    suppressWarnings(model1 <- R39Toolbox::fit(model, data))

    ### Fixed-weights (predict)
    prediction1 <- predict(
      model1, data,
      leading_period = c(rep(1, 100), rep(0, nrow(data) - 100)))
    expect_equal(length(prediction1), length(data$conso) - 100)
    expect_equal(class(prediction1), "numeric")
    suppressWarnings(
      simulation1 <- R39Toolbox::simulate(
        model1, data, update_frequency = 0,
        launch_frequency = 10000000,
        leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
    expect_equal(simulation1, prediction1)

    ### Online mode (simulate)
    data_no_december2014 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
    data_december2014 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    expect_error(R39Toolbox::simulate(model1_1, data_december2014))
    suppressWarnings(
      simulation1_1 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    suppressWarnings(
      simulation1_2 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        update_frequency = 24, launch_frequency = 24,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    #
    suppressWarnings(
      simulation1_2_2 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
        update_frequency = 24, launch_frequency = 24, horizon = 12))
    expect_true(all(is.na(simulation1_2_2[1:12])))
    expect_equal(simulation1_2_2[13:24], simulation1_2[13:24])
    expect_equal(simulation1_2_2[37:48], simulation1_2[37:48])
    #
    suppressWarnings(
      simulation1_3 <- R39Toolbox::simulate(
        model1_1, data_december2014,
        update_frequency = data_december2014$date[as.numeric(strftime(
          data_december2014$date, format = "%H", tz = 'UTC')) == 8],
        launch_frequency = data_december2014$date[as.numeric(strftime(
          data_december2014$date, format = "%H", tz = 'UTC')) == 8],
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    expect_equal(simulation1_1[[1]], simulation1_2[[1]])
    expect_equal(simulation1_2, simulation1_3)
    suppressWarnings(
      prediction1_1 <- predict(
        model1_1, data_december2014,
        leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
    #
    data_no_december2014_2 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 13:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
    data_december2014_2 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(
      prediction1_2 <- predict(
        model1_2, data_december2014_2,
        leading_period = c(rep(1, 61), rep(0, nrow(data_december2014_2) - 61))))
    #
    data_no_december2014_3 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
        data$date < as.POSIXct(
          "2014-11-26 14:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(model1_3 <- R39Toolbox::fit(model, data_no_december2014_3))
    data_december2014_3 <- data[
      data$date >= as.POSIXct(
        "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
    suppressWarnings(
      prediction1_3 <- predict(
        model1_3, data_december2014_3,
        leading_period = c(rep(1, 62), rep(0, nrow(data_december2014_3) - 62))))
    expect_equal(prediction1_1[[1]], simulation1_1[[1]])
    expect(prediction1_1[[2]] != simulation1_1[[2]], failure_message = "")
    expect_equal(prediction1_1[[2]], simulation1_2[[2]])
    expect_equal(prediction1_2[[1]], simulation1_1[[6]])
    expect(prediction1_2[[2]] != simulation1_1[[7]], failure_message = "")
    expect_equal(prediction1_3[[1]], simulation1_1[[7]])
    expect(prediction1_3[[2]] != simulation1_1[[8]], failure_message = "")
  }
})
