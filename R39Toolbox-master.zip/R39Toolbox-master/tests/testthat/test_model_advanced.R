data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL


context("Model advanced tests")

test_that("Compute neutral temperature", {
  ### col_temperature = 'Temperature'
  model <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan")
  model <- R39Toolbox::fit(model, data_cut)
  # compute neutral temperature
  neutral_temperature <- R39Toolbox::compute_neutral_temperature(
    model, data_cut, t_step = 1)
  expect_lte(neutral_temperature, 20)
  expect_gte(neutral_temperature, 14)
  # climatic part
  model <- R39Toolbox::set_neutral_temperature(model, neutral_temperature)
  climatic_part <- compute_climatic_part(model, data)
  expect_lt(sum(climatic_part), sum(predict(model, data)))

  ### col_temperature = 'Temperature2'
  model <- R39Toolbox::LinearModel(
    formula = "conso ~ Temperature + Posan",
    transformation_function = transformation_function)
  model <- R39Toolbox::fit(model, data_cut_alt)
  # compute neutral temperature
  neutral_temperature <- compute_neutral_temperature(
    model, data_cut_alt, col_temperature = 'Temperature2', t_step = 1)
  expect_lte(neutral_temperature, 20)
  expect_gte(neutral_temperature, 14)
  # climatic part
  model <- R39Toolbox::set_neutral_temperature(model, neutral_temperature)
  climatic_part <- compute_climatic_part(
    model, data_alt, col_temperature = 'Temperature2')
  expect_lt(sum(climatic_part), sum(predict(model, data_alt)))
})
