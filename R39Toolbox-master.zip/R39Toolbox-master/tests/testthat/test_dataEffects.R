context("get_model_effects tests")


require(mgcv)
model <- gam(conso ~ s(Temperature) + TypeJour7 + Posan,
             data = R39ExData[1:10000, ])


test_that("predict terms on gam model", {
  via.mgcv <- stats::predict(model, type = "terms")
  colnames(via.mgcv) <- paste0("effect.fit.", colnames(via.mgcv))
  via.mgcv <- data.frame(model$model, via.mgcv, check.names=FALSE)

  via.get_model_effect <- get_model_effects(model, type = "terms")

  expect_identical(via.mgcv, via.get_model_effect)
})


test_that("predict terms + SE on gam model", {
  via.mgcv <- data.frame(stats::predict(model, type = "terms", se.fit = TRUE),
                         check.names = FALSE)
  colnames(via.mgcv) <- paste0("effect.", colnames(via.mgcv))
  via.mgcv <- data.frame(model$model, via.mgcv, check.names = FALSE)

  via.get_model_effect <- get_model_effects(model, type = "terms", se.fit = TRUE)

  expect_identical(via.mgcv, via.get_model_effect)
})


test_that("predict ordering terms + SE on gam model", {
  data <- data.frame(model$model, check.names = FALSE)
  via.get_model_effect <- get_model_effects(
    model, type = "terms", se.fit = TRUE, ordering = TRUE)
  expect_true(is.list(via.get_model_effect))
  expect_true(length(via.get_model_effect) == 3)

  ctrl <- lapply(via.get_model_effect, function(var) {
    x <- var[, 1]
    y <- unique(sort(data[, colnames(var)[1]]))
    if (class(data[, colnames(var)[1]]) %in% c("numeric", "double")) {
      expect_true(all(x %in% y))
    } else {
      expect_equal(x, y)
    }
  })
})


test_that("predict iterms on gam model", {
  via.mgcv <- stats::predict(model, type = "iterms")
  colnames(via.mgcv) <- paste0("effect.fit.", colnames(via.mgcv))
  via.mgcv <- data.frame(model$model, via.mgcv, check.names = FALSE)

  via.get_model_effect <- get_model_effects(model, type = "iterms")

  expect_identical(via.mgcv, via.get_model_effect)
})


test_that("predict iterms + SE on gam model", {
  via.mgcv <- data.frame(stats::predict(model, type = "iterms", se.fit = TRUE),
                         check.names = FALSE)
  colnames(via.mgcv) <- paste0("effect.", colnames(via.mgcv))
  via.mgcv <- data.frame(model$model, via.mgcv, check.names = FALSE)

  via.get_model_effect <- get_model_effects(model, type = "iterms", se.fit = TRUE)

  expect_identical(via.mgcv, via.get_model_effect)
})


test_that("predict lpmatrix on gam model", {
  via.mgcv <- stats::predict(model, type = "lpmatrix")
  colnames(via.mgcv) <- paste0("effect.fit.", colnames(via.mgcv))
  via.mgcv <- data.frame(model$model, via.mgcv, check.names = FALSE)

  via.get_model_effect <- get_model_effects(model, type = "lpmatrix")

  expect_identical(via.mgcv, via.get_model_effect)
})


# Deprecation tests
test_that("dataEffects is still OK", {
  expect_warning(R39Toolbox::dataEffects(model, type = "lpmatrix"))
})
