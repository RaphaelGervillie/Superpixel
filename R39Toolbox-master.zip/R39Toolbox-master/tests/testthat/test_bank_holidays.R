#context("generate_calendar tests")

test_that("generate school break", {
  ts <- 24 * 60 * 60
  tz <- "UTC"
  date_begin <- "2016-01-01 00:00"
  date_end <- "2016-12-31 23:50"

  calendar_test <- generate_calendar(date_begin, date_end, ts, tz)


  date <- seq.POSIXt(as.POSIXct(date_begin, tz = tz),
                    as.POSIXct(date_end, tz = tz),
                    by = ts)

  #creation de jours de vacances
  tmp <- rep(FALSE, nrow(calendar_test))
  zoneA <- data.frame(date, vacance = tmp)
  zoneB <- data.frame(date, vacance = tmp)
  zoneC <- data.frame(date, vacance = tmp)
  #zone A
  #Fin des cours : samedi 19 decembre 2015/Jour de reprise : lundi 4 janvier 2016 (non inclus)
  noel_2015_start <- 1
  noel_2015_end <- which(zoneA$date == as.POSIXct("2016-01-03", tz=tz))
  #Fin des cours : samedi 13 fevrier 2016/Jour de reprise : lundi 29 fevrier 2016 (non inclus)
  hiver_2016_start <- which(zoneA$date == as.POSIXct("2016-02-14", tz=tz))
  hiver_2016_end <- which(zoneA$date == as.POSIXct("2016-02-28", tz=tz))
  #Fin des cours : samedi 9 avril 2016/Jour de reprise : lundi 25 avril 2016
  printemps_2016_start <- which(zoneA$date == as.POSIXct("2016-04-10", tz=tz))
  printemps_2016_end <- which(zoneA$date == as.POSIXct("2016-04-24", tz=tz))
  #Fin des cours : mardi 5 juillet 2016/Jour de reprise : Jeudi 1 septembre 2016
  ete_2016_start <- which(zoneA$date == as.POSIXct("2016-07-06", tz=tz))
  ete_2016_end <- which(zoneA$date == as.POSIXct("2016-08-31", tz=tz))
  #Fin des cours : mercredi 19 octobre 2016/reprise : jeudi 3 novembre 2016
  toussaint_2016_start <- which(zoneA$date == as.POSIXct("2016-10-20", tz=tz))
  toussaint_2016_end <- which(zoneA$date == as.POSIXct("2016-11-02", tz=tz))
  #Fin des cours : samedi 17 decembre 2016/Reprise : mardi 3 janvier 2017
  noel_2016_start <- which(zoneA$date == as.POSIXct("2016-12-18", tz=tz))
  noel_2016_end <- 366
  #mise a jour vecteur vacance
  index_zone_A <- c(noel_2015_start,
            noel_2015_end,
            hiver_2016_start,
            hiver_2016_end,
            printemps_2016_start,
            printemps_2016_end,
            ete_2016_start,
            ete_2016_end,
            toussaint_2016_start,
            toussaint_2016_end,
            noel_2016_start,
            noel_2016_end)

  #Zone B
  #Fin des cours : samedi 19 decembre 2015/Jour de reprise : lundi 4 janvier 2016
  noel_2015_start <- 1
  noel_2015_end <- which(zoneA$date == as.POSIXct("2016-01-03", tz=tz))
  #Fin des cours : samedi 6 fevrier 2016/Jour de reprise : lundi 22 fevrier 2016
  hiver_2016_start <- which(zoneA$date == as.POSIXct("2016-02-07", tz=tz))
  hiver_2016_end <- which(zoneA$date == as.POSIXct("2016-02-21", tz=tz))
  #Fin des cours : samedi 2 avril 2016/Jour de reprise : lundi 18 avril 2016
  printemps_2016_start <- which(zoneA$date == as.POSIXct("2016-04-03", tz=tz))
  printemps_2016_end <- which(zoneA$date == as.POSIXct("2016-04-17", tz=tz))
  #Fin des cours : mardi 5 juillet 2016/Jour de reprise : Jeudi 1 septembre 2016
  ete_2016_start <- which(zoneA$date == as.POSIXct("2016-07-06", tz=tz))
  ete_2016_end <- which(zoneA$date == as.POSIXct("2016-08-31", tz=tz))
  #Fin des cours : mercredi 19 octobre 2016/reprise : jeudi 3 novembre 2016
  toussaint_2016_start <- which(zoneA$date == as.POSIXct("2016-10-20", tz=tz))
  toussaint_2016_end <- which(zoneA$date == as.POSIXct("2016-11-02", tz=tz))
  #Fin des cours : samedi 17 decembre 2016/Reprise : mardi 3 janvier 2017
  noel_2016_start <- which(zoneA$date == as.POSIXct("2016-12-18", tz=tz))
  noel_2016_end <- 366
  #mise a jour vecteur vacance
  index_zone_B <- c(noel_2015_start,
                    noel_2015_end,
                    hiver_2016_start,
                    hiver_2016_end,
                    printemps_2016_start,
                    printemps_2016_end,
                    ete_2016_start,
                    ete_2016_end,
                    toussaint_2016_start,
                    toussaint_2016_end,
                    noel_2016_start,
                    noel_2016_end)

  #Zone C
  #Fin des cours : samedi 19 decembre 2015/Jour de reprise : lundi 4 janvier 2016
  noel_2015_start <- 1
  noel_2015_end <- which(zoneA$date == as.POSIXct("2016-01-03", tz=tz))
  #Fin des cours : samedi 20 fevrier 2016/Jour de reprise : lundi 07 mars 2016
  hiver_2016_start <- which(zoneA$date == as.POSIXct("2016-02-21", tz=tz))
  hiver_2016_end <- which(zoneA$date == as.POSIXct("2016-03-06", tz=tz))
  #Fin des cours : samedi 16 avril 2016/Jour de reprise : lundi 02 mai 2016
  printemps_2016_start <- which(zoneA$date == as.POSIXct("2016-04-17", tz=tz))
  printemps_2016_end <- which(zoneA$date == as.POSIXct("2016-05-01", tz=tz))
  #Fin des cours : mardi 5 juillet 2016/Jour de reprise : Jeudi 1 septembre 2016
  ete_2016_start <- which(zoneA$date == as.POSIXct("2016-07-06", tz=tz))
  ete_2016_end <- which(zoneA$date == as.POSIXct("2016-08-31", tz=tz))
  #Fin des cours : mercredi 19 octobre 2016/reprise : jeudi 3 novembre 2016
  toussaint_2016_start <- which(zoneA$date == as.POSIXct("2016-10-20", tz=tz))
  toussaint_2016_end <- which(zoneA$date == as.POSIXct("2016-11-02", tz=tz))
  #Fin des cours : samedi 17 decembre 2016/Reprise : mardi 3 janvier 2017
  noel_2016_start <- which(zoneA$date == as.POSIXct("2016-12-18", tz=tz))
  noel_2016_end <- 366
  #mise a jour vecteur vacance
  index_zone_C <- c(noel_2015_start,
                    noel_2015_end,
                    hiver_2016_start,
                    hiver_2016_end,
                    printemps_2016_start,
                    printemps_2016_end,
                    ete_2016_start,
                    ete_2016_end,
                    toussaint_2016_start,
                    toussaint_2016_end,
                    noel_2016_start,
                    noel_2016_end)

  for( i in c(1, 3, 5, 7, 9, 11)) {
      zoneA$vacance[index_zone_A[i]:index_zone_A[i+1]] <- TRUE
      zoneB$vacance[index_zone_B[i]:index_zone_B[i+1]] <- TRUE
      zoneC$vacance[index_zone_C[i]:index_zone_C[i+1]] <- TRUE
  }

  calendar_test$vacanceZoneA <- zoneA$vacance
  calendar_test$vacanceZoneB <- zoneB$vacance
  calendar_test$vacanceZoneC <- zoneC$vacance

  res_zone_A <- R39Toolbox::is_school_break(data_period = date, zone = "A")
  res_zone_B <- R39Toolbox::is_school_break(data_period = date, zone = "B")
  res_zone_C <- R39Toolbox::is_school_break(data_period = date, zone = "C")

  testthat::expect_equal(res_zone_A, calendar_test$vacanceZoneA)
  testthat::expect_equal(res_zone_B, calendar_test$vacanceZoneB)
  testthat::expect_equal(res_zone_C, calendar_test$vacanceZoneC)
})

