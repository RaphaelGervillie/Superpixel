##########################
# Composite Model
##########################
context("Composite model tests")

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL


test_that("Composite models", {
  # init
  model1 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan",
                                    fit_default = list(by = 'Instant'))
  model2 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature",
                                    fit_default = list(by = 'Instant'))
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))

  # fit
  data_tmp <- data_cut
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(data_tmp$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  model <- R39Toolbox::fit(model, data_tmp)
  # fit sub-models separately
  model1 <- R39Toolbox::fit(
    model1, data_cut[as.numeric(data_cut$Instant) >= 10, ])
  model2 <- R39Toolbox::fit(
    model2, data_cut[as.numeric(data_cut$Instant) < 10, ])

  # predict
  prediction <- predict(model, data_tmp)
  expect_equal(length(prediction), length(data_tmp$conso))
  expect_equal(class(prediction), "numeric")
  # predict sub-models separately
  expect_equal(
    prediction[as.numeric(data_cut$Instant) >= 10],
    predict(model1, data_cut[as.numeric(data_cut$Instant) >= 10, ]))
  expect_equal(
    prediction[as.numeric(data_cut$Instant) < 10],
    predict(model2, data_cut[as.numeric(data_cut$Instant) < 10, ]))

  # rmse
  score_rmse <- R39Toolbox::score(model, data_tmp, data_tmp$conso)
  expect_equal(class(score_rmse), "numeric")
  expect_equal(length(score_rmse), 1)
})


test_that("Composite models (predict_details)", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ Temperature + Posan",
    fit_default = list(by = 'Instant'))
  model2 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ Temperature",
    fit_default = list(by = 'Instant'))
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))

  # fit
  data_tmp <- data_cut
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(data_tmp$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  model <- R39Toolbox::fit(model, data_tmp)
  # fit sub-models separately
  model1 <- R39Toolbox::fit(
    model1, data_cut[as.numeric(data_cut$Instant) >= 10, ])
  model2 <- R39Toolbox::fit(
    model2, data_cut[as.numeric(data_cut$Instant) < 10, ])

  # predict
  expect_warning(
    prediction <- predict_details(model, data_tmp))
  expect_equal(nrow(prediction), length(data_tmp$conso))
  expect_equal(class(prediction), "data.frame")
  # predict sub-models separately
  expect_equal(
    prediction[as.numeric(data_cut$Instant) >= 10, 1],
    predict_details(model1, data_cut[as.numeric(data_cut$Instant) >= 10, ])[, 1])
  expect_equal(
    prediction[as.numeric(data_cut$Instant) >= 10, 2],
    predict_details(model1, data_cut[as.numeric(data_cut$Instant) >= 10, ])[, 2])
  expect_equal(
    prediction[as.numeric(data_cut$Instant) < 10, 1],
    predict_details(model2, data_cut[as.numeric(data_cut$Instant) < 10, ])[, 1])
  # check that predict_details and predict make the same prediction
  expect_equal(
    as.numeric(rowSums(prediction, na.rm = TRUE)),
    predict(model, data_tmp))

})


# Fix issue #23 about predict_details
test_that("Composite modele issue #23", {
  n_obs_par_instant <- 100
  data <- data.frame(
    Instant_factor = as.factor(rep(0:47, n_obs_par_instant)),
    V1 = rnorm(48 * n_obs_par_instant),
    V2 = rnorm(48 * n_obs_par_instant),
    DayValidity = 1
  )

  DeclarerModeleInstant <- function(instant) {
    R39Toolbox::GeneralizedAdditiveModel(
      "V2 ~ V1 - 1", fit_default = NULL, clean = TRUE)
  }

  liste_selection <- as.list(levels(data$Instant_factor))
  liste_modeles <- lapply(liste_selection, DeclarerModeleInstant)

  modele <- R39Toolbox::CompositeModel(
    model_list = liste_modeles,
    selection_factor_name = "Instant_factor",
    selection_factor_levels = liste_selection)

  modele <- R39Toolbox::fit(
    modele, data, weights = "DayValidity", bypass_transform = TRUE)

  # OK
  predict(modele, data)
  # was not OK before bug fix
  predict_details(modele, data)

  expect_true(TRUE)  # without this line the test is skipped
})


# Fix issue about predict_details: GAMadapt models and instants
test_that("Composite modele and adaptative model by instants", {
  n_obs_par_instant <- 100
  data <- data.frame(
    Instant = as.factor(rep(0:47, n_obs_par_instant)),
    V1 = rnorm(48 * n_obs_par_instant),
    V2 = rnorm(48 * n_obs_par_instant),
    DayValidity = 1
  )
  data$TypeModel <- 0
  data$TypeModel[data$Instant %in% 20:30] <- 1
  data$TypeModel <- as.factor(data$TypeModel)

  # GAM
  gam_model <- R39Toolbox::GeneralizedAdditiveModel(
    "V2 ~ V1 - 1", fit_default = list(by = 'Instant'), clean = TRUE)
  gam_model <- R39Toolbox::fit(gam_model, data)

  # GAM adapt
  gam_adapt <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    gam_model, fit_default = list(by = 'Instant'))
  
  modele <- R39Toolbox::CompositeModel(
    model_list = list(gam_adapt, gam_adapt),
    selection_factor_name = "TypeModel",
    selection_factor_levels = list(0, 1))
  modele <- R39Toolbox::fit(
    modele, data, weights = "DayValidity", bypass_transform = TRUE)

  # OK
  silent_out <- predict(modele, data)
  # was not OK before bug fix
  silent_out <- predict_details(modele, data)

  expect_true(TRUE)  # without this line the test is skipped
})
