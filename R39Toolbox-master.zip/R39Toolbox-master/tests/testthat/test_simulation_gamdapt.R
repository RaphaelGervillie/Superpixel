context("Simulations (Gam Adapt)")

data <- R39Toolbox::R39ExData
data$Var1 <- as.factor(as.numeric(data$Instant < 12))
data$Instant <- as.factor(data$Instant)

test_that("GamAdaptative model (simulation)", {
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_mid_term2,
    fixed_global_effect = 's(Temperature)', mu = 0.95)

  suppressWarnings(model1 <- R39Toolbox::fit(model, data))

  ### Fixed-weights (predict)
  suppressWarnings(
    prediction1 <- predict(
      model1, data,
      leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
  expect_equal(length(prediction1), length(data$conso) - 100)
  expect_equal(class(prediction1), "numeric")
  suppressWarnings(
    simulation1 <- R39Toolbox::simulate(
      model1, data, update_frequency = 0, launch_frequency = 10000000,
      leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
  expect_equal(simulation1, prediction1)

  ### Online mode (simulate)
  data_no_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
  data_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(
    simulation1_1 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  suppressWarnings(
    simulation1_2 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
      update_frequency = 24, launch_frequency = 24))
  #
  suppressWarnings(
    simulation1_2_2 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
      update_frequency = 24, launch_frequency = 24, horizon = 12))
  expect_true(all(is.na(simulation1_2_2[1:12])))
  expect_equal(simulation1_2_2[13:24], simulation1_2[13:24])
  expect_equal(simulation1_2_2[37:48], simulation1_2[37:48])
  #
  suppressWarnings(
    simulation1_3 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
      update_frequency = data_december2014$date[as.numeric(strftime(
        data_december2014$date, format = "%H", tz = 'UTC')) == 8],
      launch_frequency = data_december2014$date[as.numeric(strftime(
        data_december2014$date, format = "%H", tz = 'UTC')) == 8]))
  expect_equal(simulation1_2, simulation1_3)
  suppressWarnings(
    prediction1_1 <- predict(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  #
  data_no_december2014_2 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 09:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
  suppressWarnings(
    prediction1_2 <- predict(
      model1_2, data_december2014,
      leading_period = c(rep(1, 57), rep(0, nrow(data_december2014) - 57))))
  #
  expect_equal(prediction1_1[[1]], simulation1_1[[1]])
  expect(prediction1_1[[2]] != simulation1_1[[2]], failure_message = "")
  expect_equal(prediction1_2[[1]], simulation1_1[[2]])
})


test_that("Adaptative GAM models with history", {
  # load data
  cut1 <- 25000
  cut2 <- 24800
  data_cut <- data[1:cut1, ]
  data_cut2 <- data[1:cut2, ]

  # init
  model_gam <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  model_gam <- R39Toolbox::fit(model_gam, data_cut)
  model1 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_gam,
    fixed_global_effects = c("s(Temperature)", "(Intercept)"),
    mu = 0.95)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))
  model_for_simulate <- model1
  model_for_simulate_DOAAT <- model1

  # fit normally
  model1 <- R39Toolbox::fit(model1, data_cut2, hist = TRUE)
  model1_bis <- R39Toolbox::fit(model1, tail(data_cut, cut1 - cut2), hist = TRUE)
  model1 <- R39Toolbox::fit(model1, data_cut, hist = TRUE)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))
  expect_true(!is.null(model1$model_))
  expect_equal(length(model1$history), 2)
  # fit through simulate
  res_simulate_fit <- simulate(
    model_for_simulate, data,
    update_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    verbose = FALSE, output_model = TRUE, save_history = TRUE)
  model_for_simulate  <- res_simulate_fit$model
  prediction_simulate <- res_simulate_fit$simulation
  expect_true("GeneralizedAdditiveModelAdaptative"
              %in% class(model_for_simulate))
  # DOAAT's version
  res_simulate_fit <- simulate_DOAAT(
    model_for_simulate_DOAAT, data,
    update_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    verbose = FALSE, output_model = TRUE, save_history = TRUE)
  model_for_simulate_DOAAT  <- res_simulate_fit$model
  prediction_simulate_DOAAT <- res_simulate_fit$simulation

  # Prediction (already tested in test_model_ar.R) so no test is added
  # predict
  prediction1 <- predict(model1, data)
  prediction1_bis <- predict(model1_bis, data)
  expect_warning(
    prediction2 <- predict(model1, data, predict_as_date = data$date[[1]]))
  prediction3 <- predict(
    model1, data,
    predict_as_date = data$date[[(cut2 + cut1) / 2]])
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data)
  prediction1_bis_1 <- R39Toolbox::predict_details(model1_bis, data)
  prediction2_1 <- R39Toolbox::predict_details(
    model1, data, predict_as_date = data$date[[1]])
  prediction3_1 <- R39Toolbox::predict_details(
    model1, data, predict_as_date = data$date[[(cut2 + cut1) / 2]])
  # Prediction through simulate (= the main purpose of this test)
  # 1. with history use
  res_simulate_predict <- simulate(
    model_for_simulate, data,
    update_frequency = 100000000,
    launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    verbose = FALSE,
    output_model = FALSE, save_history = FALSE, use_history = TRUE)
  expect_equal(prediction_simulate, res_simulate_predict)
  mask_test <- 1:cut2
  expect_equal(prediction_simulate[mask_test], prediction2[mask_test])
  mask_test <- (cut2 + 1):cut1
  expect_equal(prediction_simulate[mask_test], prediction3[mask_test])
  mask_test <- (cut1 + 1):nrow(data)
  expect_equal(prediction_simulate[mask_test], prediction1_bis[mask_test])

  # 2. without history use
  res_simulate_predict <- simulate(
    model_for_simulate, data,
    update_frequency = 100000000,
    launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    verbose = FALSE,
    output_model = FALSE, save_history = FALSE, use_history = FALSE)
  expect_equal(res_simulate_predict, prediction1_bis)
  res_simulate_predict_DOAAT <- simulate_DOAAT(
    model_for_simulate_DOAAT, data,
    update_frequency = 100000000,
    launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
    verbose = FALSE,
    output_model = FALSE, save_history = FALSE, use_history = FALSE)
  expect_equal(res_simulate_predict_DOAAT, prediction1)
})


test_that("GamAdaptative model 'per factor'", {
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7',
    fit_default = list(by = 'Var1'))
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_mid_term2,
    fixed_global_effect = 's(Temperature)', mu = 0.95)

  suppressWarnings(model1 <- R39Toolbox::fit(model, data))

  ### Fixed-weights (predict)
  prediction1 <- predict(
    model1, data,
    leading_period = c(rep(1, 100), rep(0, nrow(data) - 100)))
  expect_equal(length(prediction1), length(data$conso) - 100)
  expect_equal(class(prediction1), "numeric")
  suppressWarnings(
    simulation1 <- R39Toolbox::simulate(
      model1, data, update_frequency = 0,
      launch_frequency = 10000000,
      leading_period = c(rep(1, 100), rep(0, nrow(data) - 100))))
  expect_equal(simulation1, prediction1)

  ### Online mode (simulate)
  data_no_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
  data_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  expect_error(R39Toolbox::simulate(model1_1, data_december2014))
  suppressWarnings(
    simulation1_1 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  suppressWarnings(
    simulation1_2 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      update_frequency = 24, launch_frequency = 24,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  #
  suppressWarnings(
    simulation1_2_2 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56)),
      update_frequency = 24, launch_frequency = 24, horizon = 12))
  expect_true(all(is.na(simulation1_2_2[1:12])))
  expect_equal(simulation1_2_2[13:24], simulation1_2[13:24])
  expect_equal(simulation1_2_2[37:48], simulation1_2[37:48])
  #
  suppressWarnings(
    simulation1_3 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      update_frequency = data_december2014$date[as.numeric(strftime(
        data_december2014$date, format = "%H", tz = 'UTC')) == 8],
      launch_frequency = data_december2014$date[as.numeric(strftime(
        data_december2014$date, format = "%H", tz = 'UTC')) == 8],
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  expect_equal(simulation1_1[[1]], simulation1_2[[1]])
  expect_equal(simulation1_2, simulation1_3)
  suppressWarnings(
    prediction1_1 <- predict(
      model1_1, data_december2014,
      leading_period = c(rep(1, 56), rep(0, nrow(data_december2014) - 56))))
  #
  data_no_december2014_2 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 13:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
  data_december2014_2 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(
    prediction1_2 <- predict(
      model1_2, data_december2014_2,
      leading_period = c(rep(1, 61), rep(0, nrow(data_december2014_2) - 61))))
  #
  data_no_december2014_3 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 14:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_3 <- R39Toolbox::fit(model, data_no_december2014_3))
  data_december2014_3 <- data[
    data$date >= as.POSIXct(
      "2014-11-24 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(
    prediction1_3 <- predict(
      model1_3, data_december2014_3,
      leading_period = c(rep(1, 62), rep(0, nrow(data_december2014_3) - 62))))
  expect_equal(prediction1_1[[1]], simulation1_1[[1]])
  expect(prediction1_1[[2]] != simulation1_1[[2]], failure_message = "")
  expect_equal(prediction1_1[[2]], simulation1_2[[2]])
})

