context("Simulations")

data <- R39Toolbox::R39ExData
data$Var1 <- as.factor(as.numeric(data$Instant < 12))
data$Instant <- as.factor(data$Instant)


test_that("Basic models", {
  # Model initiatlisation
  # auxillary models
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  # check API robustness
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data, weights = rep(1, nrow(data)))
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  # final list
  all_models <- list(
    R39Toolbox::LinearModel(
      formula = "conso ~ Temperature + Posan"),
    R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan"),
    R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan",
      fit_default = list(by = 'Instant')),
    R39Toolbox::MixtureModel(
      list(model_mid_term1, model_mid_term2), 'conso'))

  for (i in 1:length(all_models)) {
    model <- all_models[[i]]
    suppressWarnings(model1 <- R39Toolbox::fit(model, data))

    ### Fixed-weights (predict)
    prediction1 <- predict(model1, data)
    expect_equal(length(prediction1), length(data$conso))
    expect_equal(class(prediction1), "numeric")
    suppressWarnings(
      simulation1 <- R39Toolbox::simulate(
        model1, data, update_frequency = 0, launch_frequency = 10000000))
    expect_equal(simulation1, prediction1)

    if ('ShortTermForecastModel' %in% class(model)) {
      ### Online mode (simulate)
      data_no_december2014 <- data[
        data$date >= as.POSIXct(
          "2014-11-25 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
          data$date < as.POSIXct(
            "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
      data_december2014 <- data[
        data$date >= as.POSIXct(
          "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      suppressWarnings(
        simulation1_1 <- R39Toolbox::simulate(model1_1, data_december2014))
      #
      suppressWarnings(
        simulation1_2 <- R39Toolbox::simulate(
          model1_1, data_december2014, update_frequency = 24))
      suppressWarnings(
        simulation1_2_with_model <- R39Toolbox::simulate(
          model1_1, data_december2014, update_frequency = 24, output_model = TRUE))
      suppressWarnings(
        simulation1_2_1 <- R39Toolbox::simulate(
          model1_1, data_december2014, update_frequency = 24, launch_frequency = 24))
      expect_equal(simulation1_2_1, simulation1_2)
      #
      suppressWarnings(
        simulation1_2_2 <- R39Toolbox::simulate(
          model1_1, data_december2014,
          update_frequency = 24, launch_frequency = 24, horizon = 12))
      expect_true(all(is.na(simulation1_2_2[1:12])))
      expect_equal(simulation1_2_2[13:24], simulation1_2_1[13:24])
      expect_equal(simulation1_2_2[37:48], simulation1_2_1[37:48])
      #
      suppressWarnings(
        simulation1_3 <- R39Toolbox::simulate(
          model1_1, data_december2014,
          update_frequency = data_december2014$date[as.numeric(strftime(
            data_december2014$date, format = "%H", tz = 'UTC')) == 8]))
      expect_equal(simulation1_2, simulation1_3)

      prediction1_1 <- predict(model1_1, data_december2014)
      #
      data_no_december2014_2 <- data[
        data$date >= as.POSIXct(
          "2014-11-25 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
          data$date < as.POSIXct(
            "2014-11-26 09:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
      data_december2014_2 <- data[
        data$date >= as.POSIXct(
          "2014-11-26 09:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      prediction1_2 <- predict(model1_2, data_december2014_2)
      #
      data_no_december2014_3 <- data[
        data$date >= as.POSIXct(
          "2014-11-25 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
          data$date < as.POSIXct(
            "2014-11-26 10:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      suppressWarnings(model1_3 <- R39Toolbox::fit(model, data_no_december2014_3))
      data_december2014_3 <- data[
        data$date >= as.POSIXct(
          "2014-11-26 10:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
      prediction1_3 <- predict(model1_3, data_december2014_3)
      expect_equal(prediction1_1[[1]], simulation1_1[[1]])
      expect(prediction1_1[[2]] != simulation1_1[[2]], failure_message = "")
      expect_equal(prediction1_2[[1]], simulation1_1[[2]])
      expect_equal(prediction1_3[[1]], simulation1_1[[3]])
    } else {
      suppressWarnings(simulation2 <- R39Toolbox::simulate(model1, data))
      expect_equal(simulation2, prediction1)
    }
  }
})
