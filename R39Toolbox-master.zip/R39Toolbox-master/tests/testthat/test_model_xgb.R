##########################
# Xgboost Model
##########################
context("Xgboost Model tests")

skip_if_no_xgboost <- function() {
  if (!require(xgboost)) {
    skip("'xgboost' package not available.")
  }
}

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
train_test_split <- floor(nrow(data) * 0.8)
train <- data[1:train_test_split, ]
test <- data[(1 + train_test_split):nrow(data), ]

test_that("Xgboost Model - initialization", {
  #skip_if_no_xgboost()
  # test run initialization
  
  # init
  model <- R39Toolbox::XgboostModel(
    target_variable = "conso",
    eta = 0.2, max_depth = 4, 
    min_child_weight = 2,
    nrounds = 700)
  
  # fit
  train_xgb <- data.frame(model.matrix(~ .-1, train[, -1]))
  model <- R39Toolbox::fit(model, train_xgb)
  
  # predict
  test_xgb <- data.frame(model.matrix(~ .-1, test[, -1]))
  prediction <- predict(model, test_xgb)
  expect_equal(length(prediction), length(test$conso))
})



test_that("Xgboost Model by instant, initialized by data set", {
  #skip_if_no_xgboost()
  # init
  model1 <- R39Toolbox::XgboostModel(
    target_variable = "conso",
    fit_default = list(by = 'Instant'))
  
  model2 <- R39Toolbox::XgboostModel(
    target_variable = "conso",
    eta = 0.2, max_depth = 4, 
    min_child_weight = 2,
    nrounds = 700,
    fit_default = list(by = 'Instant'))
  
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))
  
  # fit
  data_tmp <- data.frame(model.matrix(~ .-1, train[, -1]))
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(train$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  data_tmp$Instant <- train$Instant
  model <- R39Toolbox::fit(model, data_tmp)
  
  # fit sub-models separately
  train_xgb <- data.frame(model.matrix(~ .-1, train[, -c(1, 5)]))
  train_xgb$Instant <- train$Instant
  model1 <- R39Toolbox::fit(
    model1, train_xgb[as.numeric(train$Instant) >= 10, ])
  model2 <- R39Toolbox::fit(
    model2, train_xgb[as.numeric(train$Instant) < 10, ])
  
  # predict
  data_tmp <- data.frame(model.matrix(~ .-1, test[, -1]))
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(test$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  data_tmp$Instant <- test$Instant
  prediction <- predict(model, data_tmp)
  
  expect_equal(length(prediction), length(data_tmp$conso))
  
  # predict sub-models separately
  test_xgb <- data.frame(model.matrix(~ .-1, test[, -c(1, 5)]))
  test_xgb$Instant <- test$Instant
  expect_true(
    all(prediction[as.numeric(test$Instant) >= 10] ==
          predict(model1, test_xgb[as.numeric(test$Instant) >= 10, ])))
  expect_true(
    all(prediction[as.numeric(test$Instant) < 10] ==
          predict(model2, test_xgb[as.numeric(test$Instant) < 10, ])))
})
