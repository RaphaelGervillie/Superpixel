context("Metrics tests")

obs <- c(1, 2)
fit <- c(2, 5)

##########################
# RMSE
##########################

test_that("RMSE result", {
  expect_equal(sqrt((1 * (1 - 2) ^ 2 + 1 * (2 - 5) ^ 2)/(1 + 1)), rmse(obs, fit))
  expect_equal(sqrt((1 * (1 - 2) ^ 2 + 1 * (2 - 5) ^ 2)/(1 + 1))/(1.5), rmse(obs, fit, normalized = TRUE))
  expect_equal(sqrt((1 * (0 - 0) ^ 2 + 1 * (1 - 2) ^ 2 + 1 * (2 - 5) ^ 2) / (1 + 1 + 1)), rmse(c(0, obs), c(0, fit)))
  expect_equal(sqrt((1 * (1 - 2) ^ 2 + 1 * (2 - 5) ^ 2) / (1 + 1)), rmse(c(obs, NA), c(fit, NA), na.rm = TRUE))
  expect_equal(sqrt((1 * (1 - 2) ^ 2 + 4 * (2 - 5) ^ 2) / (1 + 4)), rmse(obs, fit, weights = c(1, 4)))
})

test_that("RMSE control", {
  expect_error(rmse(obs, fit[-1]))
  expect_error(rmse(c(obs, -3), c(fit, 3), normalized = TRUE))
  expect_error(rmse(obs, fit, weights = c(0, 0)))
  expect_error(rmse(obs, fit, weights = c(-1, 2)))
  expect_warning(rmse(c(obs, NA), c(fit, NA), weights = c(0, 1, 1)))
})


##########################
# MAE
##########################
test_that("MAE result", {
  expect_equal((1 * abs(1 - 2) + 1 * abs(2 - 5)) / (1 + 1), mae(obs, fit))
  expect_equal((1 * abs(0 - 0) + 1 * abs(1 - 2) + 1 * abs(2 - 5)) / (1 + 1 + 1), mae(c(0, obs), c(0, fit)))
  expect_equal((1 * abs(1 - 2) + 1 * abs(2 - 5)) /(1 + 1), mae(c(obs, NA), c(fit, NA), na.rm = TRUE))
  expect_equal((1 * abs(1 - 2) + 4 * abs(2 - 5)) /(1 + 4), mae(obs, fit, weights = c(1, 4)))
})

test_that("MAE control", {
  expect_error(mae(obs, fit[-1]))
  expect_error(mae(obs, fit, weights = c(0, 0)))
  expect_error(mae(obs, fit, weights = c(-1, 2)))
  expect_warning(mae(c(obs, NA), c(fit, NA), weights = c(0, 1, 1)))
})


##########################
# MAPE
##########################
test_that("MAPE result", {
  expect_equal((1 * abs((1 - 2) / 1) + 1 * abs((2 - 5) / 2)) / (1 + 1), mape(obs, fit))
  expect_equal((1 * abs((1 - 2) / 1) + 1 * abs((2 - 5) / 2)) / (1 + 1), mape(c(obs, NA), c(fit, NA), na.rm = TRUE))
  expect_equal((1 * abs((1 - 2) / 1) + 4 * abs((2 - 5) / 2)) / (1 + 4), mape(obs, fit, weights = c(1, 4)))
})


test_that("MAPE control", {
  expect_error(mape(obs, fit[-1]))
  expect_warning(mape(c(0, obs), c(0, fit)))
  expect_error(mape(obs, fit, weights = c(0, 0)))
  expect_error(mape(obs, fit, weights = c(-1, 2)))
  expect_warning(mape(c(obs, NA), c(fit, NA), weights = c(0, 1, 1)))
})
