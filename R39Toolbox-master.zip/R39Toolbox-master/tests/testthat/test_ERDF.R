context("ERDF tests")

library(timeDate)

# Deprecation tests
test_that("create*.ERDF is still OK", {
  date_debut <- "2015-01-01"
  date_fin   <- "2015-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_debut, " 00:00:00"),
    date_end   = paste0(date_fin, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date"), convention = 'begin')
  expect_warning(R39Toolbox::createDayType.ERDF(data))
  expect_warning(R39Toolbox::createDayType.ERDF7(data))
  expect_warning(R39Toolbox::createDayType.ERDF9(data))
  expect_warning(R39Toolbox::createBreak.ERDF2(data))
  expect_warning(R39Toolbox::createBreak.ERDF11(data))
})
