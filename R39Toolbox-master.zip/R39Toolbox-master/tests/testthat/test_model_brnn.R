context("Bayesian Regularization for Feed-Forward Neural Network")

data <- R39Toolbox::R39ExData
data$TypeJour7 <- as.numeric(data$TypeJour7)

train_test_split <- floor(nrow(data) * 0.8)
train <- data[1:train_test_split, ]
test  <- data[(1 + train_test_split):nrow(data), ]

test_that("BRNN models two ways of initialization", {
  # test run initialization
  # two ways don't necessarily end in the same performance
  skip(paste0("BRNN tests: ",
              "two ways of initialization do not necessarily end ",
              "in the same performance."))
  
  # init
  model1 <- R39Toolbox::BayesianRegularizedNNModel(
    formula = "conso ~ Temperature + Posan + TypeJour7 + Tendance",
    neurons = 2)

  model2 <- R39Toolbox::BayesianRegularizedNNModel(
    target_variable = "conso", neurons = 2)
  
  # fit
  model1  <- R39Toolbox::fit(model1, train)
  train_2 <- data.frame(model.matrix(~ .-1, train[, -c(1, 5)]))
  model2  <- R39Toolbox::fit(model2, train_2)
  
  # predict
  prediction_1 <- predict(model1, test)
  test_2 <- data.frame(model.matrix(~ .-1, test[, -c(1, 5)]))
  prediction_2 <- predict(model2, test)
  expect_equal(length(prediction_1), length(test$conso))
  expect_equal(length(prediction_2), length(test$conso))
  expect_equal(prediction_1, prediction_2)
})
