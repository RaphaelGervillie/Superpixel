context("create variables tests")

test_that("DayTypes", {
  ### weekdays
  date_begin <- "2018-04-08"
  date_end   <- "2018-04-14"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = 0:6)
  expect_equal(levels(daytype), as.character(0:6))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(0:6, each = 48))

  ### sets of days
  daytype <- generate_daytypes(data, daytypes = c(11, 12))
  expect_equal(levels(daytype), as.character(11:12))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(11, 12, 12, 12, 12, 12, 11), each = 48))

  daytype <- generate_daytypes(data, daytypes = c(13, 14))
  expect_equal(levels(daytype), as.character(c(13, 14, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 13, 14, 14, 14, 13, 10), each = 48))

  ### specific days
  # Sunday in June
  date_begin <- "2018-06-24"
  date_end   <- "2018-06-24"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(20))
  expect_equal(levels(daytype), as.character(c(20)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(20), 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(20))
  expect_equal(levels(daytype), as.character(c(20)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(20), 48))
  # Sunday in July
  date_begin <- "2018-07-29"
  date_end   <- "2018-07-29"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(20))
  expect_equal(levels(daytype), as.character(c(20)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(20), 48))
  daytype <- generate_daytypes(data, daytypes = c(23))
  expect_equal(levels(daytype), as.character(c(23)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(23), 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(20))
  expect_equal(levels(daytype), as.character(c(20)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(20), 48))
  daytype <- generate_daytypes(data, daytypes = c(23))
  expect_equal(levels(daytype), as.character(c(23)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(23), 48))
  # Sunday in August
  date_begin <- "2018-08-19"
  date_end   <- "2018-08-19"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(21))
  expect_equal(levels(daytype), as.character(c(21)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(21), 48))
  daytype <- generate_daytypes(data, daytypes = c(23))
  expect_equal(levels(daytype), as.character(c(23)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(23), 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(21))
  expect_equal(levels(daytype), as.character(c(21)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(21), 48))
  daytype <- generate_daytypes(data, daytypes = c(23))
  expect_equal(levels(daytype), as.character(c(23)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(23), 48))
  # Sunday in December
  date_begin <- "2018-12-23"
  date_end   <- "2018-12-23"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(22))
  expect_equal(levels(daytype), as.character(c(22)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(22), 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(22))
  expect_equal(levels(daytype), as.character(c(22)))
  expect_equal(as.numeric(levels(daytype)[daytype]), rep(c(22), 48))

  ### Generic special days
  # 2018 May 1st period
  date_begin <- "2018-04-30"
  date_end   <- "2018-05-02"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = 30:33)
  expect_equal(levels(daytype), as.character(30:33))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(33, 30, 32), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = 30:33)
  expect_equal(levels(daytype), as.character(30:33))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(33, 30, 32), each = 48))
  # 2018 May 1st period
  date_begin <- "2018-05-07"
  date_end   <- "2018-05-09"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = 30:33)
  expect_equal(levels(daytype), as.character(30:33))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(33, 30, 33), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = 30:33)
  expect_equal(levels(daytype), as.character(30:33))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(33, 30, 33), each = 48))
})

test_that("DayTypes (special days)", {
  ### Special days
  # New Years Day
  date_begin <- "2018-12-31"
  date_end   <- "2019-01-02"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(401, 40, 402))
  expect_equal(levels(daytype), as.character(c(401, 40, 402)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(401, 40, 402), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(401, 40, 402))
  expect_equal(levels(daytype), as.character(c(401, 40, 402)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(401, 40, 402), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Christmas
  date_begin <- "2018-12-24"
  date_end   <- "2018-12-26"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(471, 47, 472))
  expect_equal(levels(daytype), as.character(c(471, 47, 472)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(471, 47, 472), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(471, 47, 472))
  expect_equal(levels(daytype), as.character(c(471, 47, 472)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(471, 47, 472), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # May 1st
  date_begin <- "2018-04-30"
  date_end   <- "2018-05-02"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(41))
  expect_equal(levels(daytype), as.character(c(41, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 41, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(41))
  expect_equal(levels(daytype), as.character(c(41, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 41, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # May 8th
  date_begin <- "2018-05-07"
  date_end   <- "2018-05-09"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(42))
  expect_equal(levels(daytype), as.character(c(42, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 42, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(42))
  expect_equal(levels(daytype), as.character(c(42, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 42, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # July 14th
  date_begin <- "2018-07-13"
  date_end   <- "2018-07-15"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(43))
  expect_equal(levels(daytype), as.character(c(43, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 43, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(43))
  expect_equal(levels(daytype), as.character(c(43, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 43, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # August 15th
  date_begin <- "2018-08-14"
  date_end   <- "2018-08-16"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(44))
  expect_equal(levels(daytype), as.character(c(44, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 44, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(44))
  expect_equal(levels(daytype), as.character(c(44, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 44, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # November 1st
  date_begin <- "2018-10-31"
  date_end   <- "2018-11-02"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(45))
  expect_equal(levels(daytype), as.character(c(45, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 45, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(45))
  expect_equal(levels(daytype), as.character(c(45, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 45, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # November 11th
  date_begin <- "2018-11-10"
  date_end   <- "2018-11-12"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(46))
  expect_equal(levels(daytype), as.character(c(46, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 46, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(46))
  expect_equal(levels(daytype), as.character(c(46, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 46, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Easter
  date_begin <- "2018-04-01"
  date_end   <- "2018-04-03"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(50))
  expect_equal(levels(daytype), as.character(c(50, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 50, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(50))
  expect_equal(levels(daytype), as.character(c(50, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 50, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Pentecost
  date_begin <- "2018-05-20"
  date_end   <- "2018-05-22"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(52))
  expect_equal(levels(daytype), as.character(c(52, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 52, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(52))
  expect_equal(levels(daytype), as.character(c(52, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 52, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # "Ascension"
  date_begin <- "2018-05-09"
  date_end   <- "2018-05-11"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(51))
  expect_equal(levels(daytype), as.character(c(51, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 51, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(51))
  expect_equal(levels(daytype), as.character(c(51, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 51, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # July 14th
  date_begin <- "2018-07-13"
  date_end   <- "2018-07-15"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(43))
  expect_equal(levels(daytype), as.character(c(43, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 43, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(43))
  expect_equal(levels(daytype), as.character(c(43, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 43, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # August 15th
  date_begin <- "2018-08-14"
  date_end   <- "2018-08-16"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(44))
  expect_equal(levels(daytype), as.character(c(44, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 44, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(44))
  expect_equal(levels(daytype), as.character(c(44, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 44, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # November 1st
  date_begin <- "2018-10-31"
  date_end   <- "2018-11-02"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(45))
  expect_equal(levels(daytype), as.character(c(45, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 45, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(45))
  expect_equal(levels(daytype), as.character(c(45, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 45, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # November 11th
  date_begin <- "2018-11-10"
  date_end   <- "2018-11-12"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(46))
  expect_equal(levels(daytype), as.character(c(46, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 46, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(46))
  expect_equal(levels(daytype), as.character(c(46, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 46, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Easter
  date_begin <- "2018-04-01"
  date_end   <- "2018-04-03"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(50))
  expect_equal(levels(daytype), as.character(c(50, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 50, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(50))
  expect_equal(levels(daytype), as.character(c(50, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 50, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Pentecost
  date_begin <- "2018-05-20"
  date_end   <- "2018-05-22"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(52))
  expect_equal(levels(daytype), as.character(c(52, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 52, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(52))
  expect_equal(levels(daytype), as.character(c(52, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 52, 10), each = 48))
  daytype <- generate_daytypes(data, daytypes = c(30))
  expect_equal(levels(daytype), as.character(c(30, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 30, 10), each = 48))

  # Holy Friday
  date_begin <- "2018-03-29"
  date_end   <- "2018-03-31"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(60))
  expect_equal(levels(daytype), as.character(c(60, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 60, 10), each = 48))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  daytype <- generate_daytypes(data, daytypes = c(60))
  expect_equal(levels(daytype), as.character(c(60, 10)))
  expect_equal(as.numeric(levels(daytype)[daytype]),
               rep(c(10, 60, 10), each = 48))
})


test_that("Daytypes (comparison with deprecated daytypes functions)", {
  date_begin <- "2017-01-01"
  date_end   <- "2017-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 60 * 60, tz = "CET", variables = c("date", "Instant"))

  # generate_daytype_ERDF
  daytypes_new <- R39Toolbox::generate_daytypes(data, daytypes = c(10, 30))
  expect_warning(
    daytypes_old <- R39Toolbox::generate_daytype_ERDF(
      data, holidays = c(
        timeDate::listHolidays(pattern = "*FR"), "NewYearsDay",
        "EasterMonday", "LaborDay", "PentecostMonday", "ChristmasDay")),
    regexp = "deprecated")
  expect_equal(length(daytypes_old), length(daytypes_new))
  expect_equal(
    unique(levels(daytypes_new)[daytypes_new[daytypes_old == "Regular"]]),
    "10")
  expect_equal(
    unique(levels(daytypes_new)[daytypes_new[daytypes_old != "Regular"]]),
    "30")

  # generate_daytype_ERDF_7
  daytypes_new <- R39Toolbox::generate_daytypes(
    data, daytypes = c(1, 14, 5, 6, 0, 30, 33))
  expect_warning(
    daytypes_old <- R39Toolbox::generate_daytype_ERDF_7(
      data, holidays = c(
        timeDate::listHolidays(pattern = "*FR"), "NewYearsDay",
        "EasterMonday", "LaborDay", "PentecostMonday", "ChristmasDay")),
    regexp = "deprecated")
  expect_equal(length(daytypes_old), length(daytypes_new))
  toto <- cbind(
    strftime(data$date, format = "%Y-%m-%d %H:%M:%S"),
    daytypes_old,
    levels(daytypes_new)[daytypes_new])
  map_values <- list("0" = "0", "1" = "1", "2" = "14", "5" = "5", "6" = "6",
                     "7" = "30", "8" = "33")
  for (x in names(map_values)) {
    expect_equal(unique(toto[toto[, 2] == x, 3]), map_values[[x]])
  }

  # generate_daytype_ERDF_9
  daytypes_new <- R39Toolbox::generate_daytypes(
    data, daytypes = c(1, 2, 3, 4, 5, 6, 0, 30, 33))
  expect_warning(
    daytypes_old <- R39Toolbox::generate_daytype_ERDF_9(
      data, holidays = c(
        timeDate::listHolidays(pattern = "*FR"), "NewYearsDay",
        "EasterMonday", "LaborDay", "PentecostMonday", "ChristmasDay")),
    regexp = "deprecated")
  expect_equal(length(daytypes_old), length(daytypes_new))
  toto <- cbind(
    strftime(data$date, format = "%Y-%m-%d %H:%M:%S"),
    daytypes_old,
    levels(daytypes_new)[daytypes_new])
  map_values <- list("0" = "0", "1" = "1", "2" = "2", "3" = "3",
                     "4" = "4", "5" = "5", "6" = "6", "7" = "30", "8" = "33")
  for (x in names(map_values)) {
    expect_equal(unique(toto[toto[, 2] == x, 3]), map_values[[x]])
  }
})


# Test that bridges can be generated eventhough dayoffs are not
# Fix issue #14
test_that("generate_daytypes and bridging days", {
  expect_warning(
    cal <- R39Toolbox::generate_calendar(
      "2019-05-25", "2019-05-31", ts = 60 * 60 * 24, variables = c('date')))
  cal$dt <- R39Toolbox::generate_daytypes(cal, daytypes = c(33))
  expect_equal(as.numeric(tail(levels(cal$dt)[cal$dt], 1)), 33)
  expect_equal(as.numeric(tail(levels(cal$dt)[cal$dt], 2))[[1]], 10)
})


test_that("Offsets (general offsets)", {
  date_begin <- "2018-01-01"
  date_end   <- "2018-12-31"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 2))
  expect_equal(levels(offsets), as.character(c(1, 2)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(2, 42 + 48 * (30 * 7 + 6) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 3, 4))
  expect_equal(levels(offsets), as.character(c(1, 3, 4)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(3, 42 + 48 * (23 * 7)),
      rep(4, 48 * (7 * 7 + 6) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 5, 6))
  expect_equal(levels(offsets), as.character(c(1, 5, 6)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(5, 42 + 48 * (23 * 7 - 2)),
      rep(6, 48 * (7 * 7 + 6 + 2) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 2))
  expect_equal(levels(offsets), as.character(c(1, 2)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 2),
      # summer (offset = 2) until 2018-10-28 01:00:00 UTC (excluded),
      # because it corresponds to 2018-10-28 03:00:00 CEST, which is the moment
      # where we switch to the new hour
      rep(2, 46 + 48 * (30 * 7 + 6) + 2),
      rep(1, 46 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 3, 4))
  expect_equal(levels(offsets), as.character(c(1, 3, 4)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 2),
      rep(3, 46 + 48 * (23 * 7)),
      rep(4, 48 * (7 * 7 + 6) + 2),
      rep(1, 46 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 5, 6))
  expect_equal(levels(offsets), as.character(c(1, 5, 6)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 2),
      rep(5, 46 + 48 * (23 * 7 - 2)),
      rep(6, 48 * (7 * 7 + 6 + 2) + 2),
      rep(1, 46 + 48 * (9 * 7 + 1))))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 2))
  expect_equal(levels(offsets), as.character(c(1, 2)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(2, 42 + 48 * (30 * 7 + 6) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 3, 4))
  expect_equal(levels(offsets), as.character(c(1, 3, 4)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(3, 42 + 48 * (23 * 7)),
      rep(4, 48 * (7 * 7 + 6) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(1, 5, 6))
  expect_equal(levels(offsets), as.character(c(1, 5, 6)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(1, 48 * (11 * 7 + 6) + 4),
      rep(5, 42 + 48 * (23 * 7 - 2) + 2),
      rep(6, -2 + 48 * (7 * 7 + 6 + 2) + 6),
      rep(1, 44 + 48 * (9 * 7 + 1))))
})


test_that("Offsets (summer break)", {
  date_begin <- "2018-07-25"
  date_end   <- "2018-09-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(10, 48 * 7 * 5), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(11:15, each = 48 * 7), rep(0, 48 * 8)))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(10, 48 * 7 * 5), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(11:15, each = 48 * 7), rep(0, 48 * 8)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(10, 48 * 7 * 5), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 5), rep(11:15, each = 48 * 7), rep(0, 48 * 8)))

  date_begin <- "2018-08-01"
  date_end   <- "2018-09-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(10, 48 * (7 * 4 + 5)), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(11, 48 * 5), rep(12:15, each = 48 * 7), rep(0, 48 * 8)))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(10, 48 * (7 * 4 + 5)), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(11, 48 * 5), rep(12:15, each = 48 * 7), rep(0, 48 * 8)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(10, 48 * (7 * 4 + 5)), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(11, 48 * 5), rep(12:15, each = 48 * 7), rep(0, 48 * 8)))

  date_begin <- "2016-07-25"
  date_end   <- "2016-09-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(10, 48 * (7 * 4 + 3 + 4)), rep(0, 48 * 6)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 6)))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(10, 48 * (7 * 4 + 3 + 4)), rep(0, 48 * 6)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 6)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(10, 48 * (7 * 4 + 3 + 4)), rep(0, 48 * 6)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 6)))

  date_begin <- "2015-07-25"
  date_end   <- "2015-09-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(10, 48 * (7 * 4 + 1 + 6)), rep(0, 48 * 4)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 4)))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(10, 48 * (7 * 4 + 1 + 6)), rep(0, 48 * 4)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 4)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(10))
  expect_equal(levels(offsets), as.character(c(10, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(10, 48 * (7 * 4 + 1 + 6)), rep(0, 48 * 4)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 11:15)
  expect_equal(levels(offsets), as.character(c(11:15, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 9), rep(11:14, each = 48 * 7),
      rep(15, 48 * 7), rep(0, 48 * 4)))
})


# Test consistency of summer offsets generation
# Fix issue #13
test_that("generate_offsets consistency in summer", {
  date_begin <- as.POSIXct("2014-09-01 00:00:00", tz="CET")
  date_end   <- as.POSIXct("2020-12-31 23:30:00", tz="CET")
  cal <- R39Toolbox::generate_calendar(
    date_begin, date_end, ts = 30 * 60, variables = c("date"))
  offsets_rpt <- R39Toolbox::generate_offsets_calhisto_france(cal)
  expect_equal(
    head(levels(offsets_rpt)[offsets_rpt][cal$date >= "2014-09-01"]),
    rep("15", 6))
  # add the test below because there was an issue with offsets when
  # the data run over several years
  expect_equal(
    head(levels(offsets_rpt)[offsets_rpt][cal$date >= "2015-09-01"]),
    rep("15", 6))
})


test_that("Offsets (winter break)", {
  date_begin <- "2017-12-10"
  date_end   <- "2018-01-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(20))
  expect_equal(levels(offsets), as.character(c(20, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(20, 48 * 17), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 21:23)
  expect_equal(levels(offsets), as.character(c(21:23, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(21, 48 * 2), rep(22, 48 * 7),
      rep(23, 48 * 8), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(211))
  expect_equal(levels(offsets), as.character(c(211, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 13), rep(211, 48 * 1), rep(0, 48 * 18)))
  #(UTC)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(20))
  expect_equal(levels(offsets), as.character(c(20, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(20, 48 * 17), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 21:23)
  expect_equal(levels(offsets), as.character(c(21:23, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(21, 48 * 2), rep(22, 48 * 7),
      rep(23, 48 * 8), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(211))
  expect_equal(levels(offsets), as.character(c(211, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 13), rep(211, 48 * 1), rep(0, 48 * 18)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(20))
  expect_equal(levels(offsets), as.character(c(20, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(20, 48 * 17), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 21:23)
  expect_equal(levels(offsets), as.character(c(21:23, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 12), rep(21, 48 * 2), rep(22, 48 * 7),
      rep(23, 48 * 8), rep(0, 48 * 3)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(211))
  expect_equal(levels(offsets), as.character(c(211, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 13), rep(211, 48 * 1), rep(0, 48 * 18)))

  date_begin <- "2016-12-10"
  date_end   <- "2017-01-10"
  #(CET)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(20))
  expect_equal(levels(offsets), as.character(c(20, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 6), rep(20, 48 * 18), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 21:23)
  expect_equal(levels(offsets), as.character(c(21:23, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 6), rep(21, 48 * 8), rep(22, 48 * 7),
      rep(23, 48 * 3), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(211))
  expect_equal(levels(offsets), as.character(c(211, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(211, 48 * 7), rep(0, 48 * 18)))
  #(CET24)
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(20))
  expect_equal(levels(offsets), as.character(c(20, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 6), rep(20, 48 * 18), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = 21:23)
  expect_equal(levels(offsets), as.character(c(21:23, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 6), rep(21, 48 * 8), rep(22, 48 * 7),
      rep(23, 48 * 3), rep(0, 48 * 8)))
  offsets <- R39Toolbox::generate_offsets(data, offsets = c(211))
  expect_equal(levels(offsets), as.character(c(211, 0)))
  expect_equal(
    as.numeric(levels(offsets)[offsets]),
    c(rep(0, 48 * 7), rep(211, 48 * 7), rep(0, 48 * 18)))
})


test_that("Offsets (comparison with deprecated breaks functions)", {
  date_begin <- "2018-01-01"
  date_end   <- "2018-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 60 * 60, tz = "CET", variables = c("date", "Instant"))

  # generate_break_ERDF_2
  offsets_new <- R39Toolbox::generate_offsets(data, offsets = c(1, 2))
  expect_warning(
    offsets_old <- R39Toolbox::generate_break_ERDF_2(data),
    regexp = "deprecated")
  expect_equal(length(offsets_old), length(offsets_new))
  toto <- cbind(
    strftime(data$date, format = "%Y-%m-%d %H:%M:%S"),
    offsets_old,
    levels(offsets_new)[offsets_new])
  toto <- toto[-c(7203), ]  # bug in deprecated function
  map_values <- list("0" = "1", "1" = "2")
  for (x in names(map_values)) {
    expect_equal(unique(toto[toto[, 2] == x, 3]), map_values[[x]])
  }

  # generate_break_ERDF_11
  offsets_new <- R39Toolbox::generate_offsets(
    data, offsets = c(1, 2, 4, 11:15, 21:23))
  expect_warning(
    offsets_old <- R39Toolbox::generate_break_ERDF_11(data),
    regexp = "deprecated")
  expect_equal(length(offsets_old), length(offsets_new))
  toto <- cbind(
    strftime(data$date, format = "%Y-%m-%d %H:%M:%S"),
    offsets_old,
    levels(offsets_new)[offsets_new])
  toto <- toto[-c(7203), ]  # bug in deprecated function
  map_values <- list(
    "0" = "1", "1" = "2", "10" = "4",
    "5" = "11", "6" = "12", "7" = "13", "8" = "14", "9" = "15",
    "2" = "21", "3" = "22", "4" = "23")
  for (x in names(map_values)) {
    expect_equal(unique(toto[toto[, 2] == x, 3]), map_values[[x]])
  }
})


test_that("Marches", {
  ### (CET) + breaks as POSIXct
  dates <- c("2017-01-02 00:00:00", "2017-01-03 00:00:00")
  dates <- as.POSIXct(dates, format = "%Y-%m-%d %H:%M:%S", tz = "CET")
  # Full interval
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-04"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  marches <- R39Toolbox::generate_levels(data, dates)
  expect_equal(as.numeric(levels(marches)[marches]),
               c(rep(0, 48), rep(1, 48), rep(2, 48 * 2)))
  # Reduced interval
  date_begin <- "2017-01-03"
  date_end   <- "2017-01-04"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  marches2 <- R39Toolbox::generate_levels(data, dates)
  expect_equal(
    as.numeric(levels(marches2)[marches2]),
    as.numeric(levels(marches)[marches])[(48 * 2 + 1):length(marches)])
  # Reduced interval
  date_begin <- "2017-01-02"
  date_end   <- "2017-01-02"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  marches3 <- R39Toolbox::generate_levels(data, dates)
  expect_equal(as.numeric(levels(marches3)[marches3]), rep(1, 48))

  ### (CET) + breaks as character
  dates <- c("2017-01-02 00:00:00", "2017-01-03 00:00:00")
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-04"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  marches <- R39Toolbox::generate_levels(data, dates)
  expect_equal(as.numeric(levels(marches)[marches]),
               c(rep(0, 48), rep(1, 48), rep(2, 48 * 2)))

  ### (CET24) + breaks as character
  dates <- c("2017-01-02 00:00:00", "2017-01-03 00:00:00")
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-04"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  marches <- R39Toolbox::generate_levels(data, dates)
  expect_equal(as.numeric(levels(marches)[marches]),
               c(rep(0, 48), rep(1, 48), rep(2, 48 * 2)))

  ### (CET24) + breaks as POSIXct
  dates <- c("2017-01-02 00:00:00", "2017-01-03 00:00:00")
  dates <- as.POSIXct(dates, format = "%Y-%m-%d %H:%M:%S", tz = "CET")
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-04"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET24", variables = c("date", "Instant"))
  marches <- R39Toolbox::generate_levels(data, dates)
  expect_equal(as.numeric(levels(marches)[marches]),
               c(rep(0, 48), rep(1, 48), rep(2, 48 * 2)))
})


test_that("Trends", {
  ### Nominal case
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-08"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  breaks <- c("2017-01-02 00:00:00", "2017-01-05 00:00:00")
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, c(rep(0:3, each = 48), rep(1:4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(1, 0))
  expect_equal(slopes, c(rep(0:3, each = 48), rep(0, 48 * 4)))
  # with slopes
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 4))
  expect_equal(slopes, c(rep(0:3 * 2, each = 48), rep(1:4 * 4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 0))
  expect_equal(slopes, c(rep(0:3 * 2, each = 48), rep(0, 48 * 4)))
  # continous
  slopes <- R39Toolbox::generate_slopes(data, breaks, continuous = TRUE)
  expect_equal(slopes, c(rep(0:3, each = 48), rep(1:4, each = 48) + 3))

  ### Case where the dataset starts after the first break
  date_begin <- "2017-01-05"
  date_end   <- "2017-01-08"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  breaks <- c("2017-01-02 00:00:00", "2017-01-05 00:00:00")
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, rep(1:4, each = 48))
  slopes <- R39Toolbox::generate_slopes(data, breaks, continuous = TRUE)
  expect_equal(slopes, rep(1:4, each = 48) + 3)
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(1, 0))
  expect_equal(slopes, rep(0, each = 48 * 4))

  ### One break case
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-05"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  breaks <- c("2017-01-02 00:00:00")
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, rep(c(0, 1:4), each = 48))

  ### Missing dates case
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-08"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  mask <- which(as.numeric(strftime(data$date, format = "%d")) == 3)
  data <- data[-mask, ]
  breaks <- c("2017-01-02 00:00:00", "2017-01-05 00:00:00")
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, c(rep(c(0, 1, 3), each = 48), rep(1:4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(1, 0))
  expect_equal(slopes, c(rep(c(0, 1, 3), each = 48), rep(0, 48 * 4)))
  # with slopes
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 4))
  expect_equal(slopes, c(rep(c(0, 1, 3) * 2, each = 48),
                         rep(1:4 * 4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 0))
  expect_equal(slopes, c(rep(c(0, 1, 3) * 2, each = 48),
                         rep(0, 48 * 4)))
  # continous
  slopes <- R39Toolbox::generate_slopes(data, breaks, continuous = TRUE)
  expect_equal(slopes, c(rep(c(0, 1, 3), each = 48), rep(1:4, each = 48) + 3))

  ### UTC timezone
  date_begin <- "2017-01-01"
  date_end   <- "2017-01-08"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  breaks <- c("2017-01-02 00:00:00", "2017-01-05 00:00:00")
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, c(rep(0:3, each = 48), rep(1:4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(1, 0))
  expect_equal(slopes, c(rep(0:3, each = 48), rep(0, 48 * 4)))
  # with slopes
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 4))
  expect_equal(slopes, c(rep(0:3 * 2, each = 48), rep(1:4 * 4, each = 48)))
  slopes <- R39Toolbox::generate_slopes(data, breaks, slopes = c(2, 0))
  expect_equal(slopes, c(rep(0:3 * 2, each = 48), rep(0, 48 * 4)))
  # continous
  slopes <- R39Toolbox::generate_slopes(data, breaks, continuous = TRUE)
  expect_equal(slopes, c(rep(0:3, each = 48), rep(1:4, each = 48) + 3))
  # missing values
  mask <- which(
    as.numeric(strftime(data$date, format = "%d", tz = 'UTC')) == 3)
  data <- data[-mask, ]
  slopes <- R39Toolbox::generate_slopes(data, breaks)
  expect_equal(slopes, c(rep(c(0, 1, 3), each = 48), rep(1:4, each = 48)))
})
