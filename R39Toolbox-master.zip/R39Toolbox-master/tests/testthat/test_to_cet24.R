context("to_cet24 tests")

tz <- "CET"

date.begin <- "2010/10/30 23:00:00"
date.end <- "2010/10/31 03:00:00"
date <- seq.POSIXt(as.POSIXct(date.begin, tz=tz), as.POSIXct(date.end, tz=tz),
                   by="10 min")
data.oct <- data.frame(date=date, value=rnorm(length(date)))

date.begin <- "2010/03/27 22:00:00"
date.end <- "2010/03/28 03:50:00"
date <- seq.POSIXt(as.POSIXct(date.begin, tz=tz), as.POSIXct(date.end, tz=tz),
                   by="10 min")
data.mars <- data.frame(date=date, value=rnorm(length(date)))


test_that("to_cet24 results", {
  res <- to_cet24(data.oct, 1)
  expect_equal(nrow(data.oct) - 6, nrow(res))
  expect_is(res$date, "CET24")

  expect_equal(setdiff(res$value, data.oct$value), numeric(0))
  expect_equal(length(setdiff(data.oct$value, res$value)), 6)
  expect_false(any(duplicated(as.character(res$date))))

  res <- to_cet24(data.mars, 1)
  expect_equal(nrow(data.mars) + 6, nrow(res))
  expect_is(res$date, "CET24")

  expect_equal(setdiff(res$value, data.mars$value), numeric(0))
  expect_equal(setdiff(data.mars$value, res$value), numeric(0))
  expect_false(any(duplicated(as.character(res$date))))
})


# issue #17
test_that("to_cet24 does not accept NULL data", {
  data.err <- data.oct
  data.err$date[[1]] <- "NULL"
  expect_error(to_cet24(data.err, 1))
})

# issue #16
test_that("to_cet24 works with ind_date != 1", {
  data <- generate_calendar(
    date_begin = as.POSIXct("2018-01-01 00:00:00", tz = "CET"),
    date_end   = as.POSIXct("2018-12-31 23:30:00", tz = "CET"),
    ts = 30 * 60,
    variables = c("date")
  )
  data$valeur <- 1:nrow(data)
  data_inverse <- data[, c(2, 1)]
  data_new <- to_cet24(data = data_inverse, ind_date = 2)  # no error expected

  expect_equal(dim(data), dim(data_new))
})
