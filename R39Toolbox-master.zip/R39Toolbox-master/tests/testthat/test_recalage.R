context("Fonction de recalage tests")

#chargement des jeux de donnees
res <- readRDS("test_recalage_res.rds")
simu <- readRDS("test_recalage_simu.rds")
#chargement du fichier stf_opt pour l'hebdo
stf_opt_hebdo <- readRDS("test_recalage_param_stf.rds")
#chargement du fichier stf_opt_infra pour l'infra
stf_opt_infra <- readRDS("test_recalage_param_stf_indra.rds")
#chargement du fichier de ref pour les resultats hebdo
res_hebdo <- readRDS("test_recalage_hebdo_resultats.rds")
#chargement du fichier de ref pour les resultats infra
res_infra <- readRDS("test_recalage_infra_resultats.rds")

test_that("recalage hebdo", {
  res_prevision_toolbox <-
    R39Toolbox::eventailPrevisionCourtTerme(
      data = simu,
      resultats = res,
      STFparameters = stf_opt_hebdo,
      byDayType = 0,
      type_recalage = "hebdo"
    )
  testthat::expect_equal(res_prevision_toolbox$ShortTermForecast,
               res_hebdo,
               tolerance = 1e-4)
})

test_that("recalage infra", {
  recal <-
    transform(simu, ShortTermForecast = res$EstimatedLoad)
  #comme les donnees sont issus d'un recalage hebdo on met des Load a 0
  taille_donnees <- nrow(recal)
  recal$Load[4656:taille_donnees] <- 0
  simu$Load[4656:taille_donnees] <- 0
  
  res_prevision_toolbox <-
    R39Toolbox::eventailPrevisionCourtTerme(
      data = simu,
      resultats = recal,
      STFparameters = stf_opt_infra,
      type_recalage = "infra"
    )
  prev_infra <-
    R39Toolbox::remplitPCTapres(
      donnees = res_prevision_toolbox,
      resultats = recal,
      start = 4656,
      CoeffDeRecopie = 0.29
    )
  testthat::expect_equal(prev_infra$ShortTermForecast,
               res_infra,
               tolerance = 1e-4)
  })
