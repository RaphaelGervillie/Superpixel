context("gam_effects tests")


require(mgcv)
model <- gam(conso ~ s(Temperature) + TypeJour7 + Posan,
             data = R39ExData[1:10000, ])


test_that("multiplyByCoefficients on gam model", {
  temp.effect <- round(stats::predict(model, type = "terms",
                                      terms = "s(Temperature)")[, 1], 4)

  via.dataEffect <- get_model_effects(model, type = "lpmatrix")
  via.dataEffect <- scale_effects(model, via.dataEffect)
  temp.effect2 <- round(
    rowSums(via.dataEffect[, grep("effect.fit.s(Temperature)",
                                  colnames(via.dataEffect),
                                  fixed = TRUE)]), 4)

  expect_identical(temp.effect, temp.effect2)
})

