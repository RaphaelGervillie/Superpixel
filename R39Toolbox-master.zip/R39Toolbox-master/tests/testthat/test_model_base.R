data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL

##########################
# Linear Model
##########################
context("Linear model tests")

# 1. Init/fit/predict model
# 2. Same but use weights
test_that("Linear models", {
  # init
  model1 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan")
  expect_true("LinearModel" %in% class(model1))

  # fit
  # model1 fit normally
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut)
  expect_true("LinearModel" %in% class(model1))
  expect_true(!is.null(model1$model_))
  # fit with weights
  model1_1 <- R39Toolbox::fit(model1, data, weights = weights)
  expect_equal(model1$model_$coefficients, model1_1$model_$coefficients)

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data)
  expect_equal(prediction1, simulation1)

  # rmse
  # score1 computed directly
  # score1_1 computed using weights
  score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
  expect_equal(score1_1, score1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})

# 1. Init/fit/predict model *by factor*
# 2. Same but use weights
test_that("Linear models by factor", {
  # init
  model1 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan")
  expect_true("LinearModel" %in% class(model1))
  # model2 = model1 with by = 'Instant' by default
  model2 <- R39Toolbox::LinearModel(formula = "conso ~ Temperature + Posan",
                                    fit_default = list(by = "Instant"))

  # fit
  # model1 fit by Instant
  # model2 too, but using default
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut, by = 'Instant')
  expect_true("LinearModel" %in% class(model1))
  expect_true(!is.null(model1$model_))
  # fit with weights
  model1_1 <- R39Toolbox::fit(model1, data, by = 'Instant', weights = weights)
  expect_equal(model1$model_$coefficients, model1_1$model_$coefficients)
  # fit with default 'by' option
  model2 <- R39Toolbox::fit(model2, data_cut)
  expect_equal(length(model2$model_), length(model1$model_))
  expect_equal(model2$model_[[1]]$coefficients, model1$model_[[1]]$coefficients)

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data)
  expect_equal(prediction1, simulation1)

  # rmse
  # score1 computed directly
  # score1_1 computed using weights
  score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
  expect_equal(score1_1, score1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})

# 1. Init/fit/predict model *with prior transformation function*
test_that("Linear model with transform", {
  # init
  model1 <- R39Toolbox::LinearModel(
    formula = "conso ~ Temperature + Posan",
    transformation_function = transformation_function)
  expect_true("LinearModel" %in% class(model1))

  # fit
  model1 <- R39Toolbox::fit(model1, data_cut_alt)
  model1_bis <- R39Toolbox::fit(model1, data_cut, bypass_transform = TRUE)
  expect_true("LinearModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  # predict
  prediction1     <- predict(model1, data_alt)
  prediction1_bis <- predict(model1, data, bypass_transform = TRUE)
  prediction1_ter <- predict(model1_bis, data, bypass_transform = TRUE)
  expect_equal(length(prediction1), length(data_alt$conso))
  expect_equal(class(prediction1), "numeric")
  expect_equal(prediction1, prediction1_bis)
  expect_equal(prediction1, prediction1_ter)
  # simulation
  simulation1     <- R39Toolbox::simulate(model1, data_alt)
  simulation1_bis <- R39Toolbox::simulate(model1, data, bypass_transform = TRUE)
  simulation1_ter <- R39Toolbox::simulate(model1_bis, data, bypass_transform = TRUE)
  expect_equal(simulation1, prediction1)
  expect_equal(simulation1_bis, prediction1_bis)
  expect_equal(simulation1_ter, prediction1_ter)
})


##########################
# Generalized Additive Model
##########################
context("GAM model tests")

# 1. Init/fit/predict model
# 2. Same but use weights
test_that("GAM models", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  expect_true("GeneralizedAdditiveModel" %in% class(model1))

  # fit
  # model1 fit normally
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut)
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  expect_true(!is.null(model1$model_))
  # fit with weights
  # small differences due to optimisation algorithm
  model1_1 <- R39Toolbox::fit(model1, data, weights = weights)
  expect_lt(abs(mean(model1$model_$coefficients
                     - model1_1$model_$coefficients)),
            abs(mean(model1$model_$coefficients)))

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  target_period    <- rep(1, nrow(data))
  target_period[1] <- 0
  prediction2 <- predict(model1, data, leading_period = 1 - target_period)
  expect_equal(length(prediction2), length(data$conso) - 1)
  expect_equal(class(prediction2), "numeric")
  expect_equal(prediction2, prediction1[2:length(prediction1)])
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data)
  expect_equal(prediction1, simulation1)

  # rmse
  # score1 computed directly
  # score1_1 computed using weights
  score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
  expect_equal(score1_1, score1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})


# 1. Init/fit/predict model *by factor*
# 2. Same but use weights
# 3. Check 'simulate' and 'predict' are equal
# 4. Check 'leading_period' is taken into account
test_that("GAM models by factor", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  # model2 = model1 with by = 'Instant' by default
  model2 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan",
    fit_default = list(by = 'Instant'))

  # fit
  # model1 fit by Instant
  # model2 too, but using default
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut, by = 'Instant')
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  expect_true(!is.null(model1$model_))
  # fit with weights
  # small differences due to optimisation algorithm
  model1_1 <- R39Toolbox::fit(model1, data, by = 'Instant', weights = weights)
  expect_equal(length(model1$model_), length(model1_1$model_))
  expect_lt(abs(mean(model1$model_[[1]]$model_$coefficients
                     - model1_1$model_[[1]]$model_$coefficients)),
            0.05 * abs(mean(model1$model_[[1]]$model_$coefficients)))
  # fit with default 'by' option
  # small differences due to optimisation algorithm
  model2 <- R39Toolbox::fit(model2, data_cut)
  expect_equal(length(model2$model_), length(model1$model_))
  expect_lt(abs(mean(model1$model_[[1]]$model_$coefficients
                     - model2$model_[[1]]$model_$coefficients)),
            0.05 * abs(mean(model1$model_[[1]]$model_$coefficients)))

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data)
  expect_equal(prediction1, simulation1)

  # predict with leading_period
  target_period    <- rep(1, nrow(data))
  target_period[1] <- 0
  prediction2 <- predict(model1, data, leading_period = 1 - target_period)
  expect_equal(length(prediction2), length(data$conso) - 1)
  expect_equal(class(prediction2), "numeric")
  expect_equal(prediction2, prediction1[2:length(prediction1)])
  # simulate with target_period
  simulation2 <- R39Toolbox::simulate(
    model1, data, leading_period = 1 - target_period)
  expect_equal(prediction2, simulation2)

  # rmse
  # score1 computed directly
  # score1_1 computed using weights
  score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
  expect_equal(score1_1, score1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})


# 1. Init/fit/predict model *with prior transformation function*
test_that("GAM model with transform", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan",
    transformation_function = transformation_function)
  expect_true("GeneralizedAdditiveModel" %in% class(model1))

  # fit
  model1 <- R39Toolbox::fit(model1, data_cut_alt)
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  # predict
  prediction1 <- predict(model1, data_alt)
  expect_equal(length(prediction1), length(data_alt$conso))
  expect_equal(class(prediction1), "numeric")
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data_alt)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data_alt)
  expect_equal(prediction1, simulation1)
})


## ##########################
## # Gradient Boosting Model
## ##########################
## context("GBM model tests")

## # 1. Init/fit/predict model
## # 2. Same but use weights
## test_that("GBM models", {
##   # init
##   model1 <- R39Toolbox::GradientBoostingModel(
##     target_variable = 'conso',
##     explanatory_variables = c('Temperature', 'Posan'))
##   expect_true("GradientBoostingModel" %in% class(model1))

##   # fit
##   # model1 fit normally
##   # model1_1 fit with weights
##   model1 <- R39Toolbox::fit(model1, data_cut)
##   expect_true("GradientBoostingModel" %in% class(model1))
##   expect_true(!is.null(model1$model_))
##   # fit with weights
##   model1_1 <- R39Toolbox::fit(model1, data, weights = weights)
##   expect_equal(model1$model_, model1_1$model_)

##   # predict
##   prediction1 <- predict(model1, data)
##   expect_equal(length(prediction1), length(data$conso))
##   expect_equal(class(prediction1), "numeric")

##   # rmse
##   # score1 computed directly
##   # score1_1 computed using weights
##   score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
##   expect_equal(class(score1), "numeric")
##   expect_equal(length(score1), 1)
##   score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
##   expect_equal(score1, score1_1)
##   # mape
##   score2 <- R39Toolbox::score(model1, data, data$conso,
##                               type = R39Toolbox::mape)
##   expect_equal(class(score2), "numeric")
##   expect_equal(length(score2), 1)
## })


## # 1. Init/fit/predict model *by factor*
## # 2. Same but use weights
## test_that("GBM models by factor", {
##   # init
##   model1 <- R39Toolbox::GradientBoostingModel(
##     target_variable = 'conso',
##     explanatory_variables = c('Temperature', 'Posan'))
##   expect_true("GradientBoostingModel" %in% class(model1))
##   model2 <- R39Toolbox::GradientBoostingModel(
##     target_variable = 'conso',
##     explanatory_variables = c('Temperature', 'Posan'),
##     fit_default = list(by = 'Instant'))

##   # fit
##   # model1 fit by Instant
##   # model2 too, but using default
##   # model1_1 fit with weights
##   model1 <- R39Toolbox::fit(model1, data_cut, by = 'Instant')
##   expect_true("GradientBoostingModel" %in% class(model1))
##   expect_true(!is.null(model1$model_))
##   model1_1 <- R39Toolbox::fit(model1, data, by = 'Instant')
##   # expect_equal(model1$model_, model1_1$model_)
##   # fit with default 'by' option
##   model2 <- R39Toolbox::fit(model2, data_cut)
##   # expect_equal(model1$model_, model2$model_)

##   # predict
##   prediction1 <- predict(model1, data)
##   expect_equal(length(prediction1), length(data$conso))
##   expect_equal(class(prediction1), "numeric")

##   # rmse
##   # score1 computed directly
##   # score1_1 computed using weights
##   score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
##   expect_equal(class(score1), "numeric")
##   expect_equal(length(score1), 1)
##   score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
##   expect_equal(score1, score1_1)
##   # mape
##   score2 <- R39Toolbox::score(model1, data, data$conso,
##                               type = R39Toolbox::mape)
##   expect_equal(class(score2), "numeric")
##   expect_equal(length(score2), 1)
## })


## ##########################
## # Random Forest Model
## ##########################
## context("RF model tests")

## mask_data_light <- as.numeric(as.character(data$Instant)) < 3
## data_light      <- data[mask_data_light, ]
## weights_light   <- weights[mask_data_light]
## data_light_cut  <- data_light[weights_light == 1, ]

## # 1. Init/fit/predict model
## # 2. Same but use weights
## test_that("RF models", {
##   model1 <- R39Toolbox::RandomForestModel(
##     formula = "conso ~ Temperature + Posan")
##   expect_true("RandomForestModel" %in% class(model1))

##   model1 <- R39Toolbox::fit(model1, data_light)
##   expect_true("RandomForestModel" %in% class(model1))
##   expect_true(!is.null(model1$model_))

##   prediction1 <- predict(model1, data_light)
##   expect_equal(length(prediction1), length(data_light$conso))
##   expect_equal(class(prediction1), "numeric")

##   # rmse
##   score1 <- R39Toolbox::score(model1, data_light, data_light$conso)
##   expect_equal(class(score1), "numeric")
##   expect_equal(length(score1), 1)
##   # mape
##   score2 <- R39Toolbox::score(model1, data_light, data_light$conso,
##                               type = R39Toolbox::mape)
##   expect_equal(class(score2), "numeric")
##   expect_equal(length(score2), 1)
## })


## # 1. Init/fit/predict model *by factor*
## # 2. Same but use weights
## test_that("RF models by factor", {
##   # init
##   model1 <- R39Toolbox::RandomForestModel(
##     formula = "conso ~ Temperature + Posan")
##   expect_true("RandomForestModel" %in% class(model1))
##   model2 <- R39Toolbox::RandomForestModel(
##     formula = "conso ~ Temperature + Posan",
##     fit_default = list(by = 'Instant'))

##   # fit
##   # model1 fit by Instant
##   # model2 too, but using default
##   # model1_1 fit with weights
##   model1 <- R39Toolbox::fit(model1, data_light_cut, by = 'Instant')
##   expect_true("RandomForestModel" %in% class(model1))
##   expect_true(!is.null(model1$model_))
##   model1_1 <- R39Toolbox::fit(model1, data_light, by = 'Instant', weights = weights_light)
##   # expect_equal(model1$model_, model1_1$model_)
##   # fit with default 'by' option
##   model2 <- R39Toolbox::fit(model2, data_light_cut)
##   # expect_equal(model1$model_, model2$model_)

##   # predict
##   prediction1 <- predict(model1, data_light)
##   expect_equal(length(prediction1), length(data_light$conso))
##   expect_equal(class(prediction1), "numeric")

##   # rmse
##   # score1 computed directly
##   # score1_1 computed using weights
##   score1 <- R39Toolbox::score(model1, data_light_cut, data_light_cut$conso)
##   expect_equal(class(score1), "numeric")
##   expect_equal(length(score1), 1)
##   score1_1 <- R39Toolbox::score(model1, data_light, data_light$conso, weights = weights_light)
##   expect_equal(score1, score1_1)
##   # mape
##   score2 <- R39Toolbox::score(model1, data_light, data_light$conso,
##                               type = R39Toolbox::mape)
##   expect_equal(class(score2), "numeric")
##   expect_equal(length(score2), 1)
## })
