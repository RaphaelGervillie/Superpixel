context("Simulations (mixture)")

data <- R39Toolbox::R39ExData
data$Var1 <- as.factor(as.numeric(data$Instant < 12))
data$Instant <- as.factor(data$Instant)

test_that("Mixture 'per factor'", {
  # Model initialisation
  # auxillary models
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  # check API robustness
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data, weights = rep(1, nrow(data)))
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature) + TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  # final list
  model <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso',
    fit_default = list(by = 'Var1'))
  suppressWarnings(model1 <- R39Toolbox::fit(model, data))

  ### Fixed-weights (predict)
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  suppressWarnings(
    simulation1 <- R39Toolbox::simulate(
      model1, data, update_frequency = 0, launch_frequency = 10000000))
  expect_equal(simulation1, prediction1)

  ### Online mode (simulate)
  data_no_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-01 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_1 <- R39Toolbox::fit(model, data_no_december2014))
  data_december2014 <- data[
    data$date >= as.POSIXct(
      "2014-11-26 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(
    simulation1_1 <- R39Toolbox::simulate(model1_1, data_december2014))
  suppressWarnings(
    simulation1_2 <- R39Toolbox::simulate(
      model1_1, data_december2014, update_frequency = 24, launch_frequency = 24))
  #
  suppressWarnings(
    simulation1_2_2 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      update_frequency = 24, launch_frequency = 24, horizon = 12))
  expect_true(all(is.na(simulation1_2_2[1:12])))
  expect_equal(simulation1_2_2[13:24], simulation1_2[13:24])
  expect_equal(simulation1_2_2[37:48], simulation1_2[37:48])
  #
  suppressWarnings(
    simulation1_3 <- R39Toolbox::simulate(
      model1_1, data_december2014,
      update_frequency = data_december2014$date[as.numeric(strftime(
        data_december2014$date, format = "%H", tz = 'UTC')) == 8]))
  expect_equal(simulation1_1[[1]], simulation1_2[[1]])
  expect_equal(simulation1_2, simulation1_3)
  prediction1_1 <- predict(model1_1, data_december2014)
  #
  data_no_december2014_2 <- data[
    data$date >= as.POSIXct(
      "2014-11-01 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-27 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_2 <- R39Toolbox::fit(model, data_no_december2014_2))
  data_december2014_2 <- data[
    data$date >= as.POSIXct(
      "2014-11-27 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  prediction1_2 <- predict(model1_2, data_december2014_2)
  #
  data_no_december2014_3 <- data[
    data$date >= as.POSIXct(
      "2014-11-01 00:00", format = "%Y-%m-%d %H:%M", tz = "UTC") &
      data$date < as.POSIXct(
        "2014-11-28 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  suppressWarnings(model1_3 <- R39Toolbox::fit(model, data_no_december2014_3))
  data_december2014_3 <- data[
    data$date >= as.POSIXct(
      "2014-11-28 08:00", format = "%Y-%m-%d %H:%M", tz = "UTC"), ]
  prediction1_3 <- predict(model1_3, data_december2014_3)
  expect_equal(prediction1_1[[1]], simulation1_1[[1]])
  expect_false(all(prediction1_1 == simulation1_1))
  expect_equal(prediction1_1[1:24], simulation1_2[1:24])
  expect_equal(prediction1_2[1:24], simulation1_2[25:48])
  expect_equal(prediction1_3[1:24], simulation1_2[49:72])
})


test_that("Mixture models with history", {
  # load data
  data <- R39Toolbox::R39ExData
  data$Instant <- as.factor(data$Instant)
  cut0 <- 15000
  cut1 <- 25000
  cut2 <- 24800
  data_cut0 <- data[1:cut0, ]
  data_cut <- data[1:cut1, ]
  data_cut2 <- data[1:cut2, ]

  # init
  model_mid_term1 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ s(Temperature)')
  model_mid_term1 <- R39Toolbox::fit(model_mid_term1, data)
  model_mid_term2 <- R39Toolbox::GeneralizedAdditiveModel(
    'conso ~ TypeJour7')
  model_mid_term2 <- R39Toolbox::fit(model_mid_term2, data)
  model1 <- R39Toolbox::MixtureModel(
    list(model_mid_term1, model_mid_term2), 'conso')
  model_for_simulate <- model1
  model_for_simulate_DOAAT <- model1

  # fit normally
  suppressWarnings(model1_DOAAT <- R39Toolbox::fit(model1, data_cut, hist = TRUE))
  suppressWarnings(model1 <- R39Toolbox::fit(model1, data_cut2, hist = TRUE))
  suppressWarnings(
    model1_bis <- R39Toolbox::fit(
      model1, tail(data_cut, cut1 - cut2), hist = TRUE))
  suppressWarnings(model1 <- R39Toolbox::fit(model1, data_cut, hist = TRUE))
  # fit through simulate
  suppressWarnings(
    res_simulate_fit <- simulate(
      model_for_simulate, data,
      update_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      verbose = TRUE, output_model = TRUE, save_history = TRUE))
  model_for_simulate  <- res_simulate_fit$model
  prediction_simulate <- res_simulate_fit$simulation
  # (DOAAT's version)
  suppressWarnings(
    res_simulate_fit_DOAAT <- simulate_DOAAT(
      model_for_simulate_DOAAT, data,
      update_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      verbose = TRUE, output_model = TRUE, save_history = TRUE))
  model_for_simulate_DOAAT  <- res_simulate_fit_DOAAT$model
  prediction_simulate_DOAAT <- res_simulate_fit_DOAAT$simulation

  # Prediction (already tested in test_model_ar.R) so no test is added
  # predict
  prediction1 <- predict(model1, data)
  prediction1_DOAAT <- predict(model1_DOAAT, data)
  prediction1_bis <- predict(model1_bis, data)
  expect_warning(
    prediction2 <- predict(model1, data, predict_as_date = data$date[[1]]))
  prediction3 <- predict(
    model1, data,
    predict_as_date = data$date[[(cut2 + cut1) / 2]])
  # Prediction through simulate (= the main purpose of this test)
  # 1. with history use
  suppressWarnings(
    res_simulate_predict <- simulate(
      model_for_simulate, data,
      update_frequency = 100000000,
      launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      verbose = TRUE,
      output_model = FALSE, save_history = FALSE, use_history = TRUE))
  expect_equal(prediction_simulate, res_simulate_predict)
  mask_test <- 1:cut2
  expect_equal(prediction_simulate[mask_test], prediction2[mask_test])
  mask_test <- (cut2 + 1):cut1
  expect_equal(prediction_simulate[mask_test], prediction3[mask_test])
  mask_test <- (cut1 + 1):nrow(data)
  expect_equal(prediction_simulate[mask_test], prediction1_bis[mask_test])

  # 2. without history use
  suppressWarnings(
    res_simulate_predict <- simulate(
      model_for_simulate, data,
      update_frequency = 100000000,
      launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      verbose = TRUE,
      output_model = FALSE, save_history = FALSE, use_history = FALSE))
  expect_equal(res_simulate_predict, prediction1_bis)
  suppressWarnings(
    res_simulate_predict_DOAAT <- simulate_DOAAT(
      model_for_simulate_DOAAT, data,
      update_frequency = 100000000,
      launch_frequency = c(data$date[[cut2 + 1]], data$date[[cut1 + 1]]),
      verbose = TRUE,
      output_model = FALSE, save_history = FALSE, use_history = FALSE))
  expect_equal(res_simulate_predict_DOAAT, prediction1_DOAAT)
})
