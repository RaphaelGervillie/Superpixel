##########################
# Autoregressive Model
##########################
context("Autoregressive model tests")

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
weights <- rep(1, nrow(data))
weights[1:(30 * 4)] <- 0
data_cut <- data[weights == 1, ]
data_cut2 <- data_cut[1:(nrow(data_cut) - 60), ]

transformation_function <- function(data) {
  data$Temperature <- data$Temperature2
  data$Temperature2 <- NULL
  data
}
data_cut_alt <- data_cut
data_cut_alt$Temperature2 <- data_cut_alt$Temperature
data_cut_alt$Temperature  <- NULL
data_alt <- data
data_alt$Temperature2 <- data_alt$Temperature
data_alt$Temperature  <- NULL


test_that("Autoregressive models (lag 1)", {
  # init
  model1 <- R39Toolbox::AutoRegressiveModel(target_variable = 'conso',
                                            lags = c(1))
  expect_true("AutoRegressiveModel" %in% class(model1))

  # fit
  model1$coefficients_ <- c(0.5)
  model1$model_ <- "fit->ok"

  # predict
  prediction1 <- predict(
    model1, data,
    leading_period = c(rep(1, 1), rep(0, nrow(data) - 1)))
  expect_equal(length(prediction1), length(data$conso) - 1)
  expect_equal(class(prediction1), "numeric")
  expect_equal(prediction1[[1]], 0.5 * data$conso[[1]])

  # simulation
  simulation1 <- R39Toolbox::simulate(
    model1, data[1:5, ],
    leading_period = c(rep(1, 1), rep(0, nrow(data[1:5, ]) - 1)),
    update_frequency = 10, launch_frequency = 1)
  expect_equal(simulation1, 0.5 * data$conso[1:4])
  simulation1_2 <- R39Toolbox::simulate(
    model1, data[1:5, ],
    leading_period = c(rep(1, 1), rep(0, nrow(data[1:5, ]) - 1)),
    update_frequency = 10, launch_frequency = 10)
  expect_equal(
    simulation1_2,
    c(0.5 * data$conso[[1]],
      0.25 * data$conso[[1]],
      0.125 * data$conso[[1]],
      0.0625 * data$conso[[1]]))

  # rmse
  score1 <- R39Toolbox::score(
    model1, data_cut, data_cut$conso,
    leading_period = c(rep(1, 1), rep(0, nrow(data) - 1)))
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
})


test_that("Autoregressive models (several lags)", {
  # init
  model1 <- R39Toolbox::AutoRegressiveModel(lags = c(1, 3),
                                            target_variable = 'conso')
  expect_true("AutoRegressiveModel" %in% class(model1))

  # fit
  model1$coefficients_ <- c(0.5, 0.5)
  model1$model_ <- "fit->ok"

  model2 <- R39Toolbox::fit(
    model1, data,
    leading_period = c(rep(1, 3), rep(0, nrow(data) - 3)))
  expect_equal(sum(model2$coefficients_), 1, tol = 1e-2)

  # predict
  prediction1 <- predict(
    model1, data,
    leading_period = c(rep(1, 3), rep(0, nrow(data) - 3)))
  expect_error(predict(model1, data))
  expect_equal(length(prediction1), length(data$conso) - 3)
  expect_equal(class(prediction1), "numeric")
})


test_that("Autoregressive models (lag auto)", {
  # init
  model1 <- R39Toolbox::AutoRegressiveModel(target_variable = 'conso',
                                            lags = 'auto')
  expect_true("AutoRegressiveModel" %in% class(model1))

  # fit
  model1 <- R39Toolbox::fit(model1, data, leading_period = 1 - weights)

  # predict
  prediction1 <- predict(model1, data, leading_period = 1 - weights)
  expect_equal(length(prediction1), length(which(weights == 1)))
  expect_equal(class(prediction1), "numeric")
})


#######################################
# Generalized Additive Model Adaptative
#######################################
context("Adaptative GAM model tests")

test_that("Adaptative GAM models and predict_details", {
  # init
  model_gam <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  model_gam <- R39Toolbox::fit(model_gam, data_cut)
  model1 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_gam,
    fixed_global_effects = c("s(Temperature)", "(Intercept)"),
    mu = 0.95)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))
  model2 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_gam,
    fixed_global_effects = c("s(Temperature)"),
    mu = 0.95)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model2))

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(prediction1, predict(model_gam, data))
  prediction2 <- predict(model2, data)
  expect_equal(prediction2, predict(model_gam, data))

  # fit
  # model1 fit normally
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))
  expect_true(!is.null(model1$model_))
  model2 <- R39Toolbox::fit(model2, data_cut)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model2))
  expect_true(!is.null(model2$model_))

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  target_period    <- rep(1, nrow(data))
  target_period[1] <- 0
  prediction1_2 <- predict(model1, data, leading_period = 1 - target_period)
  expect_equal(length(prediction1_2), length(data$conso) - 1)
  expect_equal(class(prediction1_2), "numeric")
  expect_equal(prediction1_2, prediction1[2:length(prediction1)])
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))

  # predict 2
  prediction2 <- predict(model2, data)
  expect_equal(length(prediction2), length(data$conso))
  expect_equal(class(prediction2), "numeric")
  target_period    <- rep(1, nrow(data))
  target_period[1] <- 0
  prediction2_2 <- predict(model2, data, leading_period = 1 - target_period)
  expect_equal(length(prediction2_2), length(data$conso) - 1)
  expect_equal(class(prediction2_2), "numeric")
  expect_equal(prediction2_2, prediction2[2:length(prediction2)])
  # predict with detailed effects
  prediction2_1 <- R39Toolbox::predict_details(model2, data)
  expect_equal(prediction2, as.numeric(rowSums(prediction2_1)))

  #init GAM by factor
  model_gam_by_factor <- R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan",
      fit_default = list(by = "Instant"))
  #init GAM by factor with transformation function
  model_gam_by_factor_transform <- R39Toolbox::GeneralizedAdditiveModel(
      formula = "conso ~ s(Temperature) + Posan",
      fit_default = list(by = "Instant"),
      transformation_function = transformation_function)
  #fit GAM by factor (default)
  model_gam_by_factor <- R39Toolbox::fit(model_gam_by_factor, data_cut)
  #fit GAM by factor with transformation function (default)
  model_gam_by_factor_transform <- R39Toolbox::fit(model_gam_by_factor_transform, data_cut_alt)
  #init GAM adapt by factor
  model3 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
      model_gam_by_factor,
      fixed_global_effects = c("s(Temperature)", "(Intercept)"),
      mu = 0.95,
      fit_default = list(by = 'Instant'))
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model3))
  #init GAM adapt by factor with transformation function
  model4 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
      model_gam_by_factor_transform,
      fixed_global_effects = c("s(Temperature)", "(Intercept)"),
      mu = 0.95,
      fit_default = list(by = 'Instant'),
      transformation_function = transformation_function)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model4))
  #predict
  prediction3 <- predict(model3, data)
  expect_equal(prediction3, predict(model_gam_by_factor, data))
  prediction4 <- predict(model4, data_alt)
  expect_equal(prediction4, predict(model_gam_by_factor_transform, data_alt))
  #predict with detailed effects
  prediction3_1 <- R39Toolbox::predict_details(model3, data)
  expect_equal(prediction3, as.numeric(rowSums(prediction3_1)))
  prediction4_1 <- R39Toolbox::predict_details(model4, data_alt)
  expect_equal(prediction4, as.numeric(rowSums(prediction4_1)))
  #simulate ####SIMULATE MIGHT NEED AN UPDATED####
  #simulation3 <- R39Toolbox::simulate(model3, data)
  #expect_equal(prediction3, simulation3)
  #simulation4 <- R39Toolbox::simulate(model4, data_alt)
  #expect_equal(prediction4, simulation4)
})


# 1. Init/fit/predict model *by factor*
# 2. Same but use weights
# 3. Check 'simulate' and 'predict' are equal
# 4. Check 'leading_period' is taken into account
test_that("GAM models by factor", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  # model2 = model1 with by = 'Instant' by default
  model2 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan",
    fit_default = list(by = 'Instant'))

  # fit
  # model1 fit by Instant
  # model2 too, but using default
  # model1_1 fit with weights
  model1 <- R39Toolbox::fit(model1, data_cut, by = 'Instant')
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  expect_true(!is.null(model1$model_))
  # fit with weights
  # small differences due to optimisation algorithm
  model1_1 <- R39Toolbox::fit(model1, data, by = 'Instant', weights = weights)
  expect_equal(length(model1$model_), length(model1_1$model_))
  expect_lt(abs(mean(model1$model_[[1]]$model_$coefficients
                     - model1_1$model_[[1]]$model_$coefficients)),
            0.05 * abs(mean(model1$model_[[1]]$model_$coefficients)))
  # fit with default 'by' option
  # small differences due to optimisation algorithm
  model2 <- R39Toolbox::fit(model2, data_cut)
  expect_equal(length(model2$model_), length(model1$model_))
  expect_lt(abs(mean(model1$model_[[1]]$model_$coefficients
                     - model2$model_[[1]]$model_$coefficients)),
            0.05 * abs(mean(model1$model_[[1]]$model_$coefficients)))

  # predict
  prediction1 <- predict(model1, data)
  expect_equal(length(prediction1), length(data$conso))
  expect_equal(class(prediction1), "numeric")
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data)
  expect_equal(prediction1, simulation1)

  # predict with leading_period
  target_period    <- rep(1, nrow(data))
  target_period[1] <- 0
  prediction2 <- predict(model1, data, leading_period = 1 - target_period)
  expect_equal(length(prediction2), length(data$conso) - 1)
  expect_equal(class(prediction2), "numeric")
  expect_equal(prediction2, prediction1[2:length(prediction1)])
  # simulate with target_period
  simulation2 <- R39Toolbox::simulate(
    model1, data, leading_period = 1 - target_period)
  expect_equal(prediction2, simulation2)

  # rmse
  # score1 computed directly
  # score1_1 computed using weights
  score1 <- R39Toolbox::score(model1, data_cut, data_cut$conso)
  expect_equal(class(score1), "numeric")
  expect_equal(length(score1), 1)
  score1_1 <- R39Toolbox::score(model1, data, data$conso, weights = weights)
  expect_equal(score1_1, score1)
  # mape
  score2 <- R39Toolbox::score(model1, data, data$conso,
                              type = R39Toolbox::mape)
  expect_equal(class(score2), "numeric")
  expect_equal(length(score2), 1)
})


# 1. Init/fit/predict model *with prior transformation function*
test_that("GAM model with transform", {
  # init
  model1 <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan",
    transformation_function = transformation_function)
  expect_true("GeneralizedAdditiveModel" %in% class(model1))

  # fit
  model1 <- R39Toolbox::fit(model1, data_cut_alt)
  expect_true("GeneralizedAdditiveModel" %in% class(model1))
  expect_true(!is.null(model1$model_))

  # predict
  prediction1 <- predict(model1, data_alt)
  expect_equal(length(prediction1), length(data_alt$conso))
  expect_equal(class(prediction1), "numeric")
  # predict with detailed effects
  prediction1_1 <- R39Toolbox::predict_details(model1, data_alt)
  expect_equal(prediction1, as.numeric(rowSums(prediction1_1)))
  # simulate
  simulation1 <- R39Toolbox::simulate(model1, data_alt)
  expect_equal(prediction1, simulation1)
})


test_that("Adaptative GAM models with polynomial adaptation", {
  # init
  model_gam <- R39Toolbox::GeneralizedAdditiveModel(
    formula = "conso ~ s(Temperature) + Posan")
  model_gam <- R39Toolbox::fit(model_gam, data_cut)
  model1 <- R39Toolbox::GeneralizedAdditiveModelAdaptative(
    model_gam,
    fixed_global_effects = c('Posan', '(Intercept)'),
    adapted_poly_effects = list('s(Temperature)' = c(2,3)),
    mu = 0.95, max_obs = 3)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))

  model1 <- R39Toolbox::fit(model1, data_cut)
  expect_true("GeneralizedAdditiveModelAdaptative" %in% class(model1))
  expect_true(!is.null(model1$model_))
  expect_equal(ncol(model1$alphas_), 3)
})
