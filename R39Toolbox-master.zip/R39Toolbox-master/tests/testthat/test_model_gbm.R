##########################
# Generalized Boosted Model
##########################
context("Generalized Boosted model tests")

skip_if_no_gbm <- function() {
  if (!require(gbm)) {
    skip("'gbm' package not available.")
  }
}

data <- R39Toolbox::R39ExData
data$Instant <- as.factor(data$Instant)
train_test_split <- floor(nrow(data) * 0.8)
train <- data[1:train_test_split, ]
test <- data[(1 + train_test_split):nrow(data), ]

test_that("Generalized Boosted models two ways of initialization", {
  skip_if_no_gbm()
  # test run initialization
  # two ways don't necessarily end in the same performance
  
  # init
  model1 <- R39Toolbox::GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 3, interaction_depth = 2,
    shrinkage = 0.1, n_trees = 500,
    formula = "conso ~ Temperature + Posan + TypeJour7 + Tendance")
  
  model2 <- R39Toolbox::GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 3, interaction_depth = 2,
    shrinkage = 0.1, n_trees = 500)
  
  # fit
  invisible(capture.output(model1 <- R39Toolbox::fit(model1, train)))
  train_2 <- data.frame(model.matrix(~ .-1, train[, -c(1, 5)]))
  invisible(capture.output(model2 <- R39Toolbox::fit(model2, train_2)))
  
  # predict
  prediction_1 <- predict(model1, test)
  test_2 <- data.frame(model.matrix(~ .-1, test[, -c(1, 5)]))
  prediction_2 <- predict(model2, test_2)
  expect_equal(length(prediction_1), length(test$conso))
  expect_equal(length(prediction_2), length(test$conso))
})


test_that("Generalized Boosted model by instant, initialized by formula", {
  skip_if_no_gbm()
  # init by formula
  model1 <- GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 3, interaction_depth = 2,
    shrinkage = 0.1, n_trees = 500,
    formula = "conso ~ Temperature + Posan + TypeJour7 + Tendance",
    fit_default = list(by = 'Instant'))
  
  model2 <- GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 5, interaction_depth = 3,
    shrinkage = 0.2, n_trees = 500,
    formula = "conso ~ Temperature + Posan + TypeJour7",
    fit_default = list(by = 'Instant'))
  
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))
  
  # fit
  data_tmp <- train
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(data_tmp$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  
  invisible(capture.output(model <- R39Toolbox::fit(model, data_tmp)))
  
  # fit sub-models separately
  invisible(capture.output(model1 <- R39Toolbox::fit(
    model1, train[as.numeric(train$Instant) >= 10, ])))
  invisible(capture.output(model2 <- R39Toolbox::fit(
    model2, train[as.numeric(train$Instant) < 10, ])))
  
  # predict
  prediction <- predict(model, data_tmp)
  expect_equal(length(prediction), length(data_tmp$conso))
  
  # predict sub-models separately
  expect_true(
    all(prediction[as.numeric(train$Instant) >= 10] ==
          predict(model1, data_tmp[as.numeric(train$Instant) >= 10, ])))
  expect_true(
    all(prediction[as.numeric(train$Instant) < 10] ==
          predict(model2, data_tmp[as.numeric(train$Instant) < 10, ])))
})


test_that("Generalized Boosted model by instant, initialized by data set", {
  skip_if_no_gbm()
  # init by dataset
  model1 <- R39Toolbox::GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 3, interaction_depth = 2,
    shrinkage = 0.1, n_trees = 500,
    fit_default = list(by = 'Instant'))
  
  model2 <- R39Toolbox::GeneralizedBoostedModel(
    target_variable = "conso",
    min_node_size = 5, interaction_depth = 3,
    shrinkage = 0.2, n_trees = 500,
    fit_default = list(by = 'Instant'))
  
  model  <- R39Toolbox::CompositeModel(
    model_list = list(model1, model2),
    selection_factor_name = 'selection_factor',
    selection_factor_levels = list(0, 1))
  expect_true("CompositeModel" %in% class(model))
  
  # fit
  data_tmp <- data.frame(model.matrix(~ .-1, train[, -c(1, 5)]))
  data_tmp$selection_factor <- 0
  data_tmp$selection_factor[as.numeric(train$Instant) < 10] <- 1
  data_tmp$selection_factor <- as.factor(data_tmp$selection_factor)
  data_tmp$Instant <- train$Instant
  invisible(capture.output(model <- R39Toolbox::fit(model, data_tmp)))
  
  # fit sub-models separately
  invisible(capture.output(model1 <- R39Toolbox::fit(
    model1, data_tmp[as.numeric(train$Instant) >= 10, - 12])))
  invisible(capture.output(model2 <- R39Toolbox::fit(
    model2, data_tmp[as.numeric(train$Instant) < 10, - 12])))
  
  # predict
  prediction <- predict(model, data_tmp)
  
  expect_equal(length(prediction), length(data_tmp$conso))
  
  # predict sub-models separately
  expect_true(
    all(prediction[as.numeric(train$Instant) >= 10] ==
          predict(model1, data_tmp[as.numeric(train$Instant) >= 10, ])))
  expect_true(
    all(prediction[as.numeric(train$Instant) < 10] ==
          predict(model2, data_tmp[as.numeric(train$Instant) < 10, ])))
})
