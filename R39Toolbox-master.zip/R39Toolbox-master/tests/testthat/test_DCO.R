context("DCO tests")

test_that("Calhisto profiles", {
  calhisto_ref <- read.table(
    "./test_calhisto.csv", sep = ';', header = TRUE, dec = '.')
  ### weekdays
  date_begin <- "2000-01-01"
  date_end   <- "2019-12-31"
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  daytype <- R39Toolbox::generate_daytypes_calhisto_profiles(data)
  toto <- cbind(calhisto_ref$DayType, as.numeric(levels(daytype)[daytype]))
  map_values <- list(
    "0" = 1, "1" = 14, "2" = 5, "3" = 6, "4" = 0,
    "5" = 20, "6" = 21, "7" = 22, "8" = 34, "9" = 30, "10" = 33,
    "11" = 471, "12" = 47, "13" = 472, "14" = 401, "15" = 40)
  for (x in names(map_values)) {
    expect_equal(unique(toto[toto[, 1] == x, 2]), map_values[[x]])
  }
})


test_that("read Dco data", {
  date_begin <- as.POSIXct(
    '01/01/2011 00:00', format = "%d/%m/%Y %H:%M", tz = 'CET')
  date_end   <- as.POSIXct(
    '31/01/2011 23:30', format = "%d/%m/%Y %H:%M", tz = 'CET')
  dateComparison <- seq(from = date_begin, to = date_end, by = 30 * 60)
  dataToCompare <- read_dco_data("./dcoData.csv",
                                 c("Temperature", "Nebulosity"))
  #test if the results was the one expected
  expect_identical(dataToCompare$date, dateComparison)
  expect_equal(class(dataToCompare$date), class(dateComparison))
  #test if error is catched
  expect_error(read_dco_data("./dcoData.csv",
                             c("Temperature", "Nebulosity", "Frost")))
})
