context("preprocessings tests")

testna <- c(NA, NA, 2, NA, 4, NA, 3, 5, NA, NA)

tz <- 'CET'
date.start <- "2010-10-30 00:00:00"
date.end   <- "2010-12-01 23:50:00"
date.seq   <- seq.POSIXt(as.POSIXct(date.start, tz = tz),
                         as.POSIXct(date.end, tz = tz),
                         by = "10 min")
data.cet    <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
factor.test <- as.factor(c(rep(letters[1:6], each = 2), "hello", "ok"))

##########################
# create 0 - 1 dummy variables for categorical variables : binarize
##########################

test_that("binarize result", {
  d <- binarize(factor.test)
  expect_identical(paste0("factor.test_", levels(factor.test)), colnames(d))
  expect_identical(length(factor.test), nrow(d))
  expect_identical(nlevels(factor.test), ncol(d))
  expect_error(binarize(1:10))
  expect_error(binarize(letters[1:10]))
})


##########################
# lag
##########################
test_that("lag result", {
  expect_identical(1:10, lag(1:10, 0))
  expect_identical(c(NA, 1:9), lag(1:10, 1))
  expect_identical(c(rep(NA, 5), 1:5), lag(1:10, 5))
  expect_identical(rep(NA, 10), lag(1:10, 10))
})


test_that("lag control", {
  expect_error(lag(1:10, -1))
  expect_error(lag(1:10, 11))
  wv <- options("warn")$warn
  options(warn=-1)
  expect_error(lag(1:10, "re"))
})


##########################
# smooth
##########################
test_that("smooth variable scope", {
  expect_error(smoothTranform(testna, 0.5))
})


test_that("smooth theta", {
  x <- 1:10
  expect_equal(x, smooth(x, 0))
  expect_equal(rep(x[1], 10), smooth(x, 1))
})


test_that("smooth control", {
  expect_error(smooth(1:10, -1))
  expect_error(smooth(1:10, "re"))
  expect_error(smooth(LETTERS[1:10], 0.5))
})


##########################
# switch_time_zone
##########################
test_that("timezone conversion", {
  date.seq <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'CET'),
                         as.POSIXct("2010-12-01 23:50:00", tz = 'CET'),
                         by = "10 min")
  data.cet <- data.frame(date = date.seq, value = seq(1, length(date.seq)))

  # Conversion to same timezone
  data.cet2 <- R39Toolbox::switch_time_zone(data.cet, 'CET')
  expect_equal(data.cet, data.cet2)

  # Conversion to UTC
  data.utc <- R39Toolbox::switch_time_zone(data.cet, 'UTC')
  expect_equal(dim(data.cet), dim(data.utc))
  expect_equal(format.POSIXct(data.utc$date[1], "%Y-%m-%d %H:%M:%S %Z"),
               "2010-10-29 22:00:00 UTC")
  expect_equal(format.POSIXct(data.utc$date[dim(data.utc)[[1]]],
                              "%Y-%m-%d %H:%M:%S %Z"),
               "2010-12-01 22:50:00 UTC")

  # Conversion to CET24
  data.cet24 <- R39Toolbox::switch_time_zone(data.cet, 'CET24')
  expect_equal(dim(data.cet)[[1]], dim(data.cet24)[[1]] + 6)  # one hour "lost"
  expect_equal(data.cet24$date[[1]], "2010-10-30 00:00:00")
  expect_equal(data.cet24$date[[dim(data.cet24)[[1]]]], "2010-12-01 23:50:00")

  # Conversion to any timezone
  data.jst <- R39Toolbox::switch_time_zone(data.cet, 'Asia/Tokyo')
  expect_equal(dim(data.cet), dim(data.jst))
  expect_equal(format.POSIXct(data.jst$date[1], "%Y-%m-%d %H:%M:%S %Z"),
               "2010-10-30 07:00:00 JST")
  expect_equal(format.POSIXct(data.jst$date[length(date.seq)],
                              "%Y-%m-%d %H:%M:%S %Z"),
               "2010-12-02 07:50:00 JST")

  # Error cases
  # error when converting CET24 to another timezone
  expect_error(R39Toolbox::switch_time_zone(data.cet24, 'CET'))
  # error because of no 'date' column
  data.err <- data.cet
  names(data.err) <- c("foo", "bar")
  expect_error(R39Toolbox::switch_time_zone(data.err, 'CET'))
})


##########################
# resample
##########################
test_that("resampling", {
  ### Downsampling
  date.seq   <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'UTC'),
                           as.POSIXct("2010-12-01 23:50:00", tz = 'UTC'),
                           by = "10 min")
  data.10min <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
  # aggregation strategy = mean, type = first
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min")
  expect_equal(dim(data.30min)[[1]], dim(data.10min)[[1]] / 3)
  expect_equal(data.30min$value, data.10min$value[seq(2, length(date.seq), 3)])
  expect_equal(data.10min$date[1], data.30min$date[1])
  # aggregation strategy = mean, type = last
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     type_aggr = 'last')
  expect_equal(dim(data.30min)[[1]], (dim(data.10min)[[1]] / 3) - 1)
  expect_equal(data.30min$value, data.10min$value[seq(3, length(date.seq) - 3, 3)])
  expect_equal(tail(data.10min$date, 3)[1], tail(data.30min$date, 1))
  # aggregation strategy = NULL, type = first
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     fun_aggr = NULL)
  expect_equal(dim(data.30min)[[1]], dim(data.10min)[[1]] / 3)
  expect_equal(data.30min$value, data.10min$value[seq(1, length(date.seq), 3)])
  expect_equal(data.10min$date[1], data.30min$date[1])
  # aggregation strategy = NULL, type = last
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     fun_aggr = NULL, type_aggr = 'last')
  expect_equal(dim(data.30min)[[1]], (dim(data.10min)[[1]] / 3))
  expect_equal(data.30min$value, data.10min$value[seq(3, length(date.seq), 3)])

  ### Oversampling
  date.seq   <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'UTC'),
                           as.POSIXct("2010-12-01 23:30:00", tz = 'UTC'),
                           by = "30 min")
  data.30min <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
  data.15min <- R39Toolbox::resample(data.30min, target_timestep = "15 min")
  expect_equal(dim(data.15min)[[1]], (dim(data.30min)[[1]] - 1) * 2 + 1)
  expect_equal(data.15min$value[[1]], data.30min$value[[1]])
  expect_equal(data.15min$value[[2]],
               mean(c(data.30min$value[[1]], data.30min$value[[2]])))

  ### CET24 case
  data.10min <- R39Toolbox::generate_calendar(
    "2010-10-30 00:00:00", "2010-12-01 23:50:00", ts = 10 * 60,
    tz = 'CET24', variables = c('date', 'Instant'))
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min")
  expect_equal(dim(data.30min)[[1]], dim(data.10min)[[1]] / 3)
  expect_equal(data.30min$value,
               data.10min$value[seq(2, dim(data.10min)[[1]], 3)])

  ### Test with a non-uniform timestep in input data
  data.10min <- R39Toolbox::generate_calendar(
    "2010-10-30 00:00:00", "2010-12-01 23:50:00", ts = 10 * 60,
    tz = 'CET24', variables = c('date', 'Instant'))
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     fun_aggr = NULL)
  data.nonuniform <- data.10min[c(1, 2, 3, 5, 8, 9, 15, 25, 30,
                                  seq(31, dim(data.10min)[[1]])), ]
  class(data.nonuniform[, "date"]) <- "CET24"
  data.30min2 <- R39Toolbox::resample(data.nonuniform, target_timestep = "30 min")
  expect_equal(data.30min$date[1:10], data.30min2$date[1:10])
  expect_equal(data.30min$Instant[1:10], data.30min2$Instant[1:10])

  ### Tests with qualitative variables
  # Downsampling
  date.seq   <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'UTC'),
                           as.POSIXct("2010-12-01 23:50:00", tz = 'UTC'),
                           by = "10 min")
  data.10min <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
  data.10min$value.quali <- as.factor(data.10min$value)
  # aggregation strategy = NULL, type = first
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     fun_aggr = NULL, type_aggr = 'first')
  expect_equal(data.30min$value, as.numeric(data.30min$value.quali))
  expect_equal(data.10min$date[1], data.30min$date[1])
  # aggregation strategy = NULL, type = last
  data.30min <- R39Toolbox::resample(data.10min, target_timestep = "30 min",
                                     fun_aggr = NULL, type_aggr = 'last')
  expect_equal(data.30min$value, as.numeric(data.30min$value.quali))
  ## Oversampling
  date.seq   <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'UTC'),
                           as.POSIXct("2010-12-01 23:30:00", tz = 'UTC'),
                           by = "30 min")
  data.30min <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
  data.30min$value.quali <- as.factor(data.30min$value)
  data.15min <- R39Toolbox::resample(data.30min, target_timestep = "15 min",
                                     type_aggr = 'first')
  expect_equal(floor(data.15min$value),
               as.numeric(as.character(data.15min$value.quali)))
  data.15min <- R39Toolbox::resample(data.30min, target_timestep = "15 min",
                                     type_aggr = 'last')
  expect_equal(ceiling(data.15min$value),
               as.numeric(as.character(data.15min$value.quali)))
  ## Error case (non-uniform timestep with qualitative variable)
  data.nonuniform <- data.10min[c(1, 2, 3, 5, 8, 9, 15, 25, 30,
                                  seq(31, dim(data.10min)[[1]])), ]
  expect_error(R39Toolbox::resample(data.nonuniform, target_timestep = "30 min"))
  expect_error(R39Toolbox::resample(data.nonuniform, target_timestep = "5 min"))

})


# Deprecation tests
test_that("switchTimeZone is still OK", {
  date.seq <- seq.POSIXt(as.POSIXct("2010-10-30 00:00:00", tz = 'CET'),
                         as.POSIXct("2010-12-01 23:50:00", tz = 'CET'),
                         by = "10 min")
  data.cet <- data.frame(date = date.seq, value = seq(1, length(date.seq)))
  expect_warning(switchTimeZone(data.cet, 'CET'))
})


##########################
# extract daily stat
##########################
test_that("DayTypes", {
  date_begin <- "2018-04-08"
  date_end   <- "2018-04-14"
  # CET
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "CET", variables = c("date", "Instant"))
  data$X <- 1:(48 * 7)
  daily_stat <- R39Toolbox::extract_daily_statistic(data, "X", min)
  expect_equal(daily_stat, rep(0:6 * 48 + 1, each = 48))
  # UTC
  data <- R39Toolbox::generate_calendar(
    date_begin = paste0(date_begin, " 00:00:00"),
    date_end   = paste0(date_end, " 23:30:00"),
    ts = 30 * 60, tz = "UTC", variables = c("date", "Instant"))
  data$X <- 1:(48 * 7)
  daily_stat <- R39Toolbox::extract_daily_statistic(data, "X", min)
  expect_equal(daily_stat, rep(0:6 * 48 + 1, each = 48))
})
