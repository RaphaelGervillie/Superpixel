context("date/time concordance between functions")

### Common treatments
date.ejp.glob <- seq(as.Date("2010-01-01"), as.Date("2010-12-31"), "days")
data.ejp.glob <- data.frame(date = date.ejp.glob,
                            NORD = c(0, 1, 0, 1, 0),
                            SUD  = c(1, 0, 1, 0, 1))


# With this test we check the consistency between transform_EJP
# and quantitativeTransform when no timezone conversion is involved
# and no interpolation is necessary.
# We only make sure that we are able to generate data we consistent
# timestamps and that nothing is touched by the interpolation part.
test_that("conversion from <tz>/<ts> to (same) <tz>/<ts> is OK", {
  # GMT omitted from test to save time. Should be the same than UTC.
  tz <- c('UTC', 'CET', 'CET24')  # add GMT here if needed
  ts <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 180 * 60)
  test <- expand.grid(tz, ts)

  check <- sapply(1:nrow(test), function(x) {
    tz <- as.character(test[x, 1])
    ts <- test[x, 2]
    tz.safe <- ifelse(tz == 'CET24', 'UTC', tz)

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz.safe),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz.safe),
                by   = ts)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    if (tz == 'CET24') {
      data.ejp$date <- as.character(data.ejp$date)
      class(data.ejp$date) <- 'CET24'
    }
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]
    if (tz == 'CET24') {
      data.iter$date <- format.POSIXct(data.iter$date, "%Y-%m-%d %H:%M:%S")
      class(data.iter$date) <- 'CET24'
      data.iter.short$date <- format.POSIXct(data.iter.short$date,
                                             "%Y-%m-%d %H:%M:%S")
      class(data.iter.short$date) <- 'CET24'
    }

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz, ts = ts)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz, ts = ts, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
  })
})


# With this test we check the interpolation and its consistence between
# the generate_calendar and transform_EJP functions.
# We check the length of the output dataset according to the output timestep
# and we check the output date sequence is continuous (as we are working with
# UTC). There should therefore be no daylight saving and all sequences
# of this test must start at "2010/01/01 00:00:00".
test_that("conversion from UTC/<ts> to UTC/<ts'>", {
  # GMT omitted from test to save time. Should be the same than UTC.
  tz   <- c('UTC')  # add GMT here if needed
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 24 * 60 * 60)
  test <- expand.grid(tz, tz, ts, ts)

  check <- sapply(1:nrow(test), function(x) {
    tz.in  <- as.character(test[x, 1])
    tz.out <- as.character(test[x, 2])
    ts.in  <- test[x, 3]
    ts.out <- test[x, 4]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz.in),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz.in),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz.out, ts = ts.out)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz.out, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[4132], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 01:30:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[4133], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[14548], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 01:30:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[14549], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[2066], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 01:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[2067], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[7274], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 01:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[7275], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[1033], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 00:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[1034], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[3637], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 00:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[3638], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[689], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-03-28 00:00:00 ", tz.out))
    ##   expect_equal(format.POSIXct(tmp.ejp$date[690], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-03-28 03:00:00 ", tz.out))
    ##   # switch to winter time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2425], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-10-31 00:00:00 ", tz.out))
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2426], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-10-31 03:00:00 ", tz.out))
    }
  })
})


# This test is the same that the test above, except that we are now working
# with CET. All date sequences should start at "2010/01/01 00:00:00 CET".
# They are not continuous since CET is subject to daylight saving time.
# As a consequence, we should observe two breaks in the output date sequences,
# the existence of which we check in this test.
test_that("conversion from CET/<ts> to CET/<ts'>", {
  # TODO: check values (interpolation)

  tz   <- 'CET'
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60)
  test <- expand.grid(ts, ts)

  check <- sapply(1:nrow(test), function(x) {
    ts.in  <- test[x, 1]
    ts.out <- test[x, 2]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz, ts = ts.out)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[4132], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 01:30:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[4133], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[14548], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:30:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[14549], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[2066], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 01:00:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[2067], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[7274], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[7275], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[1033], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 00:00:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[1034], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[3637], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 01:00:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[3638], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[689], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-03-28 00:00:00 CET")
    ##   expect_equal(format.POSIXct(tmp.ejp$date[690], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-03-28 04:00:00 CEST")
    ##   # switch to winter time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2425], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-10-31 01:00:00 CEST")
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2426], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-10-31 03:00:00 CET")
    }
  })
})


# This is again the same test as the two above, but working with CET24.
# All date sequences should start at "2010/01/01 00:00:00". The date objects
# are actually character strings the class of which has been set to 'CET24'.
# We check that these sequences are continuous as the CET24 format has no
# daylight saving time switch.
test_that("conversion from CET24/<ts> to CET24/<ts'>", {
  # TODO: check values (interpolation)

  tz   <- 'CET24'
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 24 * 60 * 60)
  test <- expand.grid(ts, ts)

  check <- sapply(1:nrow(test), function(x) {
    ts.in  <- test[x, 1]
    ts.out <- test[x, 2]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz ='UTC'),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = 'UTC'),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]
    # conversion to CET24
    data.ejp[, "date"]         <- as.character(data.ejp[, "date"])
    class(data.ejp[, "date"])  <- 'CET24'
    data.iter[, "date"]        <- as.character(data.iter[, "date"])
    class(data.iter[, "date"]) <- 'CET24'
    data.iter.short[, "date"]        <- as.character(data.iter.short[, "date"])
    class(data.iter.short[, "date"]) <- 'CET24'

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz, ts = ts.out)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[4132]], "2010-03-28 01:30:00")
      expect_equal(tmp.ejp$date[[4133]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[14548]], "2010-10-31 01:30:00")
      expect_equal(tmp.ejp$date[[14549]], "2010-10-31 02:00:00")
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[2066]], "2010-03-28 01:00:00")
      expect_equal(tmp.ejp$date[[2067]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[7274]], "2010-10-31 01:00:00")
      expect_equal(tmp.ejp$date[[7275]], "2010-10-31 02:00:00")
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[1033]], "2010-03-28 00:00:00")
      expect_equal(tmp.ejp$date[[1034]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[3637]], "2010-10-31 00:00:00")
      expect_equal(tmp.ejp$date[[3638]], "2010-10-31 02:00:00")
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(tmp.ejp$date[689], "2010-03-28 00:00:00")
    ##   expect_equal(tmp.ejp$date[690], "2010-03-28 03:00:00")
    ##   # switch to winter time
    ##   expect_equal(tmp.ejp$date[2425], "2010-10-31 00:00:00")
    ##   expect_equal(tmp.ejp$date[2426], "2010-10-31 03:00:00")
    }
  })
})


# This test is to check the consistence between transform_EJP and
# generate_calendarwhen they are asked to return CET24 data.
# The transform_EJP function should return a data set the date sequence
# of which starts at "2010/01/01 00:00:00" and is in CET24 format.
# This is the same for the generate_calendar function.
test_that("conversion from UTC/<ts> to CET24/<ts'>", {
  # GMT omitted from test to save time. Should be the same than UTC.
  tz   <- c('UTC')  # add GMT here if needed
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 24 * 60 * 60)
  test <- expand.grid(tz, ts, ts)

  check <- sapply(1:nrow(test), function(x) {
    tz.in  <- as.character(test[x, 1])
    tz.out <- 'CET24'
    ts.in  <- test[x, 2]
    ts.out <- test[x, 3]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz.in),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz.in),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz.out, ts = ts.out)
    tmp.calendar.ejp <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz.out, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar.ejp$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[4132]], "2010-03-28 01:30:00")
      expect_equal(tmp.ejp$date[[4133]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[14548]], "2010-10-31 01:30:00")
      expect_equal(tmp.ejp$date[[14549]], "2010-10-31 02:00:00")
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[2066]], "2010-03-28 01:00:00")
      expect_equal(tmp.ejp$date[[2067]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[7274]], "2010-10-31 01:00:00")
      expect_equal(tmp.ejp$date[[7275]], "2010-10-31 02:00:00")
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(tmp.ejp$date[[1033]], "2010-03-28 00:00:00")
      expect_equal(tmp.ejp$date[[1034]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[3637]], "2010-10-31 00:00:00")
      expect_equal(tmp.ejp$date[[3638]], "2010-10-31 02:00:00")
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(tmp.ejp$date[689], "2010-03-28 00:00:00")
    ##   expect_equal(tmp.ejp$date[690], "2010-03-28 03:00:00")
    ##   # switch to winter time
    ##   expect_equal(tmp.ejp$date[2425], "2010-10-31 00:00:00")
    ##   expect_equal(tmp.ejp$date[2426], "2010-10-31 03:00:00")
    }
  })
})


# This test is to check the consistence between transform_EJP and
# generate_calendar and when they are asked
# to return CET24 data.
# The transform_EJP function should return a data set the date sequence
# of which starts at "2010/01/01 00:00:00" and is in CET24 format.
# This is the same for the generate_calendar function.
test_that("conversion from CET/<ts> to CET24/<ts'>", {
  # TODO: check values (interpolation)

  tz.in  <- 'CET'
  tz.out <- 'CET24'
  ts     <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 24 * 60 * 60)
  test   <- expand.grid(ts, ts)

  ctrl <- sapply(1:nrow(test), function(x) {
    ts.in  <- test[x, 1]
    ts.out <- test[x, 2]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz.in),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz.in),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz.out, ts = ts.out)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz.out, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time (+ check the existence of duplicated values)
      expect_equal(tmp.ejp$date[[4132]], "2010-03-28 01:30:00")
      expect_equal(tmp.ejp$date[[4133]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[14548]], "2010-10-31 01:30:00")
      expect_equal(tmp.ejp$date[[14549]], "2010-10-31 02:00:00")
    } else if (ts.out == 60 * 60) {
      # switch to summer time (+ check the existence of duplicated values)
      expect_equal(tmp.ejp$date[[2066]], "2010-03-28 01:00:00")
      expect_equal(tmp.ejp$date[[2067]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[7274]], "2010-10-31 01:00:00")
      expect_equal(tmp.ejp$date[[7275]], "2010-10-31 02:00:00")
    } else if (ts.out == 120 * 60) {
      # switch to summer time (+ check values)
      expect_equal(tmp.ejp$date[[1033]], "2010-03-28 00:00:00")
      expect_equal(tmp.ejp$date[[1034]], "2010-03-28 02:00:00")
      # switch to winter time
      expect_equal(tmp.ejp$date[[3637]], "2010-10-31 00:00:00")
      expect_equal(tmp.ejp$date[[3638]], "2010-10-31 02:00:00")
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time (+ check values)
    ##   expect_equal(tmp.ejp$date[689], "2010-03-28 00:00:00")
    ##   expect_equal(tmp.ejp$date[690], "2010-03-28 03:00:00")
    ##   # switch to winter time
    ##   expect_equal(tmp.ejp$date[2425], "2010-10-31 00:00:00")
    ##   expect_equal(tmp.ejp$date[2426], "2010-10-31 03:00:00")
    }
  })
})


# With this test we check that the conversion from UTC dataset
# to CET ones is consistent. We pay attention to the daylight saving time
# switch timestamps, because the values of the dataset variables for these
# timestamp should not change with regard to their position in the dataset.
# In fact, only the date values are changing. We check that the change
# consist only of a one-hour shift (or two hours in winter).
test_that("conversion from UTC/<ts> to CET/<ts'>", {
  # GMT omitted from test to save time. Should be the same than UTC.
  tz   <- c('UTC')  # add GMT here if needed
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60)
  test <- expand.grid(tz, ts, ts)

  ctrl <- sapply(1:nrow(test), function(x) {
    tz.in  <- as.character(test[x, 1])
    tz.out <- 'CET'
    ts.in  <- test[x, 2]
    ts.out <- test[x, 3]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01", tz = tz.in),
                to   = as.POSIXct("2011-01-01 00:00:00", tz = tz.in),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz.out, ts = ts.out)
    tmp.calendar.ejp <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz.out, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar.ejp$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[4132], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 01:30:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[4133], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[14548], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:30:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[14549], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[2066], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 01:00:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[2067], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[7274], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[7275], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[1033], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 00:00:00 CET")
      expect_equal(format.POSIXct(tmp.ejp$date[1034], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-03-28 03:00:00 CEST")
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[3637], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 01:00:00 CEST")
      expect_equal(format.POSIXct(tmp.ejp$date[3638], "%Y-%m-%d %H:%M:%S",
                            usetz = TRUE),
                   "2010-10-31 02:00:00 CET")
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[689], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-03-28 00:00:00 CET")
    ##   expect_equal(format.POSIXct(tmp.ejp$date[690], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-03-28 04:00:00 CEST")
    ##   # switch to winter time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2425], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-10-31 01:00:00 CEST")
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2426], "%Y-%m-%d %H:%M:%S",
    ##                         usetz = TRUE),
    ##                "2010-10-31 03:00:00 CET")
    }
  })
})


# This test is the converse of the test above.
# When converting from CET to UTC, only the date sequence should
# change, but the values of the corresponding variables must remain
# the same. We check that in the current test.
test_that("conversion from CET/<ts> to UTC/<ts'>", {
  # GMT omitted from test to save time. Should be the same than UTC.
  tz   <- c('UTC')  # add GMT here if needed
  ts   <- c(10 * 60, 30 * 60, 60 * 60, 120 * 60, 24 * 60 * 60)
  test <- expand.grid(tz, ts, ts)

  check <- sapply(1:nrow(test), function(x) {
    tz.out <- as.character(test[x, 1])
    tz.in  <- 'CET'
    ts.in  <- test[x, 2]
    ts.out <- test[x, 3]

    ### Build data
    # initial date sequence
    date <- seq(from = as.POSIXct("2010-01-01 01:00:00", tz = tz.in),
                to   = as.POSIXct("2011-01-01 01:00:00", tz = tz.in),
                by   = ts.in)
    # compute "instant" variable (easy to check its values after interpolation)
    max.instant <- 24 * 60 * 60 / ts.in
    instant.per.hour <- max.instant / 24
    instants <- (hour(date) * instant.per.hour
                 + minute(date) / (60 / instant.per.hour))
    # data EJP
    data.ejp <- data.ejp.glob
    # data quanti for interpolation
    data.iter       <- data.frame(date = date, value = instants,
                                  value2 = instants)
    data.iter.short <- data.iter[1:(dim(data.iter)[[1]] - 1), ]

    ### Tests
    # consistency between EJP & calendar
    tmp.ejp      <- transform_EJP(data = data.ejp, tz = tz.out, ts = ts.out)
    tmp.calendar <- generate_calendar(
      "2010-01-01 00:00:00", "2011-01-01 00:00:00",
      tz = tz.out, ts = ts.out, keep_last = FALSE)
    expect_equal(tmp.ejp$date, tmp.calendar$date)
    # check daylight saving time switches
    if (ts.out == 30 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[4132], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 01:30:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[4133], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[14548], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 01:30:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[14549], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    } else if (ts.out == 60 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[2066], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 01:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[2067], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[7274], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 01:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[7275], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    } else if (ts.out == 120 * 60) {
      # switch to summer time
      expect_equal(format.POSIXct(tmp.ejp$date[1033], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 00:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[1034], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-03-28 02:00:00 ", tz.out))
      # switch to winter time
      expect_equal(format.POSIXct(tmp.ejp$date[3637], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 00:00:00 ", tz.out))
      expect_equal(format.POSIXct(tmp.ejp$date[3638], "%Y-%m-%d %H:%M:%S %Z"),
                   paste0("2010-10-31 02:00:00 ", tz.out))
    ## } else if (ts.out == 180 * 60) {
    ##   # switch to summer time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[689], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-03-28 00:00:00 ", tz.out))
    ##   expect_equal(format.POSIXct(tmp.ejp$date[690], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-03-28 03:00:00 ", tz.out))
    ##   # switch to winter time
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2425], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-10-31 00:00:00 ", tz.out))
    ##   expect_equal(format.POSIXct(tmp.ejp$date[2426], "%Y-%m-%d %H:%M:%S %Z"),
    ##                paste0("2010-10-31 03:00:00 ", tz.out))
    }
  })
})
