context("Fonction de recalage tests sur une plus longue période")

#chargement des jeux de donnees
res <- readRDS("test_recalage_res_longer_period.rds")
simu <- readRDS("test_recalage_simu_longer_period.rds")
#chargement du fichier stf_opt pour l'hebdo
stf_opt_hebdo <- readRDS("test_recalage_param_stf_longer_period.rds")
#chargement du fichier stf_opt_infra pour l'infra
stf_opt_infra <- readRDS("test_recalage_param_stf_infra_longer_period.rds")
#chargement du fichier de ref pour les resultats hebdo
res_hebdo <- read.table("hebdo_reventail_longer_period.txt", header = TRUE)
#chargement du fichier de ref pour les resultats infra
res_infra <- read.table("infra_reventail_longer_period.txt", header = TRUE)
#chargement du fichier de ref pour les resultats hebdo + infra
res_hebdo_infra <- read.table("hebdo_infra_reventail_longer_period.txt", header = TRUE)

test_that("recalage hebdo plus longue période", {
    res_prevision_toolbox <- R39Toolbox::eventailPrevisionCourtTerme(
            data = simu,
            resultats = res,
            STFparameters = stf_opt_hebdo,
            byDayType = 0,
            type_recalage = "hebdo"
        )
    testthat::expect_equal(res_prevision_toolbox$ShortTermForecast,
                           res_hebdo$ShortTermForecast,
                           tolerance = 1e-4)
})

test_that("recalage infra plus longue période", {
    start <- tail(which(simu$Load != 0), 1) + 1
    recal <- transform(simu, ShortTermForecast = res$EstimatedLoad)
    res_prevision_toolbox <- R39Toolbox::eventailPrevisionCourtTerme(
            data = simu,
            resultats = recal,
            STFparameters = stf_opt_infra,
            type_recalage = "infra"
        )
    prev_infra <- R39Toolbox::remplitPCTapres(
            donnees = res_prevision_toolbox,
            resultats = recal,
            start = start,
            CoeffDeRecopie = 0.29
        )
    testthat::expect_equal(prev_infra$ShortTermForecast,
                           res_infra$ShortTermForecast,
                           tolerance = 1e-4)
})


test_that("recalage hebdo + infra plus longue période", {
    start <- tail(which(simu$Load != 0), 1) + 1
    #recalage hebdo
    recal_hebdo <- R39Toolbox::eventailPrevisionCourtTerme(
            data = simu,
            resultats = res,
            STFparameters = stf_opt_hebdo,
            byDayType = 0,
            type_recalage = "hebdo"
        )
    #recalage infra avec l'hebdo
    recal_infra_avec_hebdo <- R39Toolbox::eventailPrevisionCourtTerme(
            data = simu,
            resultats = recal_hebdo,
            STFparameters = stf_opt_infra,
            type_recalage = "infra"
        )
    prev_infra_avec_hebdo <- R39Toolbox::remplitPCTapres(
            donnees = recal_infra_avec_hebdo,
            resultats = recal_infra_avec_hebdo,
            start = start,
            CoeffDeRecopie = 0.29
        )
    #comparaison
    testthat::expect_equal(prev_infra_avec_hebdo$ShortTermForecast,
                           res_hebdo_infra$ShortTermForecast,
                           tolerance = 1e-4)
})
